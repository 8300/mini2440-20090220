#ifndef __USBTXRX_H__
#define __USBTXRX_H__

void MenuUsbTransmit(HWND hwnd);
void MenuUsbReceive(HWND hwnd);
void MenuUsbStatus(HWND hwnd);
int IsUsbConnected(void);

#endif //__USBTXRX_H__