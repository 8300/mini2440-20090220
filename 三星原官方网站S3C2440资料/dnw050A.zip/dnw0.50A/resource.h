//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by dnw.rc
//
#define IDR_MENU1                       101
#define IDI_ICON1                       103
#define IDD_DIALOG1                     104
#define IDD_DIALOG2                     105
#define IDI_ICON2                       116
#define IDC_PROGRESS1                   1000
#define IDC_RADIO115200                 1001
#define IDC_RADIO57600                  1002
#define IDC_RADIO38400                  1003
#define IDC_RADIO19200                  1004
#define IDC_RADIO14400                  1005
#define IDC_RADIO9600                   1006
#define IDC_RADIOCOM1                   1010
#define IDC_RADIOCOM2                   1011
#define IDC_RADIOCOM3                   1012
#define IDC_RADIOCOM4                   1013
#define IDC_EDIT1                       1025
#define CM_ABOUT                        40003
#define CM_TRANSMIT                     40005
#define CM_CONNECT                      40007
#define CM_USBTRANSMIT                  40009
#define CM_SERIALSETTINGS               40010
#define CM_USBSTATUS                    40011
#define CM_OPTIONS                      40016
#define CM_USBRECEIVE                   40017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        117
#define _APS_NEXT_COMMAND_VALUE         40018
#define _APS_NEXT_CONTROL_VALUE         1028
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
