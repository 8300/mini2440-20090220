#ifndef __NAND_H
#define __NAND_H

////////////////////////////// 8-bit ////////////////////////////////
void Test_NF16_Page_Read(void);
void Test_NF16_Block_Erase(void);


U8 Read_Status(void);

//*************** H/W dependent functions ***************
// Assembler code for speed
void __RdPage512(U8 *pPage);
void __WrPage512(U8 *pPage);
void Nand_Reset(void);
int DownloadData(void);
void InputTargetBlock(void);

void NF16_Print_Id(void);
static U16 NF16_CheckId(void);
static int NF16_EraseBlock(U32 blockNum);
int NF16_ReadPage(U32 block,U32 page,U32 *buffer);
static int NF16_WritePage(U32 block,U32 page,U8 *buffer);
int NF16_IsBadBlock(U32 block);
static int NF16_MarkBadBlock(U32 block);
void NF16_Init(void);

//*******************************************************



#endif /*__NAND_H*/

