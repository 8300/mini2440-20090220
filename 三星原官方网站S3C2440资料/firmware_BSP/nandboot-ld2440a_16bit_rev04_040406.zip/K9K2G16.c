//====================================================================
// File Name : Nand.c
// Function  : S3C2440 8-bit interface Nand Test program(this program use K9k2g16.c).
// Date      : May xx, 2003
// Version   : 0.0
// History
//   R0.0 (200305xx): Modified for 2440 from 2410. -> DonGo
//====================================================================


/**************** K9s1206 NAND flash ********************/
// 1block=(512+16)bytes x 32pages
// 4096block
// Block: A[23:14], Page: [13:9]
/**************** K9K2G16 NAND flash *******************/
// 1block=(2048+64)bytes x 64pages
// 2048block
// Block: A[23:14], page: [13:9]
/*****************************************************/

#include <string.h>
#include <stdlib.h>
#include "def.h"
#include "option.h"
#include "2440addr.h"
#include "2440lib.h"
#include "2440slib.h" 

#include "Nand.h"
//#include "k9k2g16.h"


#define C_LANG	1
#define DMA		2
#define TRANS_MODE DMA



#define BAD_MARK	(0xffff4444)




U16 Write_Protect=0;


U32 srcAddress;
U32 targetBlock;	    // Block number (0 ~ 4095)
U32 targetSize;	    // Total byte size 

U32 downloadAddress;
U32 downloadProgramSize=0x0;

//*************************************************
//*************************************************
//**           H/W dependent functions           **
//************************************************* 
//*************************************************

//The code is made for bi-endian mode

// block0: reserved for boot strap
// block1~4095: used for OS image
// badblock SE: xx xx xx xx xx 00 ....
// good block SE: ECC0 ECC1 ECC2 FF FF FF ....

#define WRITEVERIFY  (0)  //verifing is enable at writing.

#define NF_MECC_UnLock()         {rNFCONT&=~(1<<5);}
#define NF_MECC_Lock()         {rNFCONT|=(1<<5);}

#define NF_CMD(cmd)			{rNFCMD=cmd;}
#define NF_ADDR(addr)		{rNFADDR=addr;}	
#define NF_nFCE_L()			{rNFCONT&=~(1<<1);}
#define NF_nFCE_H()			{rNFCONT|=(1<<1);}
#define NF_RSTECC()			{rNFCONT|=(1<<4);}
#define NF_RDDATA() 		(rNFDATA)
#define NF_RDDATA8() 		((*(volatile unsigned char*)0x4E000010) )

#define NF_WRDATA(data) 	{rNFDATA=data;}

#define NF_WAITRB()    		{while(!(rNFSTAT&(1<<1)));} 
	   						 //wait tWB and check F_RNB pin.
// RnB Signal
#define NF_CLEAR_RB()    		{rNFSTAT |= (1<<2);}	// Have write '1' to clear this bit.
#define NF_DETECT_RB()    		{while(!(rNFSTAT&(1<<2)));}

#define ID_K9S1208V0M	0xec76
#define ID_K9K2G16U0M	0xecca

#define	NF16_BAD_OFFSET		(12)

// HCLK=100Mhz
#define TACLS		0	// 1-clk(0ns) 
#define TWRPH0		4     // 3-clk(25ns)
#define TWRPH1		0	// 1-clk(10ns)  //TACLS+TWRPH0+TWRPH1>=50ns


 


extern char *hex2char(int val);

void __RdPage512(U8 *bufPt); 



 int NF16_ReadPage(U32 block,U32 page,U32 *buffer)
{
    int i;
    unsigned int blockPage;
    U32 ecc_low,ecc_high,Mecc0, Mecc1;
    U16 ecc0, ecc1, ecc2, ecc3;
    U32 *bufPt=buffer;
    U32 se[16];	   
    

    blockPage=(block<<6)+page;

	 NF_RSTECC();    // Initialize ECC
       NF_MECC_UnLock();
    
	NF_nFCE_L();    

	NF_CLEAR_RB();
	NF_CMD(0x00);	// Read command
	NF_ADDR(0); 	// Column (A[7:0]) = 0
	NF_ADDR(0);		// A[10:8]
	NF_ADDR((blockPage)&0xff);	// A[18:11]
	NF_ADDR((blockPage>>8)&0xff);	// A[26:19]
	NF_ADDR((blockPage>>16)&0xff);  // A27
	NF_CMD(0x30);	// 2'nd command
	NF_DETECT_RB();

#if TRANS_MODE==C_LANG
    for(i=0;i<512;i++) {
    	*bufPt++=NF_RDDATA();	// Read one page
    }
#elif TRANS_MODE==DMA
	// Nand to memory dma setting
    rSRCPND=BIT_DMA0;	// Init DMA src pending.
    rDISRC0=NFDATA; 	// Nand flash data register
    rDISRCC0=(0<<0) | (1<<0); //arc=AHB,src_addr=fix
    rDIDST0=(unsigned)bufPt;
    rDIDSTC0=(0<<1) | (0<<0); //dst=AHB,dst_addr=inc;
	rDCON0=(1<<31)|(1<<30)|(1<<29)|(1<<28)|(1<<27)|(0<<23)|(1<<22)|(2<<20)|(2048/4/4);
	//Handshake,AHB,interrupt,(4-burst),whole,S/W,no_autoreload,word,count=128;

	// DMA on and start.
    rDMASKTRIG0=(1<<1)|(1<<0);

     while(!(rSRCPND & BIT_DMA0));	// Wait until Dma transfer is done.
    rSRCPND=BIT_DMA0;
#endif
   NF_MECC_Lock();


    // ECC check by hardware
  
   NF_RDDATA(); // bad block information
   Mecc0=NF_RDDATA();
   Mecc1=NF_RDDATA();
     
   rNFMECCD0=((Mecc1&0xff00)<<16)|((Mecc0&0xff00)<<8)|((Mecc1&0xff)<<8)|((Mecc0&0xff));
   rNFMECCD1=(Mecc1&0xff000000)|((Mecc0&0xff000000)>>8)|((Mecc1&0xff0000)>>8)|((Mecc0&0xff0000)>>16);
  
   NF_nFCE_H();    

   if (((rNFESTAT0&0x3) == 0x0) &&((rNFESTAT1&0x3) == 0x0))   return OK;
   else 	return FAIL;
    	
   	   
}


void Nand_Reset(void)
{
    int i;
   
	NF_nFCE_L();

	NF_CLEAR_RB();
	NF_CMD(0xFF);	//reset command
	NF_DETECT_RB();
	
	NF_nFCE_H();

}

void NF16_Init(void)
{
	// for S3C2440

	rNFCONF = (TACLS<<12)|(TWRPH0<<8)|(TWRPH1<<4)|(1<<0);	
	// TACLS		[14:12]	CLE&ALE duration = HCLK*TACLS.
	// TWRPH0		[10:8]	TWRPH0 duration = HCLK*(TWRPH0+1)
	// TWRPH1		[6:4]	TWRPH1 duration = HCLK*(TWRPH1+1)
	// AdvFlash(R)	[3]		Advanced NAND, 0:256/512, 1:1024/2048
	// PageSize(R)	[2]		NAND memory page size
	//						when [3]==0, 0:256, 1:512 bytes/page.
	//						when [3]==1, 0:1024, 1:2048 bytes/page.
	// AddrCycle(R)	[1]		NAND flash addr size
	//						when [3]==0, 0:3-addr, 1:4-addr.
	//						when [3]==1, 0:4-addr, 1:5-addr.
	// BusWidth(R/W) [0]	NAND bus width. 0:8-bit, 1:16-bit.
	
	rNFCONT = (0<<13)|(0<<12)|(0<<10)|(0<<9)|(0<<8)|(0<<6)|(0<<5)|(1<<4)|(1<<1)|(1<<0);
	// Lock-tight	[13]	0:Disable lock, 1:Enable lock.
	// Soft Lock	[12]	0:Disable lock, 1:Enable lock.
	// EnablillegalAcINT[10]	Illegal access interupt control. 0:Disable, 1:Enable
	// EnbRnBINT	[9]		RnB interrupt. 0:Disable, 1:Enable
	// RnB_TrandMode[8]		RnB transition detection config. 0:Low to High, 1:High to Low
	// SpareECCLock	[6]		0:Unlock, 1:Lock
	// MainECCLock	[5]		0:Unlock, 1:Lock
	// InitECC(W)	[4]		1:Init ECC decoder/encoder.
	// Reg_nCE		[1]		0:nFCE=0, 1:nFCE=1.
	// NANDC Enable	[0]		operating mode. 0:Disable, 1:Enable.

	rNFSTAT = 0;
    
    Nand_Reset();
}


 int NF16_IsBadBlock(U32 block)
{
    int i;
    unsigned int blockPage;
    U32 bad_block_data;
    
    
    blockPage=(block<<6);	// For 2'nd cycle I/O[7:5] 
    
	NF_nFCE_L();

	NF_CLEAR_RB();

	NF_CMD(0x00);		 // read command
	NF_ADDR((1024+0)&0xff);			// 2060 = 0x080c
	NF_ADDR(((1024+0)>>8)&0xff);		// A[10:8]
	NF_ADDR((blockPage)&0xff);		// A[11;18]
	NF_ADDR((blockPage>>8)&0xff);	// A[26:19]
	NF_ADDR((blockPage>>16)&0xff);	// A27
	NF_CMD(0x30);	// 2'nd command
	NF_DETECT_RB();	 // Wait tR(max 12us)

    bad_block_data=NF_RDDATA();

	NF_nFCE_H();    

    if(bad_block_data!=0xffffffff)
    {
    	return FAIL;
    }
    else
    {
    	return OK;
    }
}

