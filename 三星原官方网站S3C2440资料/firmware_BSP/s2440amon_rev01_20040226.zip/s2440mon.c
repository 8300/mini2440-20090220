/*******************************************************************
	
	NAME   :  2440MON.C				                           
 	DESC   :  2440 Serial(Port 1) monitor program          
 	History :  2003.05.xx ver 0.0			        
                     2004.02.25  Modefied for S3C2440A, by Y.H.Lee 

********************************************************************/

#include <stdlib.h>
#include <string.h>
#include "def.h"
#include "option.h"
#include "2440addr.h"
#include "2440lib.h"
#include "2440slib.h"

#define DOWNLOAD_ADDRESS _RAM_STARTADDRESS

void (*restart)(void)=(void (*)(void))0x0;
void (*run)(void)=(void (*)(void))DOWNLOAD_ADDRESS;

volatile unsigned char *downPt;
volatile unsigned int err=0;

void Isr_Init(void);
void Lcd_Off(void);
void Max1718_Set(int voltage);

void __irq Uart0_RxInt(void);
void __irq Uart1_RxInt(void);
void __irq Uerror(void);

void Main(void)
{
	int i,j;
    	int memError=0;
    	unsigned int fileSize, mpll_val;
    	unsigned short int checkSum=0,dnCS;
    
	//GPIO Port Init.
	Port_Init();
	Led_Display(0xf);
	
    	MMU_EnableICache();
	Led_Display(0x1);

	#if ADS10==TRUE
    		__rt_lib_init(); //for ADS 1.0
	#endif

	#if 1 //Set MAX1718 latch Value for VDDiarm Voltage and Clock Setting
	Delay(0);
	Max1718_Set(120);	// set proper voltage 
	Delay(1);
	
	ChangeClockDivider(13,12);
	//FCLK:HCLK:PCLK = 6:2:1
	ChangeMPllValue(97,1,2);	//FCLK=296MHz
	#endif

	Led_Display(0x2);

	downPt=(unsigned char *)DOWNLOAD_ADDRESS;

    	pISR_SWI=(_ISR_STARTADDRESS+0xf0);	  //for pSOS

	Isr_Init();

    	Uart_Init(0,115200);
	Uart_Select(1);
	Uart_TxEmpty(1);

    	Lcd_Off();  

	// FCLK,HCLK output
	rMISCCR = (rMISCCR & ~(7<<8) & ~(7<<4)) | (3<<8) | (2<<4);	// CLKSEL0=FCLK, CLKSEL1=HCLK
	rGPHCON = (rGPHCON & ~(0xf<<18)) | (2<<20) | (2<<18);		// CLKOUT1, CLKOUT0

    	/*******************************/
    	/*          		Banner      	            */
    	/*******************************/

    	Uart_Printf("\n\n+-----------------------------------------------------+\n");
	Uart_Printf("| S3C2440A Serial Downloader ver R0.02 2004 February. |\n");
	Uart_Printf("+-----------------------------------------------------+\n");
    	Uart_Printf("FCLK=%dMHz,COM:115.2kbps,8Bit,NP,UART1 <n+6>(4)+(n)+CS(2)\n",FCLK/1000000);
    	Uart_Printf("DOWNADDR:%xh ISR_ADDR:%xh \n",DOWNLOAD_ADDRESS,_ISR_STARTADDRESS);

	mpll_val = rMPLLCON;
	Uart_Printf("MPLLVal [M:%xh,P:%xh,S:%xh]\n", (mpll_val&(0xff<<12))>>12,(mpll_val&(0x3f<<4))>>4,(mpll_val&0x3));
	Uart_Printf("CLKDIVN:%xh\n", rCLKDIVN);

    	/*******************************/
    	/*      	    Memory test                  */
    	/*******************************/
    	Uart_Printf("\nMemory Test(%xh-%xh):WR",
	_RAM_STARTADDRESS,(_ISR_STARTADDRESS&0xfff0000));

     	for(i=_RAM_STARTADDRESS;i<(_ISR_STARTADDRESS&0xfff0000);i+=4)
    	{
		*((volatile unsigned *)i)=i;
    	}

    	Uart_Printf("\b\bRD");

    	for(i=_RAM_STARTADDRESS;i<(_ISR_STARTADDRESS&0xfff0000);i+=4)
    	{
		j=*((volatile unsigned *)i);

		if(j!=i)
		{
	    		memError=1;
	    		//Uart_Printf("0x%x=0x%x,",i,j);
		}
    	}

    	if(memError==0)
		Uart_Printf("\b\bO.K.\n");
    	else
		Uart_Printf("\b\bFAIL\n");


	MMU_DisableICache(); //for multi-ICE. 
    	//If ICache is not turned-off, debugging is started with ICache-on.
    	

    	/*******************************/
    	/*   	    Test program download   	     */
    	/*******************************/
    	
		while(( (unsigned int)downPt-DOWNLOAD_ADDRESS )<4)
    	{
			Led_Display(0xf);
			Delay(1000);
			Led_Display(0x0);
			Delay(1000);
  		}

    	fileSize=*((unsigned char *)(DOWNLOAD_ADDRESS+0))+
		(*((unsigned char *)(DOWNLOAD_ADDRESS+1))<<8)+
		(*((unsigned char *)(DOWNLOAD_ADDRESS+2))<<16)+
		(*((unsigned char *)(DOWNLOAD_ADDRESS+3))<<24);

    	Uart_Printf("\nNow, Downloading[FILESIZE:%7d bytes]\n",fileSize);

    	j=1000;

    	while(((int)downPt-DOWNLOAD_ADDRESS)<fileSize)
    	{
       		 if( ((int)downPt-DOWNLOAD_ADDRESS)>=j)
        	{
            	j+=1000;
				Uart_Printf(".");
			}
    	}

    	/*******************************/
    	/*    	 Verify check sum      */
    	/*******************************/

    	for(i=4;i<(fileSize-2);i++)
    	{
			checkSum+=*((unsigned char *)(i+DOWNLOAD_ADDRESS));
  		}

    	dnCS=*((unsigned char *)(DOWNLOAD_ADDRESS+fileSize-2))+
	(*( (unsigned char *)(DOWNLOAD_ADDRESS+fileSize-1) )<<8);

    	if(checkSum!=dnCS)
    	{
		Uart_Printf("Checksum Error!!! MEM:%x DN:%x\n",checkSum,dnCS);
		restart();
    	}

    	Uart_Printf("\nDownload O.K.\n");

    	//Move the program from 0x30000004~ to 0x30000000~(to remove header and checksum)
    	for(i=4;i<(fileSize-2);i++) 
    	{
		*((unsigned char *)(i+DOWNLOAD_ADDRESS-4))=*((unsigned char *)(i+DOWNLOAD_ADDRESS));
    	}

    	run();
}


//Sub-Routins
void Isr_Init(void)
{
	//rINTCON=0x5;    //Non-vectored,IRQ enable,FIQ disable 
    	rINTMOD=0x0;    //All=IRQ mode

	// Uart 0
	rINTSUBMSK=~(BIT_SUB_RXD0);	//Enable Rx0 Default value=0x7ff
    	rINTMSK=~(BIT_UART0);	//Enable UART0 Default value=0xffffffff
    	/*pISR_FIQ,pISR_IRQ must be initialized*/
    	pISR_UART0=(unsigned)Uart0_RxInt;

	// Uart 1
    	rINTSUBMSK=~(BIT_SUB_RXD1);	//Enable Rx1 Default value=0x7ff
    	rINTMSK=~(BIT_UART1);	//Enable UART1 Default value=0xffffffff
    	/*pISR_FIQ,pISR_IRQ must be initialized*/
    	pISR_UART1=(unsigned)Uart1_RxInt;
}

void Max1718_Set(int voltage)
{

	int vtg;
	
	//////////////////////////////////////////////
	//   D4    D3  D2   D1     D0
	//	0	 1	0 	0	 0		// 1.35V
	//	0	 1	0 	0	 1		// 1.30V
	//	0	 1	0 	1	 0		// 1.25V
	//	0	 1	0 	1	 1		// 1.20V
	//	0	 1	1 	0	 0		// 1.15V
	//	0	 1	1 	0	 1		// 1.10V
	//	0	 1	1 	1	 0		// 1.05V
	//	0	 1	1 	1	 1		// 1.00V
	//	1	 0	0 	0	 1		// 0.95V
	//	1	 0	0 	1	 1		// 0.90V
	//	1	 0	1 	0	 1		// 0.85V
	//	1	 0	1 	1	 1		// 0.80V
	
    	vtg=voltage;
	
	rGPBCON = (rGPBCON&~((3<<20) |(3<<16) |(3<<14))) | (1<<20) | (1<<16) | (1<<14);
	// GPB7, 8, 10 : Output
	rGPFCON=(rGPFCON&~(0xff<<8))|(0x55<<8);  // GPF4~7: Output , shared with LED4~7

     switch (vtg)
     {
	case 135:	
		 rGPBDAT=(rGPBDAT&~(1<<7)) |(0<<7);	//D4
	      rGPFDAT=(rGPFDAT&~(0xf<<4))|(1<<7)|(0<<6)|(0<<5)|(0<<4);	//D3~0
	      break;

	case 130:    
		 rGPBDAT=(rGPBDAT&~(1<<7)) |(0<<7);	//D4
		 rGPFDAT=(rGPFDAT&~(0xf<<4))|(1<<7)|(0<<6)|(0<<5)|(1<<4); //D3~0
		 break;
       
	case 125:
		 rGPBDAT=(rGPBDAT&~(1<<7)) |(0<<7);	//D4
		 rGPFDAT=(rGPFDAT&~(0xf<<4))|(1<<7)|(0<<6)|(1<<5)|(0<<4); //D3~0
		break;

	case 120:
		 rGPBDAT=(rGPBDAT&~(1<<7)) |(0<<7);	//D4
		 rGPFDAT=(rGPFDAT&~(0xf<<4))|(1<<7)|(0<<6)|(1<<5)|(1<<4); //D3~0
		 break;

	case 115:
		 rGPBDAT=(rGPBDAT&~(1<<7)) |(0<<7);	//D4
		 rGPFDAT=(rGPFDAT&~(0xf<<4))|(1<<7)|(1<<6)|(0<<5)|(0<<4); //D3~0
		 break;

	case 110:
		 rGPBDAT=(rGPBDAT&~(1<<7)) |(0<<7);	//D4
		 rGPFDAT=(rGPFDAT&~(0xf<<4))|(1<<7)|(1<<6)|(0<<5)|(1<<4); //D3~0
		 break;

	case 105:
		 rGPBDAT=(rGPBDAT&~(1<<7)) |(0<<7);	//D4
		 rGPFDAT=(rGPFDAT&~(0xf<<4))|(1<<7)|(1<<6)|(1<<5)|(0<<4); //D3~0
		 break;

	case 100:
		 rGPBDAT=(rGPBDAT&~(1<<7)) |(0<<7);	//D4
		 rGPFDAT=(rGPFDAT&~(0xf<<4))|(1<<7)|(1<<6)|(1<<5)|(1<<4); //D3~0
		break;

	case 95:
		 rGPBDAT=(rGPBDAT&~(1<<7)) |(1<<7);	//D4
		 rGPFDAT=(rGPFDAT&~(0xf<<4))|(0<<7)|(0<<6)|(0<<5)|(1<<4); //D3~0
		 break;

	case 90:
		 rGPBDAT=(rGPBDAT&~(1<<7)) |(1<<7);	//D4
		 rGPFDAT=(rGPFDAT&~(0xf<<4))|(0<<7)|(0<<6)|(1<<5)|(1<<4); //D3~0
		 break;

	case 85:
		 rGPBDAT=(rGPBDAT&~(1<<7)) |(1<<7);	//D4
		rGPFDAT=(rGPFDAT&~(0xf<<4))|(0<<7)|(1<<6)|(0<<5)|(1<<4); //D3~0
		 break;

      	case 80:
		 rGPBDAT=(rGPBDAT&~(1<<7)) |(1<<7);	//D4
	       rGPFDAT=(rGPFDAT&~(0xf<<4))|(0<<7)|(1<<6)|(1<<5)|(1<<4); //D3~0
		 break;

       default:	// 1.2V
		 rGPBDAT=(rGPBDAT&~(1<<7)) |(0<<7);	//D4
		 rGPFDAT=(rGPFDAT&~(0xf<<4))|(1<<7)|(0<<6)|(1<<5)|(1<<4); //D3~0
		 break;
		 
	}
		 
	rGPBDAT&=~(1<<8);   //Latch enable
	rGPBDAT|=(1<<10);   //Output enable
	rGPBDAT|=(1<<8);	 //Latch disable

}

void Lcd_Off(void)//nDIS_OFF(GPB5)
{
	//Disable LCD panel
    	rGPBDAT=rGPBDAT & 0x7df;
    	rGPBCON=(rGPBCON & 0x3ff3ff) | (1<<10);
    	rGPBUP=rGPBUP & 0x7df;

	/*
    	rPDDAT=(rPDDAT & 0x5ff);
    	rPDCON=(rPDCON & 0x33ffff)|(1<<18); 
    	rPDUP =(rPDDAT & 0x5ff);
	*/
}

//ISRs 
void __irq Uart0_RxInt(void)
{
	rSUBSRCPND = BIT_SUB_RXD0;
    	rSUBSRCPND;
    
    	ClearPending(BIT_UART0);
	*downPt++=RdURXH0();
}

void __irq Uart1_RxInt(void)
{

 	rSUBSRCPND = BIT_SUB_RXD1;
    	rSUBSRCPND;
    
    	ClearPending(BIT_UART1);
	*downPt++=RdURXH1();
}

void __irq Uerror(void)
{
	rSUBSRCPND = BIT_SUB_ERR0;
    	rSUBSRCPND;

    	ClearPending(BIT_UART0);
    	err++;
}



