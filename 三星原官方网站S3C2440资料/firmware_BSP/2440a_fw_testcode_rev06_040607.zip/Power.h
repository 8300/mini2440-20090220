#ifndef __POWER_H__
#define __POWER_H__

// Main routine
void Power_Test(void);


void Test_SlowMode(void);
void Test_HoldMode(void);
void Test_IO_Strength(void);

#endif /*__POWER_H__*/
