#ifndef __IIS_DUAL_H__
#define __IIS_DUAL_H__

#ifdef __cplusplus
extern "C" {
#endif

void Test_IisRecPlay(void);

#ifdef __cplusplus
}
#endif

#endif    //__IIS_DUAL_H__