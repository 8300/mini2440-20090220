//====================================================================
// File Name : swi.h
// Function  : S3C2440 SWI Head File
// Program   : Shin, On Pil (SOP)
// Date      : March 12, 2002
// Version   : 0.0
// History
//   0.0 : Programming start (March 12, 2002) -> SOP
//   0.01: modified fo 2440 DonGo
//====================================================================

#ifndef __SWI_H__
#define __SWI_H__

void Test_SwiIrq(void);

#endif   //__SWI_H__
