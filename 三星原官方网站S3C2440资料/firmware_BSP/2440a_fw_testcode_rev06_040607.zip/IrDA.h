#ifndef __IrDA_H_
#define __IrDA_H_
#define IrDABUFFER  _NONCACHE_STARTADDRESS

void Test_IrDA_Tx(void);
void Test_IrDA_Rx(void);
void IrDA_Test(void);

#endif/*__IrDA_H_*/