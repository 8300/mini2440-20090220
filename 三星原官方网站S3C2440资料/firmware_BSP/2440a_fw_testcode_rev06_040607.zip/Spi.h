#ifndef __SPI_H__
#define __SPI_H__

void Test_Spi_MS_int(void);
void Test_Spi_MS_poll(void);

void Test_Spi_M_Tx_DMA1(void);
void Test_Spi_M_Rx_DMA1(void);
void Test_Spi_S_Tx_DMA1(void);
void Test_Spi_S_Rx_DMA1(void);
void Test_Spi_M_Int(void);
void Test_Spi_S_Int(void);
void Spi_Test(void);

#endif /*__SPI_H__*/
