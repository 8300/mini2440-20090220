//====================================================================
// File Name : User_Testh
// Function  : S3C2440 
// Program   : DonGo
// Date      : April 15, 2003
// Version   : 0.0
// History
//   0.0 : Programming start (April 15, 2003) -> DonGo
//====================================================================

#ifndef __USER_TEST_H__
#define __USER_TEST_H__

void User_Test(void);

#endif    //__USER_TEST_H__
