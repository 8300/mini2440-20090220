#ifndef __UART1_H__
#define __UART1_H__

void Test_Uart1_Int(void);
void Test_Uart1_Dma(void);
void Test_Uart1_Fifo(void);
void Test_Uart1_AfcTx(void);
void Test_Uart1_AfcRx(void);


#endif /*__UART1_H__*/

