#ifndef __FLASH_H__
#define __FLASH_H__

void ProgramFlash(void);

#endif /*__FLASH_H__*/
