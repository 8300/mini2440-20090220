#ifndef __ADCTS_H__
#define __ADCTS_H__

//void Test_DMA_Adc(void);
void Test_AdcTs(void);
void Test_Adc(void);

#endif /*__ADC_H__*/
