//====================================================================
// File Name : Uart_Testh
// Function  : S3C2440 
// Program   : DonGo
// Date      : April 15, 2003
// Version   : 0.0
// History
//   0.0 : Programming start (April 15, 2003) -> DonGo
//====================================================================

#ifndef __UART_TEST_H__
#define __UART_TEST_H__

void Uart_Test(void);

#endif    //__UART_TEST_H__
