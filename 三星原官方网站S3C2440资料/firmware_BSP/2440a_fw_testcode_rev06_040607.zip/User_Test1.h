
#ifndef __USER_TEST1_H__
#define __USER_TEST1_H__

#ifdef __cplusplus
extern "C" {
#endif

void User_Test1(void);
#ifdef __cplusplus
}
#endif




#endif /*__USER_TEST1_H__*/
