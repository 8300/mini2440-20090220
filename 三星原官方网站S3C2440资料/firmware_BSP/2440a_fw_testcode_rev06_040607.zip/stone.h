#ifndef __STONE_H__
#define __STONE_H__

void Test_ISram(void);

#endif /*__STONE_H__*/

