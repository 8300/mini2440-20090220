#ifndef __IOTEST_H__
#define __IOTEST_H__

// Main routine
void Test_IO_Strength(void);


#endif /*__IOTEST_H__*/


