#ifndef __UART2_H__
#define __UART2_H__

void Test_Uart2_Int(void);
void Test_Uart2_Dma(void);
void Test_Uart2_Fifo(void);

#endif /*__UART2_H__*/

