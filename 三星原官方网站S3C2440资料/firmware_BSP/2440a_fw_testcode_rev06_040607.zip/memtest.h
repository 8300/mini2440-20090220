#ifndef __MEMTEST___
#define __MEMTEST___

void Mem_Test(int Print_msg);


#endif /*__MEMTEST___*/

