#ifndef __STRATA32_H__
#define __STRATA32_H__

void Program28F128J3A(void);
void Erase28F128J3A(void);

#endif /*__STRATA32_H__*/

