//====================================================================
// File Name  : swis.h
// Function	: S3C2440 SWI Test
// Date		: March 20, 2002
// Version	: 0.0
// History
//   0.0 : Programming start (March 12, 2002) -> SOP
//   0.01: Modified for 2440, DonGo
//====================================================================

#ifndef __SWIS_H__
#define __SWIS_H__

void SWI_ISR(void);

#endif   //__SWIS_H__
