#ifndef __IDLE_H__
#define __IDLE_H__

void Test_IdleMode(void);
void Test_IdleModeHard(void);
void Test_MMUIdleMode(void);

#endif /*__IDLE_H__*/
