
#ifndef __USER_TEST2_H__
#define __USER_TEST2_H__

#ifdef __cplusplus
extern "C" {
#endif

void User_Test2(void);
void Firm_DVS_Onoff(void);
void DVS_Onoff_Man(void);

#ifdef __cplusplus
}
#endif




#endif /*__USER_TEST2_H__*/
