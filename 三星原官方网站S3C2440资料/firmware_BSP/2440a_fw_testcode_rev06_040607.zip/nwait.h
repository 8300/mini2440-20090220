#ifndef __NWAIT_H__
#define __NWAIT_H__

void Test_WaitPin(void);
void Test_XBREQ(void);

#endif /*__NWAIT_H__*/
