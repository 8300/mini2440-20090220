#ifndef __PWR_C_H__
#define __PWR_C_H__

void MeasurePowerConsumption(void);
void dhrystone21(void);


void DoQsort(void);
void PWR_Lcd_Tft_16Bit_240320_On(void);
void PWR_StartTimer(void);
void PWR_StartIIS(void);


#endif /*__PWR_C_H__*/
