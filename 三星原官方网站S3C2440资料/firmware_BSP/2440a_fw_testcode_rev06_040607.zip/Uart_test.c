#include <stdio.h>
#include <string.h>
#include "def.h"
#include "option.h"
#include "2440addr.h"
#include "2440lib.h"

#include "Uart_test.h"

#include "Uart0.h"
#include "Uart1.h"
#include "Uart2.h"


void * func_uart_test[][2]=
{	
//									    "0123456789012345" max 15�� �������Ͽ� comment�ϼ���.
//UART
	(void *)Test_Uart0_Int, 								"UART0 Int      ",
	(void *)Test_Uart0_Dma, 								"UART0 DMA      ",
	(void *)Test_Uart0_Fifo,								"UART0 FIFO     ",
	(void *)Test_Uart0_AfcTx, 							"UART0 AFC Tx   ",
	(void *)Test_Uart0_AfcRx, 							"UART0 AFC Rx   ",
	(void *)Test_Uart0_RxErr,							"UART0 RxErr    ",


	(void *)Test_Uart1_Int, 								"UART1 Int      ",
	(void *)Test_Uart1_Dma, 								"UART1 DMA      ",
	(void *)Test_Uart1_Fifo,								"UART1 FIFO     ",
	(void *)Test_Uart1_AfcTx, 							"UART1 AFC Tx   ",
	(void *)Test_Uart1_AfcRx, 							"UART1 AFC Rx   ",

	(void *)Test_Uart2_Int, 								"UART2 Int      ",
	(void *)Test_Uart2_Dma, 								"UART2 DMA      ",
	(void *)Test_Uart2_Fifo,								"UART2 FIFO     ",

	//	(void *)Test_Rts_Rx,									"UART0 RTS test ",
		(void *)Test_Uart0_Temp,							"UART0 temp      ",
	0,0
};

void Uart_Test(void)
{
	int i;
	
	Uart_Printf("\n======  UART Test program start ======\n");
		
	while(1)
	{
		i=0;
		Uart_Printf("\n\n");
		while(1)
		{   //display menu
			Uart_Printf("%2d:%s",i,func_uart_test[i][1]);
			i++;
			if((int)(func_uart_test[i][0])==0)
			{
				Uart_Printf("\n");
				break;
			}
			if((i%4)==0)
			Uart_Printf("\n");
		}

		Uart_Printf("\nPress Enter key to exit : ");
		i = Uart_GetIntNum();
		if(i==-1) break;		// return.
		if(i>=0 && (i<((sizeof(func_uart_test)-1)/8)) )	// select and execute...
			( (void (*)(void)) (func_uart_test[i][0]) )();
	}
	
	Uart_Printf("\n====== UART Test program end ======\n");
}




