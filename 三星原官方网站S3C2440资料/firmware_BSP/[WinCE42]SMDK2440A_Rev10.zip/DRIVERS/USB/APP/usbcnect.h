/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
Copyright (c) 2001. Samsung Electronics, co. ltd  All rights reserved.

Module Name:  

Abstract:

	add RAS entry for USB connection - header file

rev:
	2002.1.22	: First release (kwangyoon LEE, kwangyoon@samsung.com)

Notes: 
--*/

#define SOCKET_FRIENDLY_NAME    1
#define IDS_USBCNECT_LINK       3
#define IDS_DEFAULT_NAME        2 

