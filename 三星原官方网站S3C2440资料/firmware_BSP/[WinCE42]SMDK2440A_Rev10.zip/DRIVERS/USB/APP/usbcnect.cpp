/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
Copyright (c) 2001. Samsung Electronics, co. ltd  All rights reserved.

Module Name:  

Abstract:

	add RAS entry for USB connection

rev:
	2002.1.22	: First release (kwangyoon LEE, kwangyoon@samsung.com)

Notes: 
--*/

#include <windows.h>
#include <ras.h>
#include "usbcnect.h"


 VOID CreateRASEntry(HINSTANCE hinst) 
 {
     DWORD           cb;
     RASENTRY        RasEntry;
 
     TCHAR name[256];
     LoadString(hinst, IDS_DEFAULT_NAME, name, 256);
 
     // This will create the default entries if the key does not exist. 
     RasEntry.dwSize = sizeof(RASENTRY);
     cb = sizeof(RASENTRY);
     RasGetEntryProperties (NULL, TEXT(""), &RasEntry, &cb, NULL, NULL);
 
     // Now set up the entry the way we want it (like "`115200 Default")
     TCHAR szDeviceName[RAS_MaxDeviceName + 1];
     LoadString(hinst, SOCKET_FRIENDLY_NAME, szDeviceName, RAS_MaxDeviceName + 1);
     _tcsncpy (RasEntry.szDeviceName, szDeviceName, RAS_MaxDeviceName + 1);
 
     // And finally, write the new entry out
     if ( RasSetEntryProperties (NULL, name,
                                 &RasEntry, sizeof(RasEntry), NULL, 0) ) 
     {
         RETAILMSG (1, (TEXT("Error %d from RasSetEntryProperties\r\n"),
                  GetLastError()));
         DEBUGMSG (1, (TEXT("Error %d from RasSetEntryProperties\r\n"),
                       GetLastError()));
     } 
     else 
     {
         RETAILMSG (1, (TEXT("RasEntry '%s' Created\r\n"), name));
         DEBUGMSG (1, (TEXT("RasEntry '%s' Created\r\n"), name));
     }
 
     // Now, delete the link file.
    TCHAR szUsbcnectLnk[256];
    LoadString(hinst, IDS_USBCNECT_LINK, szUsbcnectLnk, 256);
    BOOL fDeleted = DeleteFile(szUsbcnectLnk);
    if (!fDeleted)
    {
        DWORD dwDeletedError = GetLastError();
        DEBUGMSG(1, (TEXT("Usbcnect.lnk not deleted.  Error %i\r\n"), (UINT) dwDeletedError));
    }
}
 

int WINAPI WinMain(
    HINSTANCE hinst,
    HINSTANCE hinstPrev,
    LPWSTR szCmdLine,
    int iCmdShow
)
{
    CreateRASEntry(hinst);
    return 0;
}

