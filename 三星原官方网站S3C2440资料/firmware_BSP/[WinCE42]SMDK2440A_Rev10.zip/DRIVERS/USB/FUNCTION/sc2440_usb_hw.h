/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
Copyright (c) 2001. Samsung Electronics, co. ltd  All rights reserved.

Module Name:  

Abstract:

    S3C2440 USB function(ACTIVE SYNC) device driver (Chip Layer) header file

rev:
	2002.1.22	: First release/no error recovery (kwangyoon LEE, kwangyoon@samsung.com)

Notes: 
--*/

typedef struct
{
	unsigned char bmRequest, bRequest;
	unsigned short wValue, wIndex, wLength;
} SetupPKG, *PSetupPKG;

#define EP0_MAXP_SIZE           8
#define EP1_IN_MAXP_SIZE        64
#define EP2_IN_MAXP_SIZE        64
#define EP3_OUT_MAXP_SIZE       64
#define EP4_OUT_MAXP_SIZE       64

// EP0 use for configuration and Vendor Specific command interface

/*----------------------------------------------------------------------
 * The control FIFO is fixed at 8 bytes and will not work unless both
 * host and device use 8 byte packet size.
 */
#define EP0Len          EP0_MAXP_SIZE

/*----------------------------------------------------------------------
 * The IN/OUT packet size may be configured between 1-255 bytes (seems like
 * 16 is the only value that works reliably).
 */
#define EP1Len          EP1_IN_MAXP_SIZE
#define EP2Len          EP4_OUT_MAXP_SIZE

//-------------------------------------------------------------------------
// Standard Chapter 9 definition
//-------------------------------------------------------------------------

// Request Codes
#define GET_STATUS      0x00
#define CLEAR_FEATURE   0x01
#define SET_FEATURE     0x03
#define SET_ADDRESS     0x05
#define GET_DESCRIPTOR  0x06
#define SET_DESCRIPTOR  0x07
#define GET_CONFIG      0x08
#define SET_CONFIG      0x09
#define GET_INTERFACE   0x0a
#define SET_INTERFACE   0x0b

// Device specific request
#define SET_CONTROL_LINE_STATE  0x22

// Descriptor Types
#define DEVICE          0x01
#define CONFIGURATION   0x02
#define STRING          0x03
#define INTERFACE       0x04
#define ENDPOINT        0x05

/* Portable mechanism for writing bitfields in IO register structures
 */
#define IOW_REG_SET(_type,_ptr,_value)					\
		{							\
		*(volatile unsigned *)(_ptr) = _value;			\
		}
#define IOW_REG_OR(_type,_ptr,_value)					\
		{							\
		*(volatile unsigned *)(_ptr) |= _value;			\
		}
#define IOW_REG_AND(_type,_ptr,_value)					\
		{							\
		*(volatile unsigned *)(_ptr) &= _value;			\
		}

#define IOW_REG_FIELD(_type,_ptr,_field,_value)		       		\
		{							\
		register union {					\
		   _type s;						\
		   unsigned int d;					\
		} foo;							\
		foo.d = *(volatile unsigned *)(_ptr);			\
		foo.s._field = _value;					\
		*(volatile unsigned *)(_ptr) = foo.d;			\
		}

#define IOW_REG_BITSET(_type,_ptr,_field,_value)	       		\
		{							\
		register union {					\
		  _type s;						\
		  unsigned int d;					\
		} foo;							\
		foo.d = 0;						\
		foo.s._field = _value;					\
		*(volatile unsigned *)(_ptr) = foo.d;			\
		}
#define IOW_REG_GET(_type,_ptr,_field,_value)				\
		{							\
		register union {					\
		  _type s;						\
		  unsigned int d;					\
		} foo;							\
		foo.d = *(volatile unsigned *)(_ptr);			\
		_value = foo.s._field;					\
		}


//void HW_PowerOff(PSER_INFO pHWHead);
//void HW_PowerOn(PSER_INFO pHWHead);


BOOL InitUsbdDriverGlobals(void);  	//:-)
void UsbdDeallocateVm(void);	   	//:-)
BOOL UsbdAllocateVm(void);	   		//:-)
void UsbdInitDma3(int bufIndex,int bufOffset);	//:-)


