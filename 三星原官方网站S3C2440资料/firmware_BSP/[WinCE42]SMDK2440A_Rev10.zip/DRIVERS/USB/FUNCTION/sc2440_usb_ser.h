/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
Copyright (c) 2001. Samsung Electronics, co. ltd  All rights reserved.

Module Name:  

Abstract:

    S3C2440 USB function(ACTIVE SYNC) device driver (wrapper Layer) header file
	Holds definitions for sample SA-11X0 USB serial interface

rev:
	2002.5.8	: Add to s3c2410_code (Seung-han, Lim)
	2002.1.22	: First release/no error recovery (kwangyoon LEE, kwangyoon@samsung.com)

Notes: 
--*/

#ifndef __SER_PDD_H__   
#define __SER_PDD_H__

#ifdef __cplusplus
extern "C" {
#endif

//Here are the names of the values stored in the registry
#define SC2440USB_REG_IOBASE_VAL_NAME TEXT("IoBase") 
#define SC2440USB_REG_IOBASE_VAL_LEN  sizeof( DWORD )

#define SC2440USB_REG_IOLEN_VAL_NAME TEXT("IoLen") 
#define SC2440USB_REG_IOLEN_VAL_LEN  sizeof( DWORD )

#define SC2440USB_REG_IRQ_VAL_NAME TEXT("Irq") 
#define SC2440USB_REG_IRQ_VAL_LEN  sizeof( DWORD )

#define SC2440USB_REG_DEVINDEX_VAL_NAME TEXT("DeviceArrayIndex") 
#define SC2440USB_REG_DEVINDEX_VAL_LEN  sizeof( DWORD )

// We can be built with a simple setting 0, or optionally add
// a second setting which includes an interrupt endpoint
// #define INT_SETTING 1

// Since SC2440_USB doesn't interrupt on disconnect, we have option to poll for this
// #define POLL_FOR_DISCONNECT 1


// Strict timing requirements at enumeration.  Use a relatively high priority
#define DEFAULT_THREAD_PRIO 100
    
// We poll for device detach at the following rate.
// #define SC2440_USB_POLL_RATE 1000
#define SC2440_USB_POLL_RATE 500
// And simulate disconnect if SOF unchanged this many interations
#define SOF_STABLE_MAX 3

// Use this macro to determine if we are in Data0 or Data1 phase
// #define DATA1( dat_cnt ) ( ((dat_cnt) ^= 0x01) )
#define DATA1( dat_cnt ) ( ((++dat_cnt) & 0x01) )
    
// We use a callback for serial events
typedef VOID		(*EVENT_FUNC)(PVOID Arg1, ULONG Arg2);

// Here is the callback for serial events
typedef VOID (*PFN_SER_EVENT) (
              PVOID pHandle,      // PHW_INDEP_INFO, but pdd doesn't know it
	      UINT32 events       // What events where encountered?
	      );


typedef enum _USBD_STATE {
    OFF,
    SUSPEND,
    RESUME,
    IDLE,
    CONTROL,
    RX,
    PURGE_RX,
    ERR_RX,    
    TX,
    PURGE_TX,
    ERR_TX,
} USBD_STATE, *PUSBD_STATE;


/*
 * @doc HWINTERNAL
 * @struct SER_INFO | Private structure.
 */
typedef struct __SER_INFO {
	// Keep a copy of DCB since we rely on may of its parms
	DCB		dcb;		// @field Device Control Block (copy of DCB in MDD)

	// And the same thing applies for CommTimeouts
	COMMTIMEOUTS	CommTimeouts;	// @field Copy of CommTimeouts structure
	ULONG		CommErrors;	// @field Bitfield representing Win32 comm error status. 
	ULONG		ModemStatus;	// @field Bitfield representing Win32 modem status. 
	CRITICAL_SECTION HwRegCritSec;// @field Protects SC2440_USB registers from non-atomic
  				// access (addr/data pairs)
	CRITICAL_SECTION TransmitCritSec; // @field Protects UART TX FIFO from simultaneous access
	ULONG		OpenCount;	// @field Count of simultaneous opens. 
	ULONG		DroppedBytes;	// @field Number of dropped bytes 
	COMSTAT	Status; 	// @field Bitfield representing Win32 comm status. 
	HANDLE	FlushDone;	// @field Handle to flush done event.

	// We have our own dispatch thread.
	HANDLE	pDispatchThread;// @field ReceiveThread 
	DWORD		KillRxThread:1;	// @field Flag to terminate SC2440_USB_DispatchThread.
	HANDLE        hSerialEvent;   // @field Interrupt event
		
	// now hardware specific goodies
	DWORD		dwIOBase;       // @field IO Base Address - unmapped
	DWORD		dwIOLen;        // @field IO Length
	DWORD		dwIRQ;          // @field Interrupt number for this peripheral
	DWORD		dwDevIndex;     // @field Index of device
	WORD		wSOFStableCnt;  // @field How many iterations without SOF
	
	volatile IOPreg 		*pIrqCtrlAddr; // @field Interrupt base address
	volatile struct udcreg 	*pUSBCtrlAddr; // @field USB base address
	volatile CLKPWRreg    	*pCLKPWR;      // @field CLK/PWR base address

	SetupPKG	dReq;		// @field USB endpoint 0 command
	BYTE		cIntStat_eir;       // @field Last known interrupt status
	BYTE		cIntStat_uir;
	BYTE 		dConfIdx; 	// @field USB Configuration Index
	BYTE 		dInterface; 	// @field USB Interface Index
	BYTE 		dSetting; 	// @field USB Setting Index
	BYTE		dAddress;	// @field USB device Address
	UINT8		cOpenCount;     // @field Count of concurrent opens
	COMMPROP	CommProp;       // @field Pointer to CommProp structure.
	PVOID		pMddHead;       // @field First arg to mdd callbacks.
	PHWOBJ		pHWObj;         // @field Pointer to PDDs HWObj structure
	BOOL		fIRMode;        // @field Boolean, are we running in IR mode?

	WORD      wSOF;               // SOF count read in ISR
	WORD      wPrevSOF;

	USBD_STATE   State;
    
} SER_INFO, *PSER_INFO;

// And now, all the function prototypes
    PVOID
	SerInit(
        ULONG   Identifier,
        PVOID   pMddHead,
        PHWOBJ  pHWObj
        );
    BOOL SerPostInit(
        PVOID   pHead 
        );
    BOOL SerDeinit(
        PVOID   pHead 
        );
    BOOL SerOpen(
        PVOID   pHead 
        );
    ULONG SerClose(
        PVOID   pHead
        );
    VOID SerClearDTR(
        PVOID   pHead 
        );
    VOID SerSetDTR(
        PVOID   pHead 
        );
    VOID SerClearRTS(
        PVOID   pHead 
        );
    VOID SerSetRTS(
        PVOID   pHead 
        );
    VOID SerClearBreak(
        PVOID   pHead 
        );
    VOID SerSetBreak(
        PVOID   pHead 
        );
    VOID SerClearBreak(
        PVOID   pHead 
        );
    VOID SerSetBreak(
        PVOID   pHead
        );
    ULONG SerGetByteNumber(
        PVOID   pHead	     
        );
    VOID SerDisableXmit(
        PVOID   pHead	
        );
    VOID SerEnableXmit(
        PVOID   pHead	
        );
    BOOL SerSetBaudRate(
        PVOID   pHead,
        ULONG   BaudRate	//      ULONG representing decimal baud rate.
        );
    BOOL SerSetDCB(
        PVOID   pHead,	
        LPDCB   lpDCB		//     Pointer to DCB structure
        );
    ULONG SerSetCommTimeouts(
        PVOID   pHead,	
        LPCOMMTIMEOUTS   lpCommTimeouts //  Pointer to CommTimeout structure
        );
    ULONG SerGetRxBufferSize(
        PVOID pHead
        );
    INTERRUPT_TYPE SerGetInterruptType(
        PVOID pHead
        );
    ULONG SerRxIntr(
        PVOID pHead,
        PUCHAR pRxBuffer,       // Pointer to receive buffer
        ULONG *pBufflen         //  In = max bytes to read, out = bytes read
        );
    VOID SerTxIntr(
        PVOID pHead,
        PUCHAR pTxBuffer,
        ULONG *pBufflen
        );
    VOID SerLineIntr(
        PVOID pHead
        );
    VOID SerModemIntr(
        PVOID pHead 
        );
    ULONG SerGetStatus(
        PVOID	pHead,
        LPCOMSTAT lpStat	// Pointer to LPCOMMSTAT to hold status.
        );
    VOID SerReset(
        PVOID   pHead
        );
    VOID SerGetModemStatus(
        PVOID   pHead,
        PULONG  pModemStatus    //  PULONG passed in by user.
        );
    VOID SerPurgeComm(
        PVOID   pHead,
        DWORD   fdwAction	//  Action to take. 
        );
    BOOL SerXmitComChar(
        PVOID   pHead,
        UCHAR   ComChar		//  Character to transmit. 
        );
    BOOL SerPowerOn(
        PVOID   pHead
        );
    BOOL SerPowerOff(
        PVOID   pHead
        );
    BOOL SerIoctl(
        PVOID pHead,
        DWORD dwCode,
        PBYTE pBufIn,
        DWORD dwLenIn,
        PBYTE pBufOut,
        DWORD dwLenOut,
        PDWORD pdwActualOut
	);


    BOOL
    HW_PowerOff( 
        PSER_INFO pHWHead 
        );
    
    BOOL 
    HW_PowerOn(
        PSER_INFO pHWHead
        );


//*********************************************************
// Functions from the SC2440_USB HW support file
//*********************************************************
    void SC2440_USB_DoEndpoint0(
	PSER_INFO pHWHead,
	PDWORD pModemStatus
	);
    INTERRUPT_TYPE SC2440_USB_GetInterruptType(
	PSER_INFO pHWHead
	);
    void SC2440_USB_Init(
	PSER_INFO pHWHead
	);
    void SC2440_USB_LineIntHandler(
	PSER_INFO pHWHead
	);
    BOOL SC2440_USB_RxIntHandler(
	PSER_INFO pHWHead,
	PUCHAR pRxBuffer,
	ULONG *pBuffLen
	);
    void SC2440_USB_TxIntHandler(
	PSER_INFO pHWHead,
	PUCHAR pTxBuffer,
	ULONG *pBuffLen
	);

#ifdef __cplusplus
}
#endif

#endif __SER_PDD_H__
