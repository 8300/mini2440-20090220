#define SOCKET_FRIENDLY_NAME    1
#define IDS_USBCNECT_LINK       2
#define IDS_DEFAULT_NAME        3    
