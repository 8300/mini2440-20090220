/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
Copyright (c) 1995-2000 Microsoft Corporation.  All rights reserved.

Module Name:  
    uhcd.c
    
Abstract:  
    Platform dependant part of the USB Universal Host Controller Driver (UHCD).

Notes: 
--*/
#include <windows.h>
#include <nkintr.h>
#include <oalintr.h>
#include <ceddk.h>
#include <uhcdddsi.h>

// Registry key and value names
#define UHCI_DRIVER_KEY         TEXT("Drivers\\BuiltIn\\UHCI")
#define USE_EXISTING_VALUE_NAME TEXT("UseExistingSettings")
#define IRQ_VALUE_NAME          TEXT("Irq")
#define IOBASE_VALUE_NAME       TEXT("MemBase")

// Amount of memory to use for HCD buffer
static const DWORD gcTotalAvailablePhysicalMemory = 65536; // 64K
static const DWORD gcHighPriorityPhysicalMemory = 0x4000; // 16K

typedef struct _SUhcdPdd
{
    LPVOID lpvMemoryObject;
    LPVOID lpvUhcdMddObject;
} SUhcdPdd;

#define UnusedParameter(x)  x = x

/* UhcdPdd_DllMain
 * 
 *  DLL Entry point.
 *
 * Return Value:
 */
extern BOOL UhcdPdd_DllMain(HANDLE hinstDLL, DWORD dwReason, LPVOID lpvReserved)
{
    UnusedParameter(hinstDLL);
    UnusedParameter(dwReason);
    UnusedParameter(lpvReserved);

    return TRUE;
}


/* GetRegistryConfig
 *
 *   Function to get the IRQ and I/O port range from the registry.  
 *   Note: Will need to be changed to support multiple instances.
 *
 * Return Value:
 *   TRUE for success, FALSE for error
 */
static BOOL
GetRegistryConfig(
    DWORD * lpdwUseExistingSettings, // OUT- Receives value that indicates whether to 
                                     //      just use the resources assigned by the BIOS.  
    DWORD * lpdwIrq,    // OUT- Receives IRQ value
    DWORD * lpdwIoBase) // OUT- Receives I/O base
{
    HKEY hKey;
    DWORD dwData;
    DWORD dwSize;
    DWORD dwType;
    BOOL  fRet=FALSE;
    DWORD dwRet;

    dwRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE,UHCI_DRIVER_KEY,0,0,&hKey);
    if (dwRet != ERROR_SUCCESS) {
        DEBUGMSG(ZONE_ERROR,(TEXT("!UHCD:GetRegistryConfig RegOpenKeyEx(%s) failed %d\r\n"),
                             UHCI_DRIVER_KEY, dwRet));
        return FALSE;
    }
    dwSize = sizeof(dwData);
    dwRet = RegQueryValueEx(hKey,USE_EXISTING_VALUE_NAME,0,&dwType,(PUCHAR)&dwData,&dwSize);
    if (dwRet != ERROR_SUCCESS) {
        DEBUGMSG(ZONE_ERROR, (TEXT("!UHCD:GetRegistryConfig RegQueryValueEx(%s) failed %d\r\n"),
                              USE_EXISTING_VALUE_NAME, dwRet));
        goto GetRegistryConfig_exit;
    }
    *lpdwUseExistingSettings = dwData;

    dwSize = sizeof(dwData);
    dwRet = RegQueryValueEx(hKey,IRQ_VALUE_NAME,0,&dwType,(PUCHAR)&dwData,&dwSize);
    if (dwRet != ERROR_SUCCESS) {
        DEBUGMSG(ZONE_ERROR, (TEXT("!UHCD:GetRegistryConfig RegQueryValueEx(%s) failed %d\r\n"),
                              IRQ_VALUE_NAME, dwRet));
        goto GetRegistryConfig_exit;
    }
    *lpdwIrq = dwData;

    dwSize = sizeof(dwData);
    dwRet = RegQueryValueEx(hKey,IOBASE_VALUE_NAME,0,&dwType,(PUCHAR)&dwData,&dwSize);
    if (dwRet != ERROR_SUCCESS) {
        DEBUGMSG(ZONE_ERROR,(TEXT("!UHCD:GetRegistryConfig RegQueryValueEx(%s) failed %d\r\n"),
                             IOBASE_VALUE_NAME, dwRet));
        goto GetRegistryConfig_exit;
    }
    *lpdwIoBase = dwData;
    fRet = TRUE;

GetRegistryConfig_exit:
    RegCloseKey(hKey);
    return fRet;
}   // GetRegistryConfig


/* SetRegistryConfig
 *
 *   Function to set the IRQ and I/O port range in the registry.
 *   Note: Will need to be changed to support multiple instances.
 *
 * Return Value:
 *   TRUE for success, FALSE for error
 */
static BOOL
SetRegistryConfig(
    DWORD dwIrq,    // IN - IRQ value
    DWORD dwIoBase) // IN - I/O base
{
    HKEY hKey;
    BOOL  fRet=FALSE;
    DWORD dwRet;

    dwRet = RegOpenKeyEx(HKEY_LOCAL_MACHINE,UHCI_DRIVER_KEY,0,0,&hKey);
    if (dwRet != ERROR_SUCCESS) {
        DEBUGMSG(ZONE_ERROR,(TEXT("!UHCD:SetRegistryConfig RegOpenKeyEx(%s) failed %d\r\n"),
                             UHCI_DRIVER_KEY, dwRet));
        return FALSE;
    }

    dwRet = RegSetValueEx(hKey,IRQ_VALUE_NAME,0,REG_DWORD,(PUCHAR)&dwIrq,sizeof(DWORD));
    if (dwRet != ERROR_SUCCESS) {
        DEBUGMSG(ZONE_ERROR, (TEXT("!UHCD:SetRegistryConfig RegQueryValueEx(%s) failed %d\r\n"),
                              IRQ_VALUE_NAME, dwRet));
        goto SetRegistryConfig_exit;
    }

    dwRet = RegSetValueEx(hKey,IOBASE_VALUE_NAME,0,REG_DWORD,(PUCHAR)&dwIoBase,sizeof(DWORD));
    if (dwRet != ERROR_SUCCESS) {
        DEBUGMSG(ZONE_ERROR,(TEXT("!UHCD:SetRegistryConfig RegQueryValueEx(%s) failed %d\r\n"),
                             IOBASE_VALUE_NAME, dwRet));
        goto SetRegistryConfig_exit;
    }
    fRet = TRUE;

SetRegistryConfig_exit:
    RegCloseKey(hKey);
    return fRet;
}   // SetRegistryConfig

/* ConfigureUHCICard
 * 
 *    Configure UHCI controller I/O base and IRQ based on settings read from registry.
 *    This should really call routines which access the IRQ routing and memory base through
 *    the PCI BIOS and reconfigure the card.  Since we currently don't have the routines
 *    to do this, use the following algorithm:
 *        -- If fUseExisting flag is set, read the values from the PCI config registers on the
 *           card, and update pioPortBase and pIrq.
 *        -- If fUseExisting is not set, verify that the passed in values of pioPortBase and
 *           pIrq match, and return FALSE if they do not. (change - don't fail if mem base
 *           doesn't match, since this is determined by the PCI config mechanism, it will not
 *           conflict with other cards.)
 *
 * Return Value
 *    Return TRUE if successful, FALSE if card could not be detected, or if configuration
 *    does not match what was specified in the registry, and fUseExistingSettings is not set.
 */
BOOL
ConfigureUHCICard(
    BOOL fUseExistingSettings,
    PUCHAR *pioPortBase,   // IN - contains physical address of register base
                           // OUT- contains virtual address of register base
    ULONG *pIrq)           // IN - contains IRQ value
                           // OUT- (if fUseExistingSettings) contains actual IRQ value

{
    PCI_SLOT_NUMBER     slotNumber;
    PCI_COMMON_CONFIG   pciConfig;
    int                 bus, device, function;
    int                 length;
    BOOL                bFoundIt = FALSE;

// when detecting a PIIX4, these are the values which appear
#define UHCD_VENDOR_ID_INTEL ((USHORT)0x8086)
#define UHCD_DEVICE_ID_PIIX4 ((USHORT)0x7112)
// PIIX4 is strange in that the port base address
// is stored in BaseAddresses[ 4 ]. In fact, the
// BaseAddresses[ 0-3 ] are all 0, for some reason.
#define UHCD_PIIX4_ADDRESS_REG 4

    for (bus = 0; bus < PCI_MAX_BUS; bus++) {
        for (device = 0; device < PCI_MAX_DEVICES; device++) {
            slotNumber.u.bits.DeviceNumber = device;

            for (function = 0; function < PCI_MAX_FUNCTION; function++) {
                slotNumber.u.bits.FunctionNumber = function;

                length = HalGetBusData(PCIConfiguration, bus, slotNumber.u.AsULONG,
                                       &pciConfig, sizeof(pciConfig) - 
                                       sizeof(pciConfig.DeviceSpecific));

                if (length == 0 || pciConfig.VendorID == 0xFFFF) 
                    break;

                // the only UHCI controller I've tested so far is the 
                // PIIX4. The rest of this code will need to be altered
                // to support other controllers.
                //
                // This DEBUGCHK says:
                // "halt if we find an Intel USB controller that is not a PIIX4"
                DEBUGCHK( !(pciConfig.BaseClass == PCI_CLASS_SERIAL_BUS_CTLR &&
                            pciConfig.SubClass  == PCI_SUBCLASS_SB_USB &&
                            pciConfig.VendorID == UHCD_VENDOR_ID_INTEL ) ||
                          pciConfig.DeviceID == UHCD_DEVICE_ID_PIIX4 );

                if (pciConfig.BaseClass == PCI_CLASS_SERIAL_BUS_CTLR &&
                    pciConfig.SubClass  == PCI_SUBCLASS_SB_USB &&
                    pciConfig.VendorID == UHCD_VENDOR_ID_INTEL && 
                    pciConfig.DeviceID == UHCD_DEVICE_ID_PIIX4 ) {

                    RETAILMSG(1,(TEXT("UHCD: Found PCI USB UHCI controller, VendorId: %04X, DeviceId: %04X\r\n"),
                                 pciConfig.VendorID, pciConfig.DeviceID));
                    bFoundIt = TRUE;
                    DEBUGMSG( ZONE_INIT,
                              (TEXT("UHCD: PCI config: Irq = 0x%X, Port Base = 0x%X\r\n"), 
                              pciConfig.u.type0.InterruptLine, pciConfig.u.type0.BaseAddresses[ UHCD_PIIX4_ADDRESS_REG ]) );
                
                    // Update current config
                    if (fUseExistingSettings) {
                        *pIrq = pciConfig.u.type0.InterruptLine;
                        *pioPortBase = (PUCHAR)pciConfig.u.type0.BaseAddresses[ UHCD_PIIX4_ADDRESS_REG ];
                        // Save new values in registry
                        SetRegistryConfig(*pIrq, (DWORD)*pioPortBase);
                    }
                    else if ((pciConfig.u.type0.InterruptLine != (UCHAR) *pIrq) ||
                        (pciConfig.u.type0.BaseAddresses[ UHCD_PIIX4_ADDRESS_REG ] != (DWORD)*pioPortBase)) {
                        RETAILMSG(1,(TEXT("!UHCD:  Configuration different from registry: IRQ %u, PortBase: 0x%X (reg: %u, 0x%X)\r\n"),
                                     pciConfig.u.type0.InterruptLine,pciConfig.u.type0.BaseAddresses[ UHCD_PIIX4_ADDRESS_REG ],
                                     (UCHAR)*pIrq,(DWORD)*pioPortBase));
                        // If IRQ isn't what we expect, fail init (otherwise might conflict with ISA 
                        // devices).  Shouldn't have a problem with conflicting memory addresses, so
                        // don't fail if that doesn't match.
                        if (pciConfig.u.type0.InterruptLine != (UCHAR) *pIrq)
                            bFoundIt = FALSE;
                    }
                    break;
                }
                if (function == 0 && !(pciConfig.HeaderType & 0x80)) 
                    break;
            }
            if (bFoundIt || length == 0)
                break;
        }

        if (bFoundIt || (length == 0 && device == 0))
            break;
    }

    if (!bFoundIt) {
        DEBUGMSG(ZONE_ERROR, (TEXT("UHCD: Error, can't find USB Controller\r\n")));
        return FALSE;
    }
    DEBUGMSG(ZONE_INIT, (TEXT("UHCD: Revision Stepping value = 0x%02X\r\n"), pciConfig.RevisionID));

    // "PCI System Architecture, 3rd Ed" by Shanley/Anderson,
    // chapter 17, page 349 (I/O Base Address Register)
    // states that for I/O mapping, the address register
    // will end in 01. Page 348 shows that for memory mapping,
    // the register ends in 0.
#if 1
    // so far, the only UHCI controller I've tested is the PIIX4, which
    // is I/O mapped.
    DEBUGCHK( pciConfig.VendorID == UHCD_VENDOR_ID_INTEL &&
              pciConfig.DeviceID == UHCD_DEVICE_ID_PIIX4 );
    // check for I/O mapping (see comment above)
    DEBUGCHK( (((DWORD)*pioPortBase) & ~PCI_ADDRESS_IO_ADDRESS_MASK) == PCI_ADDRESS_IO_SPACE );
    *pioPortBase = (PUCHAR)( ((DWORD)*pioPortBase) & PCI_ADDRESS_IO_ADDRESS_MASK ); 
    DEBUGMSG(ZONE_INIT, (TEXT("UHCD: Using I/O Mapping. ioPortBase = 0x%X\n"), *pioPortBase)); 
#else
    if ( ((DWORD)*pioPortBase) & 0x1 ) {
        DEBUGCHK( (((DWORD)*pioPortBase) & (1 << 1) ) == 0 );
        *pioPortBase = (PUCHAR)(((DWORD)*pioPortBase) ^ 0x1); 
        DEBUGMSG(ZONE_INIT, (TEXT("UHCD: Using I/O Mapping. ioPortBase = 0x%X\n"), *pioPortBase)); 
    } else {
        // Memory mapped

        ULONG               portBase;
        PHYSICAL_ADDRESS    ioPhysicalBase;
        ULONG               inIoSpace = 0;
        ULONG               portRange = 0x70; // cDefaultUhcdPortRange;

        // So far, we haven't seen any memory mapped UHCI controllers
        DEBUGCHK( FALSE );

        // The bottom bit is 0 for memory-mapped
        DEBUGCHK( !(pciConfig.u.type0.BaseAddresses[ UHCD_PIIX4_ADDRESS_REG ] & 0x1) );
        portBase = pciConfig.u.type0.BaseAddresses[ UHCD_PIIX4_ADDRESS_REG ];
    
        ioPhysicalBase.LowPart = portBase;
    
        if (HalTranslateBusAddress(PCIBus, bus, ioPhysicalBase, &inIoSpace, 
                                   &ioPhysicalBase)) {
            if (!inIoSpace) {
                if ((*pioPortBase = (PUCHAR)MmMapIoSpace(ioPhysicalBase, 
                                                         portRange, FALSE)) == NULL) {
                    // We may as well not continue
                    DEBUGMSG(ZONE_ERROR, (TEXT("UHCD: Error mapping I/O Ports.\r\n")));
                    return FALSE;
                }
            } else {
                *pioPortBase = (PUCHAR)ioPhysicalBase.LowPart;
            }
        } else {
            DEBUGMSG(ZONE_ERROR, (TEXT("UHCD: Error translating I/O Ports.\r\n")));
            return FALSE;
        }
    
        DEBUGMSG(ZONE_INIT, 
                 (TEXT("UHCD: ioPhysicalBase 0x%X, IoSpace 0x%X\r\n"),
                  ioPhysicalBase.LowPart, inIoSpace));
        DEBUGMSG(ZONE_INIT, 
                 (TEXT("UHCD: ioPortBase 0x%X, portBase 0x%X\r\n"),
                  *pioPortBase, portBase));
    }
#endif

    return TRUE;
}


/* InitializeUHCI
 *
 *  Configure and initialize UHCI card
 *
 * Return Value:
 *  Return TRUE if card could be located and configured, otherwise FALSE
 */
static BOOL 
InitializeUHCI(
    SUhcdPdd * pPddObject,    // IN - Pointer to PDD structure
    LPCWSTR szDriverRegKey)   // IN - Pointer to active registry key string
{
    DWORD dwUseExistingSettings;
    PUCHAR ioPortBase = NULL;
    DWORD dwSysIntr, dwIRQ;
    BOOL fResult = FALSE;
    LPVOID pobMem = NULL;
    LPVOID pobUhcd = NULL;

    if (!GetRegistryConfig(&dwUseExistingSettings, &dwIRQ, (DWORD *)&ioPortBase)) {
        RETAILMSG(1,(TEXT("!UHCD: Error reading registry settings\r\n")));
        return FALSE;
    }
    DEBUGMSG(ZONE_INIT,(TEXT("UHCD: Read config from registry: Use existing: %u, IRQ: %u, I/O base: %X\r\n"),
                        dwUseExistingSettings,dwIRQ,ioPortBase));
    fResult   = ConfigureUHCICard(!!dwUseExistingSettings,&ioPortBase, &dwIRQ);

    if(fResult)
    {
        dwSysIntr = MapIrq2SysIntr(dwIRQ);
        DEBUGMSG(ZONE_INIT,(TEXT("UHCD: MapIrq2SysIntr(%u): %u\r\n"),dwIRQ,dwSysIntr));

        // The PDD can supply a buffer of contiguous physical memory here, or can let the 
        // MDD try to allocate the memory from system RAM.  In our case, let the MDD do it.
        pobMem = UhcdMdd_CreateMemoryObject(gcTotalAvailablePhysicalMemory, 
                                            gcHighPriorityPhysicalMemory, NULL,NULL); 

        if(pobMem)
        {
            pobUhcd = UhcdMdd_CreateUhcdObject(pPddObject, pobMem,
                    szDriverRegKey, ioPortBase, dwSysIntr);

            fResult = pobUhcd ? TRUE : FALSE;
        }
        else
            fResult = FALSE;

        if(!fResult)
        {
            if(pobUhcd)
                UhcdMdd_DestroyUhcdObject(pobUhcd);
            if(pobMem)
                UhcdMdd_DestroyMemoryObject(pobMem);

            pobUhcd = NULL;
            pobMem = NULL;
        }
    }

    pPddObject->lpvMemoryObject = pobMem;
    pPddObject->lpvUhcdMddObject = pobUhcd;

    return fResult;
}

/* UhcdPdd_Init
 *
 *   PDD Entry point - called at system init to detect and configure UHCI card.
 *
 * Return Value:
 *   Return pointer to PDD specific data structure, or NULL if error.
 */
extern DWORD 
UhcdPdd_Init(
    DWORD dwContext)  // IN - Pointer to context value. For device.exe, this is a string 
                      //      indicating our active registry key.
{
    SUhcdPdd *  pPddObject = malloc(sizeof(SUhcdPdd));
    BOOL        fRet = FALSE;

    fRet = InitializeUHCI(pPddObject, (LPCWSTR)dwContext);

    if(!fRet)
    {
        free(pPddObject);
        pPddObject = NULL;
    }

    return (DWORD)pPddObject;
}

/* UhcdPdd_CheckConfigPower
 *
 *    Check power required by specific device configuration and return whether it
 *    can be supported on this platform.  For CEPC, this is trivial, just limit to
 *    the 500mA requirement of USB.  For battery powered devices, this could be 
 *    more sophisticated, taking into account current battery status or other info.
 *
 * Return Value:
 *    Return TRUE if configuration can be supported, FALSE if not.
 */
extern BOOL UhcdPdd_CheckConfigPower(
    UCHAR bPort,         // IN - Port number
    DWORD dwCfgPower,    // IN - Power required by configuration
    DWORD dwTotalPower)  // IN - Total power currently in use on port
{
    return ((dwCfgPower + dwTotalPower) > 500) ? FALSE : TRUE;
}

extern void UhcdPdd_PowerUp(DWORD hDeviceContext)
{
    SUhcdPdd * pPddObject = (SUhcdPdd *)hDeviceContext;
    UhcdMdd_PowerUp(pPddObject->lpvUhcdMddObject);

    return;
}

extern void UhcdPdd_PowerDown(DWORD hDeviceContext)
{
    SUhcdPdd * pPddObject = (SUhcdPdd *)hDeviceContext;

    UhcdMdd_PowerDown(pPddObject->lpvUhcdMddObject);

    return;
}


extern BOOL UhcdPdd_Deinit(DWORD hDeviceContext)
{
    SUhcdPdd * pPddObject = (SUhcdPdd *)hDeviceContext;

    if(pPddObject->lpvUhcdMddObject)
        UhcdMdd_DestroyUhcdObject(pPddObject->lpvUhcdMddObject);
    if(pPddObject->lpvMemoryObject)
        UhcdMdd_DestroyMemoryObject(pPddObject->lpvMemoryObject);

    return TRUE;
}


extern DWORD UhcdPdd_Open(DWORD hDeviceContext, DWORD AccessCode,
        DWORD ShareMode)
{
    UnusedParameter(hDeviceContext);
    UnusedParameter(AccessCode);
    UnusedParameter(ShareMode);

    return 1; // we can be opened, but only once!
}


extern BOOL UhcdPdd_Close(DWORD hOpenContext)
{
    UnusedParameter(hOpenContext);

    return TRUE;
}


extern DWORD UhcdPdd_Read(DWORD hOpenContext, LPVOID pBuffer, DWORD Count)
{
    UnusedParameter(hOpenContext);
    UnusedParameter(pBuffer);
    UnusedParameter(Count);

    return (DWORD)-1; // an error occured
}


extern DWORD UhcdPdd_Write(DWORD hOpenContext, LPCVOID pSourceBytes,
        DWORD NumberOfBytes)
{
    UnusedParameter(hOpenContext);
    UnusedParameter(pSourceBytes);
    UnusedParameter(NumberOfBytes);

    return (DWORD)-1;
}


extern DWORD UhcdPdd_Seek(DWORD hOpenContext, LONG Amount, DWORD Type)
{
    UnusedParameter(hOpenContext);
    UnusedParameter(Amount);
    UnusedParameter(Type);

    return (DWORD)-1;
}


extern BOOL UhcdPdd_IOControl(DWORD hOpenContext, DWORD dwCode, PBYTE pBufIn,
        DWORD dwLenIn, PBYTE pBufOut, DWORD dwLenOut, PDWORD pdwActualOut)
{
    UnusedParameter(hOpenContext);
    UnusedParameter(dwCode);
    UnusedParameter(pBufIn);
    UnusedParameter(dwLenIn);
    UnusedParameter(pBufOut);
    UnusedParameter(dwLenOut);
    UnusedParameter(pdwActualOut);

    return FALSE;
}


// Manage WinCE suspend/resume events

// This gets called by the MDD's IST when it detects a power resume.
// The CEPC does not have power suspend/resume functionality so
// there's nothing we need to do beyond merely providing the entry point.
extern void UhcdPdd_InitiatePowerUp (void)
{
    return;
}
