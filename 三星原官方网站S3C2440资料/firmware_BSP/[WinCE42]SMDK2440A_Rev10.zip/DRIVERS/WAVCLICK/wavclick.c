//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//
/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.

Module Name:  

wavclick.c

Abstract:  

This file contains a template for implementing a click dll which can be
used to override the builtin click function and/or the builtin click
sounds.

If you simply want to change the wave files played for key or touch clicks,
then add your own ID_WAVE_???? resources in wavclick.rc.  The WC_PlayClick
function should be exported only if you waish to play the click sounds via
a different path than the normal wave driver.  For example, if your hardware
has a seperate audio circuit capable of simple sounds then it would be
possible to play clicks on that hardware without interrupting wave files
being played simultaneously on the wave hardware.

Functions:
DllEntry
WC_PlayClick  - Optional

Notes: 


--*/
#include <windows.h>
#include <types.h>
#include <memory.h>
#include <wavedev.h>


//
// @doc INTERNAL
// @func	BOOL | DllEntry | Process attach/detach api.
// *
// @rdesc The return is a BOOL, representing success (TRUE) or failure (FALSE).
//
BOOL
DllEntry(
	HINSTANCE	hinstDll,			  // @parm Instance pointer.
	DWORD	dwReason,				  // @parm Reason routine is called.
	LPVOID	lpReserved				  // @parm system parameter.
	)
{
    return TRUE;
}

//
// @doc INTERNAL
// @func	BOOL | WC_PlayClick | Alternative Click playing function.
// *
// @rdesc The return is a BOOL, representing success (TRUE) or failure (FALSE).
//
BOOL  
WC_PlayClick(
    WORD wClickType,     // Is this a touch or a key click
    WORD wClickVolume,   // Is it soft, loud, or muted
    DWORD dwResID        // What resource ID was read from the registry
    )
{

    
    DEBUGMSG(1,(TEXT("WC_PlayClick %d, %d,  %8.8X\n\r"),
                wClickType, wClickVolume, dwResID ));
    return TRUE;
}

