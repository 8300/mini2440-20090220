//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//
#define ID_WAVE_KEYLOUD             100
#define ID_WAVE_KEYSOFT             101
#define ID_WAVE_TCHLOUD             102
#define ID_WAVE_TCHSOFT             103
