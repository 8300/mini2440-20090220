/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
Copyright (c) 1995-2000 Microsoft Corporation.  All rights reserved.

Module Name:  

  drvsleep.c

Abstract:  

  This module contains the implementation of DriverSleep(), which
  is used when delays are needed within power handling routines, where
  no system calls are allowed.  The SH3 implementation polls the free
  running timer to implement a delay.
  
Functions:

  DriverSleep
  
Notes:

Revision History:

  Glenn Davis 4/1/97

--*/
#include <windows.h>
#include <p2.h>
#include <p2debug.h>

/*  DriverSleep
 *
 *  implement a busy-wait delay, for use by drivers
 *  during power handler functions.
 * 
 *  The following assumptions are made when calling from a power
 *  handler routine:
 *     -- Processor is in kernel mode (so we can access mem directly)
 *     -- We're non preemptible.  Otherwise, we'll get swapped out and
 *        delay could be longer than specified.
 */
void
DriverSleep(DWORD dwMS, BOOL bInPowerHandler)
{
    /*
     * If we're not in a power handler, use Sleep to block our
     * thread and let others run.  Note that Sleep() currently
     * is not very accurate for low values - the minimum sleep
     * interval is at least one system tick (25 ms).
     */
    if (!bInPowerHandler) {
        Sleep(dwMS);
        return;
     }

}
