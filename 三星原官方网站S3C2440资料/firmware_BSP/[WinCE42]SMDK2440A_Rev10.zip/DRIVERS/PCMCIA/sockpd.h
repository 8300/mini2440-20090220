/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
Copyright (c) 2002. Samsung Electronics, co. ltd  All rights reserved.

Module Name:  

Abstract:

    Platform dependent PCMCIA definitions for Intel 82365 compatible socket
    controller.

Rev:
	2001.12.12	: add S3C2400 Specific definitions (kwangyoon LEE, kwangyoon@samsung.com)

Notes: 
--*/

#define	PD6710									1

#define REG_CHIP_REVISION						0x00
#define REG_INTERFACE_STATUS					0x01
#define REG_POWER_CONTROL						0x02
#define REG_INTERRUPT_AND_GENERAL_CONTROL		0x03
#define REG_CARD_STATUS_CHANGE					0x04
#define REG_STATUS_CHANGE_INT_CONFIG			0x05
#define REG_WINDOW_ENABLE						0x06
#define REG_IO_WINDOW_CONTROL					0x07
#define REG_IO_MAP0_START_ADDR_LO				0x08
#define REG_IO_MAP0_START_ADDR_HI				0x09
#define REG_IO_MAP0_END_ADDR_LO					0x0A
#define REG_IO_MAP0_END_ADDR_HI					0x0B
#define REG_IO_MAP1_START_ADDR_LO				0x0C
#define REG_IO_MAP1_START_ADDR_HI				0x0D
#define REG_IO_MAP1_END_ADDR_LO					0x0E
#define REG_IO_MAP1_END_ADDR_HI					0x0F
#define REG_MEM_MAP0_START_ADDR_LO				0x10
#define REG_MEM_MAP0_START_ADDR_HI				0x11
#define REG_MEM_MAP0_END_ADDR_LO				0x12
#define REG_MEM_MAP0_END_ADDR_HI				0x13
#define REG_MEM_MAP0_ADDR_OFFSET_LO				0x14
#define REG_MEM_MAP0_ADDR_OFFSET_HI				0x15
#define REG_GENERAL_CONTROL						0x16

#ifdef	PD6710	
// PD6710 register
#define REG_FIFO_CTRL							0x17
#endif

#define REG_MEM_MAP1_START_ADDR_LO				0x18
#define REG_MEM_MAP1_START_ADDR_HI				0x19
#define REG_MEM_MAP1_END_ADDR_LO				0x1A
#define REG_MEM_MAP1_END_ADDR_HI				0x1B
#define REG_MEM_MAP1_ADDR_OFFSET_LO				0x1C
#define REG_MEM_MAP1_ADDR_OFFSET_HI				0x1D
#define REG_GLOBAL_CONTROL						0x1E
#define REG_CHIP_INFO							0x1F
#define REG_MEM_MAP2_START_ADDR_LO				0x20
#define REG_MEM_MAP2_START_ADDR_HI				0x21
#define REG_MEM_MAP2_END_ADDR_LO				0x22
#define REG_MEM_MAP2_END_ADDR_HI				0x23
#define REG_MEM_MAP2_ADDR_OFFSET_LO				0x24
#define REG_MEM_MAP2_ADDR_OFFSET_HI				0x25

#ifdef	PD6710	
// PD6710 register
#define REG_ATA_CTRL							0x26
#define REG_SCRATCHPAD							0x27
#endif

#define REG_MEM_MAP3_START_ADDR_LO				0x28
#define REG_MEM_MAP3_START_ADDR_HI				0x29
#define REG_MEM_MAP3_END_ADDR_LO				0x2A
#define REG_MEM_MAP3_END_ADDR_HI				0x2B
#define REG_MEM_MAP3_ADDR_OFFSET_LO				0x2C
#define REG_MEM_MAP3_ADDR_OFFSET_HI				0x2D

#ifdef	PD6710	
// PD6710 register
#define REG_EXTENDED_INDEX						0x2E
#define REG_EXTENDED_DATA						0x2F
#endif

#define REG_MEM_MAP4_START_ADDR_LO				0x30
#define REG_MEM_MAP4_START_ADDR_HI				0x31
#define REG_MEM_MAP4_END_ADDR_LO				0x32
#define REG_MEM_MAP4_END_ADDR_HI				0x33
#define REG_MEM_MAP4_ADDR_OFFSET_LO				0x34
#define REG_MEM_MAP4_ADDR_OFFSET_HI				0x35

#ifdef	PD6710	
#define REG_CARD_IO_MAP0_OFFSET_L 				0x36
#define REG_CARD_IO_MAP0_OFFSET_H 				0x37
#define REG_CARD_IO_MAP1_OFFSET_L 				0x38
#define REG_CARD_IO_MAP1_OFFSET_H 				0x39
#define REG_SETUP_TIMING0						0x3a
#define REG_CMD_TIMING0							0x3b
#define REG_RECOVERY_TIMING0					0x3c
#define REG_SETUP_TIMING1						0x3d
#define REG_CMD_TIMING1							0x3e
#define REG_RECOVERY_TIMING1					0x3f
#define REG_LAST_INDEX 							REG_RECOVERY_TIMING1
#else
#define REG_LAST_INDEX 							REG_MEM_MAP4_ADDR_OFFSET_HI
#endif
//
// Relative offsets for memory window control registers
//
#define REG_MEM_MAP_START_ADDR_LO				0x00
#define REG_MEM_MAP_START_ADDR_HI				0x01
#define REG_MEM_MAP_END_ADDR_LO					0x02
#define REG_MEM_MAP_END_ADDR_HI					0x03
#define REG_MEM_MAP_ADDR_OFFSET_LO				0x04
#define REG_MEM_MAP_ADDR_OFFSET_HI				0x05


//
// Interface status register 0x01
//
#define STS_BVD1								0x01
#define STS_BVD2								0x02
#define STS_CD1									0x04
#define STS_CD2									0x08
#define STS_WRITE_PROTECT						0x10
#define STS_CARD_READY							0x20
#define STS_CARD_POWER_ON						0x40
#define STS_GPI 								0x80

//
// Power and RESETDRV control register 0x02
//
#define PWR_VPP1_BIT0							0x01
#define PWR_VPP1_BIT1							0x02
#define PWR_VPP2_BIT0							0x04
#define PWR_VPP2_BIT1							0x08
#define PWR_VCC_POWER							0x10
#define PWR_AUTO_POWER 							0x20
#define PWR_RESUME_RESET						0x40
#define PWR_OUTPUT_ENABLE 						0x80

//
// Interrupt and general control register 0x03
//
#define INT_IRQ_BIT0							0x01
#define INT_IRQ_BIT1							0x02
#define INT_IRQ_BIT2							0x04
#define INT_IRQ_BIT3							0x08
#define INT_ENABLE_MANAGE_INT					0x10
#define INT_CARD_IS_IO 							0x20
#define INT_CARD_NOT_RESET 						0x40
#define INT_RING_INDICATE_ENABLE 				0x80

//
// Card Status change register 0x04
//
#define CSC_BATTERY_DEAD_OR_STS_CHG				0x01
#define CSC_BATTERY_WARNING						0x02
#define CSC_READY_CHANGE						0x04
#define CSC_DETECT_CHANGE						0x08
#define CSC_GPI_CHANGE							0x10

//
// Card Status change interrupt configuration register 0x05
//
#define CFG_BATTERY_DEAD_ENABLE					0x01
#define CFG_BATTERY_WARNING_ENABLE				0x02
#define CFG_READY_ENABLE 						0x04
#define CFG_CARD_DETECT_ENABLE					0x08
#define CFG_MANAGEMENT_IRQ_BIT0					0x10
#define CFG_MANAGEMENT_IRQ_BIT1					0x20
#define CFG_MANAGEMENT_IRQ_BIT2					0x40
#define CFG_MANAGEMENT_IRQ_BIT3					0x80

//
// Address window enable register 0x06
//
#define WIN_MEM_MAP0_ENABLE						0x01
#define WIN_MEM_MAP1_ENABLE 					0x02
#define WIN_MEM_MAP2_ENABLE						0x04
#define WIN_MEM_MAP3_ENABLE						0x08
#define WIN_MEM_MAP4_ENABLE						0x10
#define WIN_MEMCS16_DECODE						0x20
#define WIN_IO_MAP0_ENABLE						0x40
#define WIN_IO_MAP1_ENABLE						0x80

//
// I/O control register 0x07
//
#define ICR_0_IO_16BIT							0x01
#define ICR_0_IOCS16							0x02
#define ICR_0_ZERO_WAIT_STATE					0x04
#define ICR_0_WAIT_STATE						0x08
#define ICR_1_IO_16BIT							0x10
#define ICR_1_IOCS16							0x20
#define ICR_1_ZERO_WAIT_STATE					0x40
#define ICR_1_WAIT_STATE						0x80


//
// System memory address mapping start high byte register 0x11
// (also 0x19, 0x21, 0x29 and 0x31)
//
#define MSH_ZERO_WAIT_STATE						0x40
#define MSH_MEM_16BIT							0x80

//
// System memory address mapping stop high byte register 0x13
// (also 0x1B, 0x23, 0x2B and 0x33)
//
#define MTH_WAIT_STATE_BIT0						0x40
#define MTH_WAIT_STATE_BIT1						0x80

//
// Card memory offset address high byte register 0x15
// (also 0x1D, 0x25, 0x2D and 0x35)
//
#define MOH_REG_ACTIVE							0x40
#define MOH_WRITE_PROTECT						0x80

//
// MISC Control 1 register 0x16
//
#define MISC1_5V_DETECT							0x01
#define MISC1_VCC_33							0x02
#define MISC1_PM_IRQ							0x04
#define MISC1_PS_IRQ							0x08
#define MISC1_SPK_ENABLE						0x10
#define MISC1_INPACK_ENABLE						0x80

//
// FIFO Control register 0x17
//
#define FIFO_EMPTY_WRITE						0x80

//
// MISC Control 2 register  0x1E
//
#define MISC2_BFS								0x01
#define MISC2_LOW_POWER_MODE					0x02
#define MISC2_SUSPEND							0x04
#define MISC2_5V_CORE							0x08
#define MISC2_LED_ENABLE						0x10
#define MISC2_3STATE_BIT7						0x20
#define MISC2_IRQ15_RIOUT						0x80

//
// Identification and revision register 0x00
//
#define IRR_PCIC_VERSION_MASK					0x0F
#define IRR_PCIC_INTERFACE_ID0					0x40
#define IRR_PCIC_INTERFACE_ID1					0x80


//
// Define rate that we poll after RESET waiting for PC card to
// assert RDY.  Keep in mind that this only approximates the
// actual interval, as Sleep() may not be accurate.
//
#define PCMCIA_RDY_POLL_INT						50
#define PCMCIA_MAX_RDY_WAIT_TIME				2000

//
// Global data and functions
//
extern CRITICAL_SECTION g_PCIC_Crit;

extern VOID PCICIndex(UINT socket_num, UINT8 register_num);
extern VOID PCICDataWrite(UINT8 value);
extern UINT8 PCICDataRead(VOID);

#define SOCKET1_FIRST_MEMORY_WINDOW				5
#define SOCKET0_FIRST_IO_WINDOW					5
#define SOCKET1_FIRST_IO_WINDOW					7

#ifdef DEBUG
//
// Debug stuff
//

#define ZONE_PDD DEBUGZONE(8)

extern VOID DumpSocketRegisters(UINT socket);
extern VOID DeltaSocketRegisters(UINT socket);
#else
#define DumpSocketRegisters(socket)
#define DeltaSocketRegisters(socket)
#endif
