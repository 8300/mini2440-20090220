/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
Copyright (c) 2002. Samsung Electronics, co. ltd  All rights reserved.

Module Name:  

Abstract:  

   Platform dependent PCMCIA memory and I/O access functions

Rev:
	2001.12.21	: Debug messages (kwangyoon LEE, kwangyoon@samsung.com)
	   
Notes: 
--*/

#include <windows.h>
#include <types.h>
#include <cardserv.h>
#include <sockserv.h>
#include <sockpd.h>


//
// PDCardReadAttrByte
//
// @func    UINT8 | PDCardReadAttrByte | Read the byte at the specified offset in a card's
//                                       attribute memory space.
// @rdesc   Returns the byte read.
//
// @comm    This function should be called within a try/except statement in case the
// card is removed and the memory access results in a fault.  Card services calls
// PDCardReadAttrByte within a try/except clause in its <f CardReadAttrByte> function.
//
// @xref <f PDCardWriteAttrByte> <f PDCardReadCmnByte> <f PDCardWriteCmnByte>
//       <f PDCardReadIOByte> <f PDCardWriteIOByte>
//
UINT8
PDCardReadAttrByte(
    PVOID pCardMem,     // @parm Pointer to PC card attribute memory obtained from <f CardMapMemory>
    UINT32 uOffset      // @parm Offset into card's attribute memory
    )
{
    UINT8 uByte;
    PUCHAR pAttr = (PUCHAR)pCardMem;

    pAttr += uOffset * 2;
    uByte = *pAttr;
    return uByte;
}


//
// PDCardWriteAttrByte
//
// @func    VOID | PDCardWriteAttrByte | Write a byte to the specified offset in a card's
//                                       attribute memory space.
//
// @comm    This function should be called within a try/except statement in case the
// card is removed and the memory access results in a fault.  Card services calls
// PDCardWriteAttrByte within a try/except clause in its <f CardWriteAttrByte> function.
//
// @xref <f PDCardReadAttrByte> <f PDCardReadCmnByte> <f PDCardWriteCmnByte>
//       <f PDCardReadIOByte> <f PDCardWriteIOByte>
//
VOID
PDCardWriteAttrByte(
    PVOID pCardMem,     // @parm Pointer to PC card attribute memory obtained from <f CardMapMemory>
    UINT32 uOffset,     // @parm Offset into card's attribute memory
    UINT8 uByte         // @parm Byte to write
    )
{
    PUCHAR pAttr = (PUCHAR)pCardMem;

    pAttr += uOffset * 2;
    *pAttr = uByte;
}


//
// PDCardReadCmnByte
//
// @func    UINT8 | PDCardReadCmnByte | Read the byte at the specified offset in a card's
//                                       common memory space.
// @rdesc   Returns the byte read.
//
// @comm    This function should be called within a try/except statement in case the
// card is removed and the memory access results in a fault.  Card services calls
// PDCardReadCmnByte within a try/except clause in its <f CardReadCmnByte> function.
//
// @xref <f PDCardReadAttrByte> <f PDCardWriteAttrByte> <f PDCardWriteCmnByte>
//       <f PDCardReadIOByte> <f PDCardWriteIOByte>
//
UINT8
PDCardReadCmnByte(
    PVOID pCardMem,     // @parm Pointer to PC card common memory obtained from <f CardMapMemory>
    UINT32 uOffset
    )
{
    UINT8 uByte;
    volatile PUCHAR pCmn = (PUCHAR)pCardMem;

    pCmn += uOffset;
    uByte = *pCmn;
    return uByte;
}


//
// PDCardWriteCmnByte
//
// @func    VOID | PDCardWriteCmnByte | Write a byte to the specified offset in a card's
//                                       common memory space.
//
// @comm    This function should be called within a try/except statement in case the
// card is removed and the memory access results in a fault.  Card services calls
// PDCardWriteCmnByte within a try/except clause in its <f CardWriteCmnByte> function.
//
// @xref <f PDCardReadAttrByte> <f PDCardWriteAttrByte> <f PDCardReadCmnByte>
//       <f PDCardReadIOByte> <f PDCardWriteIOByte>
//
VOID
PDCardWriteCmnByte(
    PVOID pCardMem,     // @parm Pointer to PC card common memory obtained from <f CardMapMemory>
    UINT32 uOffset,     // @parm Offset into card's common memory
    UINT8 uByte         // @parm Byte to write
    )
{
    volatile PUCHAR pCmn = (PUCHAR)pCardMem;

    pCmn += uOffset;
    *pCmn = uByte;

	RETAILMSG(0, (TEXT("W:%x=%x[%x]\r\n"), pCmn, *pCmn, uByte));
}
