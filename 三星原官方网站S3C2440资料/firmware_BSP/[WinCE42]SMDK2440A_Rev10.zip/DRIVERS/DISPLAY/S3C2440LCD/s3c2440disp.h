/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
Copyright (c) 2001. Samsung Electronics, co. ltd  All rights reserved.

Module Name:  

Abstract:

	This file implements the S3C2440 LCD headers

rev:
	2002.4.4	: First S3C2410 version (kwangyoon LEE, kwangyoon@samsung.com)

	2002.1.31	: CE.NET port (kwangyoon LEE, kwangyoon@samsung.com)

Notes: 
--*/

#ifndef __S3C2440DISP_H__
#define __S3C2440DISP_H__


#ifdef ROTATE
class S3C2440DISP : public GPERotate
#else
class S3C2440DISP : public GPE
#endif //ROTATION
{
private:
	GPEMode			m_ModeInfo;
	DWORD			m_cbScanLineLength;
	DWORD			m_colorDepth;
	DWORD			m_VirtualFrameBuffer;
	DWORD			m_FrameBufferSize;
	BOOL			m_CursorDisabled;
	BOOL			m_CursorVisible;
	BOOL			m_CursorForcedOff;
	RECTL			m_CursorRect;
	POINTL			m_CursorSize;
	POINTL			m_CursorHotspot;
	UCHAR			*m_CursorBackingStore;
	UCHAR			*m_CursorXorShape;
	UCHAR			*m_CursorAndShape;

	volatile	struct lcdregs	*m_LCDRegs;
	volatile	struct gpioreg	*m_GPIORegs;

public:
					S3C2440DISP(void);
	virtual INT		NumModes(void);
	virtual SCODE	SetMode(INT modeId,	HPALETTE *palette);
	virtual INT		InVBlank(void);
	virtual SCODE	SetPalette(const PALETTEENTRY *source, USHORT firstEntry,
								USHORT numEntries);
	virtual SCODE	GetModeInfo(GPEMode *pMode,	INT modeNumber);
	virtual SCODE	SetPointerShape(GPESurf *mask, GPESurf *colorSurface,
									INT xHot, INT yHot, INT cX, INT cY);
	virtual SCODE	MovePointer(INT xPosition, INT yPosition);
	virtual void	WaitForNotBusy(void);
	virtual INT		IsBusy(void);
	virtual void	GetPhysicalVideoMemory(unsigned long *physicalMemoryBase, unsigned long *videoMemorySize);
	virtual SCODE	AllocSurface(GPESurf **surface, INT width, INT height,
									EGPEFormat format, INT surfaceFlags);
	virtual SCODE	Line(GPELineParms *lineParameters, EGPEPhase phase);
	virtual SCODE	BltPrepare(GPEBltParms *blitParameters);
	virtual SCODE	BltComplete(GPEBltParms *blitParameters);
	virtual ULONG	GetGraphicsCaps();
#if defined(CLEARTYPE) || defined(ROTATE)
	virtual ULONG   DrvEscape(
                        SURFOBJ *pso,
                        ULONG    iEsc,
                        ULONG    cjIn,
                        PVOID    pvIn,
                        ULONG    cjOut,
                        PVOID    pvOut);
#endif 
	SCODE			WrappedEmulatedLine (GPELineParms *lineParameters);
	void			CursorOn (void);
	void			CursorOff (void);

	void			InitializeHardware (void);
#ifdef ROTATE
	void SetRotateParms();
	LONG DynRotate(int angle);
#endif //ROTATION
};


#endif __S3C2440DISP_H__

