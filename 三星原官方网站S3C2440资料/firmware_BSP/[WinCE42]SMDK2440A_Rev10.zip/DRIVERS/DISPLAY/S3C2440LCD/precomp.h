/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
Copyright (c) 2001. Samsung Electronics, co. ltd  All rights reserved.

Module Name:  

Abstract:

	precompiled header files

rev:
	2002.4.4	: First S3C2410 version (kwangyoon LEE, kwangyoon@samsung.com)

	2002.1.31	: CE.NET port (kwangyoon LEE, kwangyoon@samsung.com)

Notes: 
--*/

#include	<windows.h>
#include	<types.h>
#include	<winddi.h>
#include	<gpe.h>
#include	<emul.h>

#include	<s2440.h>
#include	<s3c2440disp.h>

