
// Functions controlling the AC97 controller features


// Function prototypes Public Interface
// 
BOOL AC97_Init(void);						// Init the controller
BOOL AC97_Deinit(void);						// Deinit the controller 
void WriteCodecRegister(UCHAR Reg, USHORT Val);
USHORT ReadCodecRegister(UCHAR);
void AC97_InitCodec(void);
void Delay(USHORT);
