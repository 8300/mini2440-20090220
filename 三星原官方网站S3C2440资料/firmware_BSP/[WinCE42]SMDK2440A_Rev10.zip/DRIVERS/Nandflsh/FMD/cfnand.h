/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
Copyright (c) 2001  Microsoft Corporation

Module Name:	S3C2440.H

Abstract:		FLASH Media Driver Interface Samsung S3C2440 CPU with NAND Flash 
                controller.
  
Environment:	As noted, this media driver works on behalf of the FAL to directly
				access the underlying FLASH hardware.  Consquently, this module 
				needs to be linked with FLASHFAL.LIB to produce the device driver 
				named FLASHDRV.DLL.

-----------------------------------------------------------------------------*/
#ifndef _S3C2440_DEVBOARD_
#define _S3C2440_DEVBOARD_

//  Flash Chip Capability
//
#define NUM_BLOCKS                  0x1000       //  64 MB On-board NAND flash.
#define SECTOR_SIZE                 512
#define SPARE_SIZE                  16
#define PAGES_PER_BLOCK             32

#define LOG_2_PAGES_PER_BLOCK		5			// Used to avoid multiplications

//  For flash chip that is bigger than 32 MB, we need to have 4 step address
//
//  Since we are using 64 MB NAND flash on SMDK2440, define NAND_SIZE_GT_32MB
//
#define NAND_SIZE_GT_32MB

#ifdef NAND_SIZE_GT_32MB
#define NEED_EXT_ADDR               1
#else
#define NEED_EXT_ADDR               0
#endif

//  Initialization value for configuration register
#define NFCONF_INIT                 0xF850

//  NAND Flash Command. This appears to be generic across all NAND flash chips
#define CMD_READ                    0x00        //  Read
#define CMD_READ1                   0x01        //  Read1
#define CMD_READ2                   0x50        //  Read2
#define CMD_READID                  0x90        //  ReadID
#define CMD_WRITE                   0x80        //  Write phase 1
#define CMD_WRITE2                  0x10        //  Write phase 2
#define CMD_ERASE                   0x60        //  Erase phase 1
#define CMD_ERASE2                  0xd0        //  Erase phase 2
#define CMD_STATUS                  0x70        //  Status read
#define CMD_RESET                   0xff        //  Reset

//  Status bit pattern
#define STATUS_READY                0x40        //  Ready
#define STATUS_ERROR                0x01        //  Error

//  For fast read / write
#ifdef __cplusplus
extern "C"  {
#endif

void ReadPage512(BYTE *pBuf, PULONG pReg);
void WritePage512(BYTE *pBuf, PULONG pReg);

#ifdef __cplusplus
}
#endif


#endif _S3C2440_DEVBOARD_

