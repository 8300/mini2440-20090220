/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
Copyright (c) 2001. Samsung Electronics, co. ltd  All rights reserved.
--*/

#include <windows.h>
#include <nkintr.h>
#include <S2440.h>

#define     UART0BaudRate	115200
#define     UART1BaudRate	115200 //38400


/*
    @func   void | OEMInitDebugSerial | Initialize serial debug monitor port.
    @rdesc  N/A.
    @comm    
    @xref   
*/
void OEMInitDebugSerial(void) 
{
    volatile UART1reg   *s2440UART1	= (UART1reg *)UART1_BASE;
    volatile IOPreg     *s2440IOP	= (IOPreg *)IOP_BASE;
    
	// UART1 (TXD1 & RXD1) used for debug serial.
	//

	// Configure port H for UART.
	//
	s2440IOP->rGPHCON &= ~((3 << 8) | (3 << 10));	// Configure GPH2 and GHP3 for UART1 Tx and Rx, respectively.
	s2440IOP->rGPHCON |=  ((2 << 8) | (2 << 10));	//
	s2440IOP->rGPHUP  |=   (1 << 4) | (1 << 5);		// Disable pull-up on TXD1 and RXD1.

	// Configure UART.
	//
	s2440UART1->rUFCON  = 0x0;		// Disable the FIFO (TODO: do we need to enable the FIFO?)
	s2440UART1->rUMCON  = 0x0;		// Disable AFC.
	s2440UART1->rULCON  = 0x3;		// Normal mode, N81.
	s2440UART1->rUCON   = 0x245;	// Rx pulse interrupt, Tx level interrupt, Rx error status interrupt enabled.
	s2440UART1->rUBRDIV = ( (int)(S2440PCLK/16.0/UART1BaudRate + 0.5) -1 );		// Set up baudrate (38400).

}


/*****************************************************************************
*
*
*   @func   void    |   OEMWriteDebug | Display value to specified LED port.
*
*   The wIndex parameter can be used to specify a write to the discrete LEDS (if
*   0xffff), otherwise is used as an offset (DWORD aligned) for the Alpha LEDS
*   for triggering.
*/
void 
OEMWriteDebugLED(WORD wIndex, DWORD dwPattern)
{
	volatile	IOPreg *s2440IOP = (IOPreg * )IOP_BASE;

    // The S24x0X01 Eval platform supports 4 LEDs..
	//
    s2440IOP->rGPFDAT=(s2440IOP->rGPFDAT & 0xf) | ((dwPattern & 0xf)<<4);
}


/*****************************************************************************
*
*
*   @func   void    |   OEMWriteDebugString | Display string to the monitor port.
*
*   @parm   unsigned short * | str |
*           Points to the receiving buffer.
*/
void 
OEMWriteDebugString(unsigned short *str) 
{
	// Loop through text string, sending characters.
	//
    while (str && *str)
	{
        OEMWriteDebugByte((unsigned char)*str++);
	}
}

/*****************************************************************************
*
*
*   @func   void    |   OEMWriteDebugByte | Output byte to the monitor port.
*
*   @parm   unsigned char *| str |
*           Points to the output buffer.
*/
void 
OEMWriteDebugByte(UCHAR ch) 
{
    volatile UART1reg *s2440UART1	= (UART1reg *)UART1_BASE;

	// Wait for transmit buffer to be empty.
	//
	while(!(s2440UART1->rUTRSTAT & 0x2))
	{
	}

    s2440UART1->rUTXH = ch;
}


int
OEMReadDebugByte() 
{
    unsigned char ch;
    volatile UART1reg *s2440UART1 = (UART1reg *)UART1_BASE;
    
	// Any receive data for us?
	//
    if (!(s2440UART1->rUTRSTAT & 0x1))
	{
        ch = OEM_DEBUG_READ_NODATA;		// No data.
	}
    else
	{
        ch = s2440UART1->rURXH;			// Read character.
	}

    return (ch);
}


/*****************************************************************************
*
*
*   @func   void    |   OEMClearDebugComError | Clear a debug communications error
*
*/
void
OEMClearDebugCommError(void) 
{
	unsigned int ReadReg;
    volatile UART1reg *s2440UART1	= (UART1reg *)UART1_BASE;
    
	// Reading UART error status clears the status.
	//
	ReadReg=s2440UART1->rUERSTAT;
}


