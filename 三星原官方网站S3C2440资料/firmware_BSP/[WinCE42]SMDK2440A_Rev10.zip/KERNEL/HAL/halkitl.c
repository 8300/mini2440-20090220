/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
Copyright (c) 2001. Samsung Electronics, co. ltd  All rights reserved.

Module Name:  
    halkitl.c
    
Abstract:

    Platform specific code for KITL services.
    NOTE: this file is included from kernel\buildexe\kitlnokd\kitlnokd.c, NOT
          built as part of the hal.lib. The reason is to support dual build (KITL
          and non-KITL). Once we have all the tools supporting KITL, we may
          consider taking the original EDBG support out of the directory.

rev:
	2002.4.3	: First S3C2410 version (SOC)
	2002.1.28	: CE.NET port (kwangyoon LEE, kwangyoon@samsung.com)

Notes: 

--*/
#include <windows.h>
#include <nkintr.h>
#include <kitl.h>
#include <halether.h>
#include <kitlprot.h>
#include <p2.h>
#include <s2440.h>

#define LOG(x)  KITLOutputDebugString("%s == 0x%x\r\n", #x, x)
PKITLTRANSPORT gpKitl;

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
static void
itoa10(
    int n,
    char s[]
    )
{
    int i = 0; 

    // Get absolute value of number
    unsigned int val = (unsigned int)((n < 0) ? -n : n);

    // Extract digits in reverse order
    do {
        s[i++] = (val % 10) + '0';
    } while (val /= 10);

    // Add sign if number negative
    if (n < 0) s[i++] = '-';

    s[i--] = '\0';

    // Reverse string
    for (n = 0; n < i; n++, i--) {
        char swap = s[n];
        s[n] = s[i];
        s[i] = swap;
    }
}

//#define PLATFORM_STRING  "SMDK2410"
#define PLATFORM_STRING  "SMDK2440"

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
void
CreateDeviceName(EDBG_ADDR *pMyAddr, char *szBuf)
{
    strcpy(szBuf,PLATFORM_STRING);
    szBuf += strlen(szBuf);
    itoa10(((pMyAddr->wMAC[2]>>8) | ((pMyAddr->wMAC[2] & 0x00ff) << 8)), szBuf);
}

void InitDebugEther(void)
{
    // Initialize KITL transport
    if (KitlInit(TRUE)) {
        KITLOutputDebugString ("KITL Initialized\n");
        // no longer need to start kernel services
        // since KITL config message told us what to start and
        // kitl will start it accordingly
//        if (gpKitl->dwBootFlags & KITL_FL_DBGMSG)
//            SetKernelCommDev (KERNEL_SVC_DBGMSG, KERNEL_COMM_ETHER);
//        if (gpKitl->dwBootFlags & KITL_FL_PPSH)
//            SetKernelCommDev (KERNEL_SVC_PPSH, KERNEL_COMM_ETHER);
//        if (gpKitl->dwBootFlags & KITL_FL_KDBG)
//            SetKernelCommDev (KERNEL_SVC_KDBG, KERNEL_COMM_ETHER);
    } else {
        KITLOutputDebugString ("KITL Initialization Failed, No debugging support available\n");
    }
}

BOOL InitParallelSerial (PKITLTRANSPORT pKitl)
{
    return FALSE;
}

void
KitlEthEnableInts(BOOL bEnable)
{
    if (bEnable) 
        OEMEthEnableInts();
    else 
        OEMEthDisableInts();
}


static EDBG_ADDR MyAddr;

static BOOL GetDevCfg (LPBYTE pBuf, PUSHORT pcbBuf)
{
    // put our IP info in the buffer
    if (*pcbBuf < sizeof (MyAddr)) {
        return FALSE;
    }
        
    memcpy (pBuf, &MyAddr, sizeof (MyAddr));
    *pcbBuf = sizeof (MyAddr);
    return TRUE;
}

static BOOL SetHostCfg (LPBYTE pData, USHORT cbData)
{
    // we automatically figure out the host address info during initial 
    // handshake. No need to handle host cfg data here.
    return TRUE;
}

static BOOL EthSend (LPBYTE pData, USHORT cbData)
{
    return OEMEthSendFrame (pData, cbData);
}
    
/* InitEther
 *
 *  Initialize KITL Ether transport. The Odo platform uses a debug board 
 *  based on the SMC 91C94 Ethernet controller.
 *
 *  Return Value:
 *    Return TRUE if init is successful, FALSE if error.
 */
BOOL InitEther(PKITLTRANSPORT pKitl)
{
    EDBG_ADAPTER adp;
    DWORD dwDHCPLeaseTime;
    DWORD dwSubnetMask;

    KITLOutputDebugString ("+InitEther\n");

    memset (&adp, 0, sizeof(adp));
    memset (pKitl, 0, sizeof (KITLTRANSPORT));

    // use existing code for ether initialization
    if (!OEMEthInit (&adp))
        return FALSE;

    // we are going to completely ignore the info in bootargs and the adaptor info
    // returned from OEMEthInit, except MAC address. Just to prove that KITL will connect standalone

    // get the MAC address
    MyAddr.wMAC[0] = adp.Addr.wMAC[0];
    MyAddr.wMAC[1] = adp.Addr.wMAC[1];
    MyAddr.wMAC[2] = adp.Addr.wMAC[2];
    //MyAddr = adp.Addr;
    
    CreateDeviceName(&MyAddr, pKitl->szName);
    KITLOutputDebugString ("Using device name: %s\n", pKitl->szName);

    // If we haven't been given an IP address from our loader (or if we're not using static IP), get an IP address
    // from a DHCP server.
    if (adp.Addr.dwIP)
    {
        // Static IP or we got the IP from our bootloader...
        MyAddr.dwIP     = adp.Addr.dwIP;
        dwSubnetMask    = 0;    // Don't care about subnet mask...
        dwDHCPLeaseTime = adp.DHCPLeaseTime;
    }
    else
    {
        // Get a DHCP address...
        if (!EbootGetDHCPAddr (&MyAddr, &dwSubnetMask, &dwDHCPLeaseTime))
            return FALSE;
    }
    
    MyAddr.wPort = htons (EDBG_SVC_PORT);
    KITLOutputDebugString ("Device %s, IP %s, Port %d\n", pKitl->szName, inet_ntoa (MyAddr.dwIP), htons (MyAddr.wPort));

    // initialize KITL Ethernet transport layer
    if (!KitlEtherInit (&MyAddr, dwDHCPLeaseTime)) {
        KITLOutputDebugString ("Unable to initialize KITL Ether transport\n");
        return FALSE;
    }
    
    // fill in the blanks in KITLTRANSPORT structure.
    pKitl->FrmHdrSize = KitlEtherGetFrameHdrSize ();
    pKitl->Interrupt = (UCHAR) adp.SysIntrVal;
    pKitl->dwPhysBuffer = EDBG_PHYSICAL_MEMORY_START;
    pKitl->dwPhysBufLen = 0x20000;                      // 128K of buffer available
    pKitl->dwBootFlags = 0;
    pKitl->WindowSize = EDBG_WINDOW_SIZE;
    pKitl->pfnDecode = KitlEtherDecodeUDP;
    pKitl->pfnEncode = KitlEtherEncodeUDP;
    pKitl->pfnSend = EthSend;
    pKitl->pfnRecv = OEMEthGetFrame;
    pKitl->pfnEnableInt = KitlEthEnableInts;
    pKitl->pfnSetHostCfg = SetHostCfg;
    pKitl->pfnGetDevCfg = GetDevCfg;

    KITLOutputDebugString ("-InitEther\n");


    return TRUE;
}


/* OEMKitlInit
 *
 *  Initialization routine - called from KitlInit() to perform platform specific
 *  HW init.
 *
 *  Return Value:
 *    Return TRUE if init is successful, FALSE if error.
 */
BOOL OEMKitlInit (PKITLTRANSPORT pKitl)
{
    KITLOutputDebugString ("+OEMKitlInit\n");
    RETAILMSG(1, (_T("+OEMKitlInit\r\n")));
    // try to find a transport available
    if (!InitEther (pKitl) 
        && !InitParallelSerial (pKitl)) {
        KITLOutputDebugString ("Unable to initialize KITL Transports!\n");
        return FALSE;
    }

    gpKitl = pKitl;
    KITLOutputDebugString ("-OEMKitlInit\n");
    RETAILMSG(1, (_T("-OEMKitlInit\r\n")));
    return TRUE;
}

