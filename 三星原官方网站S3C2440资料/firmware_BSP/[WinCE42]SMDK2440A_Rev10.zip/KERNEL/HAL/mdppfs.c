/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
Copyright (c) 2001. Samsung Electronics, co. ltd  All rights reserved.

Module Name:  

Abstract:

 	This file implements the NK kernel ppfs client side interface

rev:
	2002.4.3	: First S3C2410 version (SOC)
	2002.1.28	: CE.NET port (kwangyoon LEE, kwangyoon@samsung.com)

Notes: 
--*/

#include "windows.h"
#include "p2debug.h"

/*
 * Write register in bits 0-7
 * Read register in bits 8-15
 * Control bits (msw only)
 *
 * This side:
 * 0x8000  - Data byte ready (tx)
 * 0x0800  - Ack to ack (noticed other side's ack)
 * 0x2000  - Waiting for byte (rx)
 * Other side:
 * 0x0002  - Ack (noticed this side's byte)
 * 0x0010  - Data byte ready (rx)
 */

typedef volatile DWORD *PVDWORD;    /* pointer to a volatile dword */

BOOL NoPPFS = FALSE;					// parallel port disconnected flag

//***************************************************************************
// OEMParallelPortGetByte - Get byte from parallel port
//
// Input -	none
// Ouput -	if parallel port disconnected, set NoPPFS=TRUE and returns -1
//			else returns byte received from parallel port
//***************************************************************************
int OEMParallelPortGetByte(void)
{
	return -1;
}

//***************************************************************************
// OEMParallelPortSendByte - send byte out parallel port
//
// Input -	chData=byte to send
//
// Output -	sets NoPPFS=TRUE if parallel port disconnected
//***************************************************************************
VOID OEMParallelPortSendByte(BYTE chData)
{
}
