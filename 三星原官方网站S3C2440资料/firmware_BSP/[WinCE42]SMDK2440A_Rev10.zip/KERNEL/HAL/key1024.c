/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
Copyright (c) 2001. Samsung Electronics, co. ltd  All rights reserved.

Module Name:  

Abstract:

    Debug routines

rev:
	2002.4.3	: First S3C2410 version (SOC)
	2002.1.28	: CE.NET port (kwangyoon LEE, kwangyoon@samsung.com)

Notes:
	This file is only needed if run-time DLL and EXE signature checking is turned on. 
	The public key below should correspond to the private key used to sign the
	executables
--*/

const unsigned char g_bSignPublicKeyBlob[] = {
    0x06,0x02,0x00,0x00,0x00,0x24,0x00,0x00,0x52,0x53,0x41,0x31,0x00,0x04,0x00,0x00,
    0x01,0x00,0x01,0x00,0x51,0xea,0xee,0xba,0x4f,0xe6,0xf4,0x87,0x44,0x7e,0x88,0xb7,
    0x70,0x9d,0x05,0xf2,0xe2,0x91,0x08,0xb9,0x92,0x95,0xa7,0x76,0xe2,0xd2,0xc1,0x5a,
    0x3b,0x0f,0x38,0x0a,0x5f,0x99,0xde,0x5c,0xa0,0x36,0xd3,0x03,0xca,0xd3,0x3e,0x81,
    0xea,0x8d,0x60,0x43,0x12,0x21,0xf2,0x8f,0x81,0x26,0x78,0xe3,0x51,0x22,0x0b,0xee,
    0x6c,0x63,0x2e,0xa8,0xf6,0x6c,0xbc,0xa1,0x41,0x03,0xf7,0xb6,0x84,0x29,0x46,0xe7,
    0xfd,0xd7,0x33,0xf6,0x86,0xeb,0x08,0xe1,0x50,0xb0,0x81,0xbf,0xa2,0x91,0x6a,0xcd,
    0xd0,0x32,0xb6,0x9a,0x5b,0x51,0x85,0xdd,0xab,0x90,0x17,0x9a,0xcd,0x64,0x1c,0x48,
    0x16,0xc3,0xb4,0x03,0xa1,0xa7,0x15,0xf6,0x6f,0x29,0x0e,0xf7,0x87,0xda,0xc0,0x59,
    0x55,0x0c,0x84,0x87
};

typedef BOOL (* OEMLoadInit_t)(LPWSTR lpszName);
typedef DWORD (* OEMLoadModule_t)(LPBYTE lpData, DWORD cbData);

// The following two kernel function pointers should be initialized in the OAL
extern OEMLoadInit_t pOEMLoadInit;      // implemented by OEMLoadInit()
extern OEMLoadModule_t pOEMLoadModule;  // implemented by OEMLoadModule()


// LoadAuth library routines
extern BOOL InitPubKey(const BYTE *KeyBlob, DWORD cbKeyBlob);
extern BOOL CertifyModuleInit(void);
extern BOOL CertifyModule(PBYTE pbBlock, DWORD cbBlock);
extern BOOL CertifyModuleFinal(PBYTE *ppbSignData, PDWORD pcbSignData);

// called once for each RAM executable module, to initialize signature checking
BOOL OEMLoadInit(LPWSTR lpszName)
{
    return CertifyModuleInit();
}

// called one or more times after OemLoadInit
DWORD OEMLoadModule(LPBYTE lpData, DWORD cbData)
{
    if (cbData)
    {
        // process module bytes
        return CertifyModule(lpData, cbData);
    }
    else
    {
        // final call
        DWORD dwTrustLevel = OEM_CERTIFY_FALSE;
        LPBYTE pSignedData;
        DWORD cbSignedData;
        BOOL fRet = CertifyModuleFinal(&pSignedData, &cbSignedData);
        if (fRet)
        {
            // the file has a valid signature
            // we expect the trust level to be returned as signed data
            if (cbSignedData < sizeof(CHAR))
                fRet = FALSE;
            else
            switch (*pSignedData)
            {
                case 'T' :
                    dwTrustLevel = OEM_CERTIFY_TRUST;
                    break;
                case 'R' :
                    dwTrustLevel = OEM_CERTIFY_RUN;
                    break;
                default:
                    dwTrustLevel = OEM_CERTIFY_FALSE;
                    break;
            }
        }
        #ifdef DEBUG
        if (!fRet)
	        lpWriteDebugStringFunc(TEXT("OEMLoadModule:signature check failed.\r\n"));
        #endif

        // return one of the OEM_CERTIFY levels
        return dwTrustLevel;
    }
}

