/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
Copyright (c) 2001. Samsung Electronics, co. ltd  All rights reserved.

Module Name:  

Abstract:
	
	OEM Debug Serial Monitor Routines

rev:
	2002.4.3	: first S3C2410 version (SOC)
	2002.1.28	: CE.NET initial port (kwangyoon LEE, kwangyoon@samsung.com)
	
Notes: 
--*/

#include <windows.h>
#include "p2.h"

///#define USE_DEC_UART 1

#undef SYSTEM_ASIC_REGS_BASE
//#undef DMA_BUFFER_BASE
#define SYSTEM_ASIC_REGS_BASE	0x20000000
//#define DMA_BUFFER_BASE			0xC7000000

#define READ_REGISTER_ULONG(reg) (*(volatile unsigned long * const)(reg))
#define WRITE_REGISTER_ULONG(reg, val) (*(volatile unsigned long * const)(reg)) = (val)
#define READ_REGISTER_USHORT(reg) (*(volatile unsigned short * const)(reg))
#define WRITE_REGISTER_USHORT(reg, val) (*(volatile unsigned short * const)(reg)) = (val)
#define READ_REGISTER_UCHAR(reg) (*(volatile unsigned char * const)(reg))
#define WRITE_REGISTER_UCHAR(reg, val) (*(volatile unsigned char * const)(reg)) = (val)

// DMA buffers for the HAL's serial port.

#define DMA_PAGE_SIZE 0x800

// Warning: when written to the DMA registers, the high 6 bits (31:26)
// will be read as all zeros.
#define DMA_RX_PAGE      DMA_BUFFER_BASE+0x2000
#define DMA_TX_PAGE      (DMA_RX_PAGE + 2 * DMA_PAGE_SIZE)


#define pCSRA (DEBUG_SER_BASE + SER_CSR_A)
#define pCSRB (DEBUG_SER_BASE + SER_CSR_B)

extern void WhereAmI(void);
//extern void ShowValue(int value);



/*****************************************************************************
*
*
*   @func   void    |   OEMInitDebugSerial | Initialize debug monitor port.
*
*   NOTE: This function MUST NOT use any global variables!!!!!!
*/
void InitSerial(void) 
{

}


// Define UART physical register.
#define     phUTRSTAT0      (*(volatile unsigned int *)0x15000010)
#define     phUTXH0         (*(volatile unsigned char *)0x15000020)

/*****************************************************************************
*
*
*   @func   void    |   OEMWriteDebugByte | Output byte to the monitor port.
*
*   @parm   unsigned char *| str |
*           Points to the output buffer.
*/
void 
WriteByte(UCHAR ch) 
{
#if 1
    int i;

    if(ch == '\n')  {
        while(!(phUTRSTAT0 & 0x2)) ;
	    for(i=0; i<0x100; i++) ;//because the slow response of hyper_terminal 
	    phUTXH0 = '\r';
	}
	while(!(phUTRSTAT0 & 0x2)); //Wait until THR is empty.
    for(i=0; i<0x100; i++) ;
    phUTXH0 = ch;
    
#endif    
}

/*****************************************************************************
*
*
*   @func   void    |   OEMWriteDebugString | Display string to the monitor port.
*
*   @parm   unsigned short * | str |
*           Points to the receiving buffer.
*/

void 
WriteString(unsigned char *str) {
    // Send message to serial port
    while (*str)
        WriteByte(*str++);
}


void WriteHex(long *ptr, int length)
{
#if 0 // jlsfix - stub for now
    int count;

    for (count = 0 ; count < length ; ++count) {
        if ((count & 7) == 0) {
            WriteByte('\r');
            WriteByte('\n');
            PutHex((long)ptr);
            WriteByte(':');
        }
        WriteByte(' ');
        PutHex(*ptr++);
    }   
    WriteByte('\r');
    WriteByte('\n');
#endif
}

