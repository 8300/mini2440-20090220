/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
Copyright (c) 2001. Samsung Electronics, co. ltd  All rights reserved.

Module Name:  

Abstract:

	ARM920(S3C2440) interrupt service routine

rev:
	2002.4.3	: first S3C2410 version (SOC)	

	2002.2.5	: system tick modification (kwangyoon LEE, kwangyoon@samsung.com)	
					- one shot timer
	2002.1.29	: bug fixups (kwangyoon LEE, kwangyoon@samsung.com)	
					- system tick interrupt
	2002.1.28	: CE.NET port (kwangyoon LEE, kwangyoon@samsung.com)
	2002.1.22	: Add USBD interrupt (kwangyoon LEE, kwangyoon@samsung.com)

Notes: 
--*/

#include <windows.h>
#include <nkintr.h>
#include <oalintr.h>
#include "p2.h"
#include "p2debug.h"
#include "drv_glob.h"

#include <S2440.h>

#define SDIO_FOR_100BD	0

extern DWORD CurMSec;
extern DWORD DiffMSec;

#if (CE_MAJOR_VER == 0x0003)
	extern DWORD ticksleft, dwSleepMin, dwPreempt;
	extern DWORD DiffMSec;
#else
	extern DWORD dwReschedTime;
#endif

extern DWORD AlarmTime;
extern volatile LARGE_INTEGER CurTicks;
extern DWORD dwReschedIncrement;
extern int (*PProfileInterrupt)(void);

extern DWORD dwIsrTime1, dwIsrTime2;
extern BOOL fIntrTime, fIntrTimeToggle;
extern WORD wNumInterrupts;    // Reset by a read of the ISR times from the IST
extern DWORD dwIntrTimeCountdown;
extern DWORD dwIntrTimeCountdownRef;
extern DWORD dwSPC;
extern DWORD PerfCountSinceTick();
extern BOOL fInterruptFlag;
extern VOID CPUPowerReset();
extern VOID OEMEmergencyPowerOff();


static USBD_GLOBALS *usbdShMem=&((DRIVER_GLOBALS *)DRIVER_GLOBALS_PHYSICAL_MEMORY_START)->usbd; //:-)
void UsbdClearEir(void);  //:-)

DWORD OEMTranslateIrq(DWORD dwIrq)
{
    return dwIrq;
}
DWORD OEMTranslateSysIntr(DWORD SysIntr)
{
    return (SysIntr<SYSINTR_FIRMWARE?(DWORD)-1:SysIntr);
}

void OEMInterruptHandlerFIQ() 
{
	// This FIQ interrupt is from BAT_FLT.
	volatile IOPreg *s2440IOP = (IOPreg *)IOP_BASE;
	volatile INTreg *s2440INT = (INTreg *)INT_BASE;

	s2440IOP->rGPFDAT = ~(0xa << 4);   /* LED Off */
	OEMEmergencyPowerOff();
	while(1);
//	RETAILMSG(1, (TEXT(">>> OEMInterruptHandlerFIQ \r\n")));
}


int flag = 1;
unsigned int tCnt = 0;
unsigned int ttt = 0;



int OEMInterruptHandler(unsigned int ra) 
{
	static BYTE nLED = 0x1;
	volatile INTreg *s2440INT = (INTreg *)INT_BASE;
	volatile IOPreg *s2440IOP = (IOPreg *)IOP_BASE;
	volatile PWMreg *s2440PWM = (PWMreg *)PWM_BASE;
	volatile MMCreg *s2440SDIO = (MMCreg *)MMC_BACE;

	unsigned int IntPendVal;
	unsigned int SubIntPendVal;	// for serial
	DWORD			submask;

	// jylee
	volatile ADCreg *s2440ADC = (ADCreg *)ADC_BASE;

	static DWORD HeartBeatCnt, HeartBeatStat;
	static volatile struct udcreg *s2440USBD = (volatile struct udcreg *)(0xB1200140); // 0xB1200140
	volatile BYTE usbd_eir = 0, usbd_uir = 0;

    TOUCH_GLOBALS *odo_tsb;  //Sample buffer stuff
    // for this, You MUST modify bsp/inc/drv_glob.h.. check drv_glob.h_jylee
    odo_tsb = &((DRIVER_GLOBALS *)DRIVER_GLOBALS_PHYSICAL_MEMORY_START)->tch;

	// Update LEDs.
	//
//	if (nLED++ > 0xf) nLED = 0;
//	OEMWriteDebugLED(0, ~nLED);
    
	IntPendVal = s2440INT->rINTOFFSET;	// Get pending IRQ mode interrupt in INTPND.
    
	// Fake CPUEnterIdle needs to know about interrupt firing.
	fInterruptFlag = TRUE;

    if (fIntrTime) {
        //
        // We're doing interrupt timing. Get Time to ISR. We subtract TIMER_COUNTDOWN
        // here because the compare register has not been updated.
        //
        dwIsrTime1 = PerfCountSinceTick() - dwReschedIncrement;
        dwSPC = ra;
        wNumInterrupts++;
    }

	//
	// Check the timer interrupt.
	//
	if (IntPendVal == INTSRC_TIMER4) 
	{
		DWORD ttmp;

        if (++HeartBeatCnt > 10)
        {
            HeartBeatCnt   = 0;
            HeartBeatStat ^= 1;

            if (HeartBeatStat)                        
                s2440IOP->rGPFDAT &= ~(1 << 4); /* LED 0 On                 */
            else
                s2440IOP->rGPFDAT |=  (1 << 4); /* LED 0 Off                */
        }
                             
		s2440PWM->rTCNTB4 = dwReschedIncrement;
                             
		ttmp = s2440PWM->rTCON & (~(0xf << 20));
                             
		s2440PWM->rTCON = ttmp | (2 << 20);		/* update TCVNTB4, stop					*/
		s2440PWM->rTCON = ttmp | (1 << 20);		/* one-shot mode,  start				*/
                             
		// Update the tick counter.
		//
		CurTicks.QuadPart += dwReschedIncrement;
                                     
		// Call the profile ISR if it's enabled.
		//
        if (PProfileInterrupt)
        {
			DWORD dwRetVal = SYSINTR_NOP;

			dwRetVal = PProfileInterrupt();
            if (dwRetVal == SYSINTR_RESCHED)
			{
				// Update the millisecond counter.
				//
				CurMSec  += RESCHED_PERIOD;
#if (CE_MAJOR_VER == 0x0003)
                DiffMSec += RESCHED_PERIOD;
#endif
            }

			// Clear the interrupt
			//
			s2440INT->rSRCPND = BIT_TIMER4;        
			if (s2440INT->rINTPND & BIT_TIMER4) s2440INT->rINTPND = BIT_TIMER4;

            // Return whatever we got back from the profiling ISR.
			//
            return(dwRetVal);
        }

		// Update the millisecond counter.
		//
#if (CE_MAJOR_VER == 0x0003)
		DiffMSec += RESCHED_PERIOD;
#endif
		CurMSec  += RESCHED_PERIOD;

		//
		// Clear the interrupt
		//
		s2440INT->rSRCPND = BIT_TIMER4;        
		if (s2440INT->rINTPND & BIT_TIMER4) s2440INT->rINTPND = BIT_TIMER4;
                             		
		if (fIntrTime) 
		{
			//
			// We're doing interrupt timing. Every other tick is a RESCHED.
			//
			dwIntrTimeCountdown--;
                                                                          
			if (dwIntrTimeCountdown == 0) 
			{
				dwIntrTimeCountdown = dwIntrTimeCountdownRef;
				wNumInterrupts = 0;
                                                                              
				dwIsrTime2 = PerfCountSinceTick();
				return (SYSINTR_TIMING);
			} else {
#if (CE_MAJOR_VER == 0x0003)
				if (ticksleft || (dwSleepMin && (dwSleepMin <= DiffMSec)) || (dwPreempt && (dwPreempt <= DiffMSec)))
#else
				if ((int) (CurMSec - dwReschedTime) >= 0)
#endif
					return(SYSINTR_RESCHED);
			}    
		} else {
#if (CE_MAJOR_VER == 0x0003)
			if (ticksleft || (dwSleepMin && (DiffMSec >= dwSleepMin)) || (dwPreempt && (DiffMSec >= dwPreempt)))
#else
			if ((int) (CurMSec - dwReschedTime) >= 0)
#endif
                             
			{
				return(SYSINTR_RESCHED);
			}
			return(SYSINTR_NOP);
		}
	} 

	else if(IntPendVal == INTSRC_MMC)	// SD, MMC
	{
		s2440INT->rINTMSK |= BIT_MMC;
        s2440INT->rSRCPND = BIT_MMC;        
        if (s2440INT->rINTPND & BIT_MMC) s2440INT->rINTPND = BIT_MMC;
//		RETAILMSG(1, (TEXT("ARMINT.C-INT:INTSRC_MMC INT\r\n")));
		if( s2440SDIO->rSDIDATSTA & (0x1<<9) ){
			// RETAILMSG(1, (TEXT("INT:SYSINTR_SDMMC_SDIO_INTERRUPT INT\r\n")));
			return SYSINTR_SDMMC_SDIO_INTERRUPT;
		}
		else {
			// RETAILMSG(1, (TEXT("INT:SYSINTR_SDMMC INT\r\n")));
			return SYSINTR_SDMMC;
		}
	}	
	else if(IntPendVal == INTSRC_DMA0)	// SD DMA interrupt
	{
		s2440INT->rINTMSK |= BIT_DMA0;
		s2440INT->rSRCPND = BIT_DMA0;
		if (s2440INT->rINTPND & BIT_DMA0) s2440INT->rINTPND = BIT_DMA0;
		return SYSINTR_DMA0;
	}
	
	else if (IntPendVal == INTSRC_EINT1)	// Keyboard interrupt is connected to EINT1.
	{ 
		s2440INT->rINTMSK |= BIT_EINT1;
		s2440INT->rSRCPND  = BIT_EINT1;        
		if (s2440INT->rINTPND & BIT_EINT1) s2440INT->rINTPND  = BIT_EINT1;

		return(SYSINTR_KEYBOARD);

	} 
	
	else if (IntPendVal == INTSRC_EINT2)	// EINT2
	{ 
		s2440IOP->rGPBCON &= ~(3<<18);
		s2440IOP->rGPBCON |=  (1<<18);
		s2440IOP->rGPBUP  |=  (1<<9);
		s2440IOP->rGPBDAT &= ~(1<<9);

		s2440INT->rINTMSK |= BIT_EINT2;
		s2440INT->rSRCPND  = BIT_EINT2;	/* Interrupt Clear				*/
		if (s2440INT->rINTPND & BIT_EINT2) s2440INT->rINTPND  = BIT_EINT2;
//		RETAILMSG(1, (TEXT(">>> CPUPowerReset \r\n")));
		//RETAILMSG(1,(TEXT(">>> >>> Reset Button Pressed <<< <<< \r\n")));
		CPUPowerReset();

		return(SYSINTR_POWER);
	}
	else if (IntPendVal == INTSRC_EINT3)	// PCMCIA interrupt is connected to EINT3. (nINT_P_DEV)
	{ 
   		s2440INT->rINTMSK |= BIT_EINT3;
   		s2440INT->rSRCPND  =  BIT_EINT3;        
   		if (s2440INT->rINTPND & BIT_EINT3) s2440INT->rINTPND = BIT_EINT3;
                           
   		return(SYSINTR_PCMCIA_STATE);
	}  
	else if (IntPendVal == INTSRC_EINT8_23)		// EINT8 ~ 23
	{ 

		s2440INT->rINTMSK |= BIT_EINT8_23;	
		submask = s2440IOP->rEINTPEND;

		//DWORD dwSubMask = s2440IOP->rEINTPEND & (~s2440IOP->rEINTMASK);

		if ( submask & (1 << 9))	// 0x200 EINT9 : CS8900
		{
			s2440IOP->rEINTMASK |= 0x200;
			s2440IOP->rEINTPEND = 0x200;

			s2440INT->rSRCPND = BIT_EINT8_23;        
			if (s2440INT->rINTPND & BIT_EINT8_23) s2440INT->rINTPND = BIT_EINT8_23;

			// RETAILMSG(1, (TEXT("INT:SYSINTR_ETHER INT s2440IOP->rEINTMASK = 0x%8x, s2440IOP->rEINTMASK\r\n")));
			// RETAILMSG(1, (TEXT("INT:SYSINTR_ETHER INT s2440IOP->rEINTPEND = 0x%8x, s2440IOP->rEINTPEND\r\n")));
			return SYSINTR_ETHER;
		}

#if SDIO_FOR_100BD	// for b'd revision 1.00
		if ( submask & (1 << 18)) // EINT28 : SDMMC_CARD_DETECT
		{
			s2440IOP->rEINTMASK |= (1 << 18);
			s2440IOP->rEINTPEND  = (1 << 18);
			s2440INT->rSRCPND  = BIT_EINT8_23;
			if (s2440INT->rINTPND & BIT_EINT8_23) 
				s2440INT->rINTPND = BIT_EINT8_23;

			// RETAILMSG(1, (TEXT("ARMINT.C - SYSINTR_SDMMC_CARD_DETECT rEINTMASK = 0x%8x, s2440IOP->rEINTMASK\r\n")));
			// RETAILMSG(1, (TEXT("ARMINT.C - SYSINTR_SDMMC_CARD_DETECT rEINTPEND = 0x%8x, s2440IOP->rEINTPEND\r\n")));			
			return SYSINTR_SDMMC_CARD_DETECT;
		}
#else					// for b'd revision 0.17
		if ( s2440IOP->rEINTPEND & (1 << 16))	// SD Card Detect
		{
			s2440IOP->rEINTMASK |= (1 << 16);
			s2440IOP->rEINTPEND  = (1 << 16);
			s2440INT->rSRCPND  = BIT_EINT8_23;
			if (s2440INT->rINTPND & BIT_EINT8_23) 
				s2440INT->rINTPND  = BIT_EINT8_23;
		
			return SYSINTR_SDMMC_CARD_DETECT;
		}
#endif

		else if (submask & (1 << 8))	// 0x100 EINT8 : PCMCIA_LEVEL
		{
			s2440IOP->rEINTMASK |= 0x100;
			s2440IOP->rEINTPEND = 0x100;

			s2440INT->rSRCPND = BIT_EINT8_23;        
			if (s2440INT->rINTPND & BIT_EINT8_23) s2440INT->rINTPND = BIT_EINT8_23;

			//RETAILMSG(1, (TEXT("INT:SYSINTR_PCMCIA_LEVEL INT\r\n")));
			return SYSINTR_PCMCIA_LEVEL;
		}
		else
		{
			s2440INT->rSRCPND = BIT_EINT8_23;        
			if (s2440INT->rINTPND & BIT_EINT8_23) s2440INT->rINTPND = BIT_EINT8_23;

			//RETAILMSG(0, (TEXT("INT:???\r\n")));
			//return SYSINTR_NOP;
		}					
	}

	else if (IntPendVal == INTSRC_ADC) // INTSRC_ADC
	{
        // Touch Panel Int
       	SubIntPendVal = s2440INT->rSUBSRCPND;
       	
       	if(SubIntPendVal & INTSUB_TC) 
		{
       		s2440INT->rINTSUBMSK |= INTSUB_TC;
       		s2440INT->rSUBSRCPND  = INTSUB_TC;
       	
            s2440INT->rINTMSK |= BIT_ADC;
   	        s2440INT->rSRCPND  = BIT_ADC;        
       	    if (s2440INT->rINTPND & BIT_ADC) s2440INT->rINTPND = BIT_ADC;
           
			if( (s2440ADC->rADCDAT0 & 0x8000) || (s2440ADC->rADCDAT1 & 0x8000) )
			{
				s2440INT->rINTMSK |= BIT_TIMER1;     // Mask timer1 interrupt.
		   		s2440INT->rSRCPND = BIT_TIMER1;     // Clear pending bit
   				if (s2440INT->rINTPND & BIT_TIMER1) s2440INT->rINTPND = BIT_TIMER1;
				//RETAILMSG(0,(TEXT("INT Touch pen up \r\n")));

      	        odo_tsb->status = TOUCH_PEN_UP;
      		}
			else
			{
				//RETAILMSG(0,(TEXT("INT Touch pen down \r\n")));
   	            odo_tsb->status = TOUCH_PEN_DOWN;
			}
       
	        return SYSINTR_TOUCH_CHANGED;
		}
       	else if(SubIntPendVal & INTSUB_ADC)
		{
       		s2440INT->rINTSUBMSK |= INTSUB_ADC;
       		s2440INT->rSUBSRCPND = INTSUB_ADC;

	        s2440INT->rINTMSK |= BIT_ADC;
   		    s2440INT->rSRCPND = BIT_ADC;        
       		if (s2440INT->rINTPND & BIT_ADC) s2440INT->rINTPND = BIT_ADC;
            	
        	s2440INT->rINTMSK &= ~BIT_ADC;

           	return SYSINTR_NOP;
       	}
       	else
       		return SYSINTR_NOP;
	}

	else if (IntPendVal == INTSRC_TIMER1) // INTSRC_TIMER1
	{
       // Timer 1 interrupt to get touch point
      	s2440INT->rINTMSK |= BIT_TIMER1;
       	s2440INT->rSRCPND = BIT_TIMER1;
  	    if (s2440INT->rINTPND & BIT_TIMER1) s2440INT->rINTPND = BIT_TIMER1;

		// charlie, 020620
		if( (s2440ADC->rADCDAT0 & 0x8000) || (s2440ADC->rADCDAT1 & 0x8000) )
		{
			//RETAILMSG(0,(TEXT("INT Touch SYSINTR_TOUCH_CHANGED 1\r\n")));
			odo_tsb->status = TOUCH_PEN_UP;
			return SYSINTR_TOUCH_CHANGED;
		}

        if(odo_tsb->status == TOUCH_PEN_UP) 
		{
			//RETAILMSG(0,(TEXT("INT Touch SYSINTR_TOUCH_CHANGED 2 \r\n")));
			odo_tsb->status = TOUCH_PEN_UP;
			return SYSINTR_TOUCH_CHANGED;
		}
        else 
		{
			unsigned int TmpTCON;

        	odo_tsb->status = TOUCH_PEN_SAMPLE;
			TmpTCON = s2440PWM->rTCON;	// get TCON value to temp TCON register
			TmpTCON &= ~0xf00;     		// clear fields of Timer 1 
			TmpTCON |= 0x200;     		// interval mode(auto reload), update TCVNTB4, stop 
			s2440PWM->rTCON = TmpTCON;	// put the value to TCON register

			TmpTCON = s2440PWM->rTCON;	// get TCON value to temp TCON register
			TmpTCON &= ~0xf00;     		// clear fields of Timer 1 
			TmpTCON |= 0x100;     		// interval mode, no operation, start for Timer 4 
			s2440PWM->rTCON = TmpTCON;	// put the value to TCON register

			//RETAILMSG(0,(TEXT("INT Touch SYSINTR_TOUCH\r\n")));
	
        	return SYSINTR_TOUCH;
		}
	}

	else if (IntPendVal == INTSRC_EINT0)		// POWER BUTTON
	{ 
		s2440INT->rINTMSK |= BIT_EINT0;
		s2440INT->rSRCPND  = BIT_EINT0;			// Interrupt Clear
		if (s2440INT->rINTPND & BIT_EINT0) s2440INT->rINTPND  = BIT_EINT0;

		return(SYSINTR_POWER);	
	}

	else if(IntPendVal == INTSRC_DMA1) // AUDIO DMA input.
	{  
		s2440INT->rINTMSK |= BIT_DMA1;
		s2440INT->rSRCPND  = BIT_DMA1;
		if (s2440INT->rINTPND & BIT_DMA1) s2440INT->rINTPND  = BIT_DMA1;

		return(SYSINTR_AUDIO);
	}
	else if(IntPendVal == INTSRC_DMA2) // AUDIO DMA output.
	{  
		s2440INT->rINTMSK |= BIT_DMA2;
		s2440INT->rSRCPND  = BIT_DMA2;
		if (s2440INT->rINTPND & BIT_DMA2) s2440INT->rINTPND  = BIT_DMA2;

		return(SYSINTR_AUDIO);
	}

	else if(IntPendVal == INTSRC_USBH) 	// USB.
	{
		s2440INT->rINTMSK |= BIT_USBH;
		s2440INT->rSRCPND  = BIT_USBH;        
		if (s2440INT->rINTPND & BIT_USBH) s2440INT->rINTPND  = BIT_USBH;
		//RETAILMSG(1, (TEXT("INT:SYSINTR_USB INT\r\n")));
		return(SYSINTR_USB);     
	} 

	else if (IntPendVal == INTSRC_DMA3)
	{
		s2440INT->rINTMSK |= BIT_USBD; // USBD interrupt should be masked
		//s2440INT->rINTMSK |= BIT_DMA3;
		s2440INT->rSRCPND = BIT_DMA3;
		if (s2440INT->rINTPND & BIT_DMA3) s2440INT->rINTPND = BIT_DMA3;
		usbdShMem->usbdDma3Int=1;
		return SYSINTR_USBD;  
		//Correct. DMA3 interrupt will be connected to USBD interrupt.
		//break;
	}

	else if(IntPendVal == INTSRC_USBD) 
	{
		s2440INT->rINTMSK |= BIT_USBD;
		UsbdClearEir();	 //:-)
		s2440INT->rSRCPND = BIT_USBD;
		if (s2440INT->rINTPND & BIT_USBD) s2440INT->rINTPND = BIT_USBD;
		RETAILMSG(0,(TEXT("INT_USBD\r\n")));
		return SYSINTR_USBD;
    }

	else if(IntPendVal == INTSRC_UART0)	// SERIAL (UART0) (physical COM1: P1 connector).
	{  
		SubIntPendVal = s2440INT->rSUBSRCPND;

		// Note that we only mask the sub source interrupt - the serial driver will clear the
		// sub source pending register.
		//
		if(SubIntPendVal & INTSUB_ERR0) 
		{
			s2440INT->rINTSUBMSK |= INTSUB_ERR0;
		}
		else if(SubIntPendVal & INTSUB_RXD0) 
		{
			s2440INT->rINTSUBMSK |= INTSUB_RXD0;
			#if USE_AFC
			// by 0212.
				s2440IOP->rGPHDAT |= (0x2);  // Deassert nRTS				
			#endif
		}
		else if(SubIntPendVal & INTSUB_TXD0) 
		{
			s2440INT->rINTSUBMSK |= INTSUB_TXD0;
		}
		else
		{
			return(SYSINTR_NOP);
		}
	
		// NOTE: Don't clear INTSRC:UART0 here - serial driver does that.
		//
		s2440INT->rINTMSK |= BIT_UART0;
		if (s2440INT->rINTPND & BIT_UART0) s2440INT->rINTPND  = BIT_UART0;

		return(SYSINTR_SERIAL);
	}
	else if(IntPendVal == INTSRC_UART2)	// IrDA (UART2)
	{
		SubIntPendVal = s2440INT->rSUBSRCPND;

		if(SubIntPendVal & INTSUB_ERR2) 
		{
			s2440INT->rINTSUBMSK |= INTSUB_ERR2;
		}       
		else if(SubIntPendVal & INTSUB_RXD2) 
		{
			s2440INT->rINTSUBMSK |= INTSUB_RXD2;
		}       
		else if(SubIntPendVal & INTSUB_TXD2) 
		{
			s2440INT->rINTSUBMSK |= INTSUB_TXD2;
		}       
		else
		{
			return(SYSINTR_NOP);
		}

		// NOTE: Don't clear INTSRC:UART2 here - serial driver does that.
		//
		s2440INT->rINTMSK |= BIT_UART2;
		if (s2440INT->rINTPND & BIT_UART2) s2440INT->rINTPND  = BIT_UART2;
		
		return(SYSINTR_IR);
	}
	else if (IntPendVal == INTSRC_RTC)	// for alarm. 030818
	{ 
		s2440INT->rSRCPND  = BIT_RTC;   // Interrupt Clear
		s2440INT->rINTPND  = BIT_RTC;
		s2440INT->rINTMSK |= BIT_RTC;   // Alarm Interrupt Disable
		return SYSINTR_RTC_ALARM;
	}
	else if(IntPendVal == INTSRC_CAM) 
	{
//		RETAILMSG(1,(TEXT("INT:SYSINTR_CAM INT:0x%x,0x%x\r\n"),s2440INT->rSRCPND,s2440INT->rSUBSRCPND));
		
		if( s2440INT->rSUBSRCPND & (0x1<<11) )
		{
			s2440INT->rINTSUBMSK |= (0x1<<11);
			s2440INT->rINTMSK |= BIT_CAM;
			s2440INT->rSUBSRCPND = (0x1<<11);
			s2440INT->rSRCPND = BIT_CAM;
			
			if (s2440INT->rINTPND & BIT_CAM) s2440INT->rINTPND = BIT_CAM;
			return SYSINTR_CAM;
		}
		else if (s2440INT->rSUBSRCPND & BIT_SUB_CAM_P)
		{
			s2440INT->rINTSUBMSK |= (0x2<<11);
			s2440INT->rINTMSK |= BIT_CAM;
			s2440INT->rSUBSRCPND = (0x2<<11);
			s2440INT->rSRCPND = BIT_CAM;
		
			if (s2440INT->rINTPND & BIT_CAM) s2440INT->rINTPND = BIT_CAM;

			return SYSINTR_CAM;
		}
		
		s2440INT->rINTSUBMSK |= (BIT_SUB_CAM_C | BIT_SUB_CAM_P);
		s2440INT->rINTMSK |= BIT_CAM;
		s2440INT->rSUBSRCPND = (BIT_SUB_CAM_C | BIT_SUB_CAM_P);
		s2440INT->rSRCPND = BIT_CAM;

		if (s2440INT->rINTPND & BIT_CAM)
		{
			s2440INT->rINTPND = BIT_CAM;
		}

		return SYSINTR_NOP;
	}
	else if(IntPendVal == INTSRC_IIC) 
	{
		s2440INT->rINTMSK |= BIT_IIC;
		s2440INT->rSRCPND = BIT_IIC;
		if (s2440INT->rINTPND & BIT_IIC) s2440INT->rINTPND = BIT_IIC;
//		RETAILMSG(1,(TEXT("IIC Interrupt\r\n")));
		return SYSINTR_IIC;
	}
	
	return(SYSINTR_NOP);
}

void UsbdClearEir(void)
{
	static volatile struct udcreg *s2440USBD = (volatile struct udcreg *)(0xB1200140);
	
	usbdShMem->usbdEir|=*(volatile BYTE *)&s2440USBD->EIR;
	usbdShMem->usbdUir|=*(volatile BYTE *)&s2440USBD->UIR;
	*(volatile BYTE *)&s2440USBD->EIR=usbdShMem->usbdEir;
	*(volatile BYTE *)&s2440USBD->UIR=usbdShMem->usbdUir;

}

