// Copyright (c) 1999-2000 Microsoft Corporation.  All rights reserved.

struct cpureg {
   int odo_cpuIsr;
   int odo_cpuMr;
   };

#define odo_systemIntr           0x0001
#define odo_lcdIntr              0x0004
#define odo_prodSerialIntr       0x0008
#define odo_touchAudioAdcIntr    0x0020
#define odo_keybIntr             0x0040
#define odo_irIntr               0x0080
#define odo_etherIntr            0x0100

struct statreg {
   WORD odo_cpuCsr;
   };

#define pwrOffIntr	      		0x00000001 	// OFF button interrupt


struct tsr {
   int odo_ioAdcCntr;
   int odo_ioAdcStr;
   int odo_ucbCntr;
   int odo_ucbStr;
   int odo_ucbRegister;
   int odo_ioSoundCntr;
   int odo_ioSoundStr;
   int odo_intrMask;
   };

#define odo_soundIntrMask	   	0x0002		// mask for all 4 sound interrupts
#define odo_playbackIntr			0x2000
#define odo_playbackEndIntr		0x1000
#define odo_recordIntr	   		0x8000
#define odo_recordEndIntr			0x4000
#define odo_soundIntr            0xF000

// Touch panel bit masks
#define odo_ucbIntr		      	0x0008
#define odo_ucbIntrMask	         0x0008
#define odo_penTimingIntr	   	0x0004
#define odo_penTimingIntrMask 	0x0004
#define odo_penIntr		      	0x0010
#define odo_penIntrMask	      	0x0010
#define odo_regIntr		      	0x0001
#define odo_regIntrMask	      	0x0001
#define odo_penState	         	0x1000
#define odo_penTimingEn	      	0x0400

// PCMCIA registers

struct pcireg {
   int odo_pcmciaReg0;
   int odo_pcmciaIntrReg0;
   int odo_pcmciaReg1;
   int odo_pcmciaIntrReg1;
   };

// PCMCIA bit definitions

#define odo_pcmciaIntrMask		   0x10
#define odo_pcmciaStateIntrMask	0x08
#define odo_pcmciaInterrupts	   0x03
#define odo_pcmciaIntr		      0x02
#define odo_pcmciaStateIntr		0x01


