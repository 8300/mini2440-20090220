//====================================================================
// File Name : IIC_OV7620.h
// Function  : S3C2440 IIC-SCCB Master Tx/Rx mode Test Program              
//
// Date      : August 14, 2003
// Version   : 0.0
// History
//   0.0 : Programming start (2003. 8. 05) by Yoh-Han Lee
//====================================================================

#ifndef __IICOV7620_H__
#define __IICOV7620_H__

#define SlaveID	0x42  //OV7620 Slave ID 

#define U8	unsigned char
#define U16	unsigned short
#define U32	unsigned int

#define WRDATA      (1)
#define RDDATA      (3)
#define SETRDADDR   (4)

#define IICBUFSIZE 0x20

void OV7620_Iic_Test(void);

void OV7620_WriteByte(void);
void OV7620_ReadByte(void);
void OV7620_WriteBlock(void);
void OV7620_ReadBlock(void);


void Wr_OV7620(U32 slvAddr, U32 addr, U8 data);    
void Rd_OV7620(U32 slvAddr, U32 addr, U8 *data);   

void Run_IicPoll(void);
void IicPoll(void);

#endif    //__IICOV7620_H__
