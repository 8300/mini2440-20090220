//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//
/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.

Module Name:

   kitlstub.c

Abstract:

Notes:


--*/
#include <windows.h>
#include <halether.h>

USHORT wLocalMAC[3];    // Saved copy of the mac address
void InitDebugEther(void)
{
}

void OEMEthEnableInts(void)
{
}

void OEMEthDisableInts(void)
{
}

void
CreateDeviceName(char *pMyAddr, char *szBuf)
{
    // Just copy a name over.
    memcpy (szBuf, "NKNoKitl", 9);
}

BOOL EdbgSendUDP(BYTE *pFrameBuffer,    // @parm [IN] - Formatting buffer (must be at least 42 + cwLength bytes)
                 EDBG_ADDR *pDestAddr,  // @parm [IN] - Address of destination
                 USHORT wSrcPort,       // @parm [IN] - Source UDP port number
                 BYTE *pData,           // @parm [IN] - User data buffer
                 UINT16 cwLength )      // @parm [IN] - # of bytes of data in user buffer
{
    return FALSE;
}

#ifdef IMGSHAREETH
BOOL OEMEthCurrentPacketFilter(PDWORD pdwRequestedFilter)
{
    return FALSE;
}

BOOL
OEMEthMulticastList(PUCHAR  pucMulticastAddressList, DWORD  dwNoOfAddresses)
{
    return FALSE;
}

#endif
