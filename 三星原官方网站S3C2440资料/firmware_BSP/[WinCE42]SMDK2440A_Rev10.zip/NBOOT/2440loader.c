//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//
/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
--*/
/************************************************
 * NAME    : 2440loader.C			*
 * DESC    : 					*
 * History : 2002.02.25 ver 0.0			*
 *         : Modified for SMDK2440 PPC2003 BSP ( November 29, 2003 ) -> HMSEO
************************************************/

#include <stdlib.h>
#include <string.h>
#include "option.h"
#include "def.h"
#include "2440addr.h"
#include "2440lib.h"
#include "2440slib.h"
#include "2440addr.h"
#include "nand.h"
#include "..\inc\loader.h"

#define SIGN_ON "\nWinCE NAND Boot v1.00\n" __DATE__ " " __TIME__ "\n"

// HMSEO : Please check UUID memory location from inc\drv_glob.h file.
unsigned char * pbUUID = ((unsigned char *) (0x30030000 + 0x4608));

//
// Globals
//
DWORD JumpAddr;

DWORD ReadImageFromNand(DWORD dwEntry, DWORD dwSig);

void Main(void)
{
    DWORD 	err; //, t0 = 0;
	int i;
    
    //	By default, we launch image CE image. If you want to launch
    //	Eboot, you need to hold down APP4 button (sw803) when it boots.
    DWORD	dwEntry = 1;


#if 0	// The bootloader's FCLK is 400MHz, it takes 1.3V
	//////////////////////////////////////////////
	//   D4  D3  D2  D1  D0
	//    0    1    0     0    0      // 1.35V
	//    0    1    0     0    1      // 1.30V
	//    0    1    0     1    0      // 1.25V
	//    0    1    0     1    1      // 1.20V
	//    0    1    1     0    0      // 1.15V
	//    0    1    1     0    1      // 1.10V
	//    0    1    1     1    0      // 1.05V
	//    0    1    1     1    1      // 1.00V
	//    1    0    0     0    1      // 0.95V
	//    1    0    0     1    1      // 0.90V
	//    1    0    1     0    1      // 0.85V
	//    1    0    1     1    1      // 0.80V

	rGPBDAT=(rGPBDAT&0x77f)|(0<<7);   //D4
	rGPFDAT=(rGPFDAT&0x0f)|(1<<7)|(0<<6)|(0<<5)|(0<<4);   //D3~0

	rGPBCON=(rGPBCON&0x3f3fff)|(1<<14);   // GPB7: Output

	rGPFCON=(rGPFCON&0x00ff)|(0x5500);  // GPF4~7: Output 

   
	rGPBDAT&=~(1<<8);   //Latch enable
	rGPBCON=(rGPBCON&0x3cffff)|(1<<16);   // GPB8: Output

	rGPBDAT|=(1<<10);   //Output enable
	rGPBCON=(rGPBCON&0x0fffff)|(1<<20);   // GPB10: Output

	rGPBDAT|=(1<<8);   //Latch disable
#endif  
  
    MMU_EnableICache();

    Uart_Init();
    Uart_SendString(SIGN_ON);

    NF_Init();

	//	Check to see if the apps buttons are pressed and take
	//	the corresponding actions if they do.
    //  Change this for the final shipping device, so that user
    //  doesn't have to press button to start!
    //
    if( (rGPFDAT & 0xF) != 0x0f ) {
        dwEntry = 0;
    }
//    Uart_SendString("\nrGPFDAT is ");
//    Uart_SendDWORD(rGPFDAT, TRUE);

    Uart_SendString("\ndwEntry is ");
    Uart_SendDWORD(dwEntry, TRUE);

    // Hardcoded to fetch TOC descriptor dwEntry
    err = ReadImageFromNand(dwEntry,0);

//    Uart_SendString("\nJumpAddr is ");
//    Uart_SendDWORD(JumpAddr, TRUE);
//    Uart_SendString("\r\n                     ");
//    Uart_SendString("\r\n                     ");
//    Uart_SendString("\r\n                     ");


#if 0
	for ( i = 0; i < 522; i++ )
	{
		Uart_SendDWORD(JumpAddr+i, FALSE);
	    Uart_SendString(" : ");
		Uart_SendDWORD(*(LPBYTE)(JumpAddr+i), TRUE);
	}
#endif

    if (ERR_SUCCESS == err) {
        Launch(JumpAddr);
        err = ERR_JUMP_FAILED;
    }

    Uart_SendString("\nBoot ERROR:");
    Uart_SendDWORD(err, TRUE);
    while (1);
}


// -----------------------------------------------------------------------------
//  ReadImageFromNand:
//      Reads nk.nb0 off NAND
//      Returns ERR_Xxx
// -----------------------------------------------------------------------------
TOC toc; // made global because it's too big for our tiny stack

DWORD
ReadImageFromNand(DWORD dwEntry, DWORD dwSig)
{
    DWORD dwSectorsNeeded;
    DWORD dwSector, dwLength;         // Start Sector & Length
    DWORD dwRAM, i;

    if ( !FMD_ReadSector(TOC_SECTOR,
                        (LPBYTE)&toc,
                        NULL, 1) )
    {
        Uart_SendString("ERR_DISK_OP_FAIL1\n");
        return ERR_DISK_OP_FAIL1;
    }

    if ( !VALID_TOC(&toc) ) {
        Uart_SendString("ERR_INVALID_TOC: ");
        Uart_SendDWORD(toc.dwSignature, TRUE);
        return ERR_INVALID_TOC;
    }

    if ( !(toc.id[dwEntry].dwImageType & IMAGE_TYPE_RAMIMAGE) ) {
        Uart_SendString("ERR_INVALID_FILE_TYPE: ");
        Uart_SendDWORD(toc.id[dwEntry].dwImageType, TRUE);
        return ERR_INVALID_FILE_TYPE;
    }

// ??
//    if ( !(toc.id[dwEntry].dwImageType & IMAGE_TYPE_BINFS) ) {
//        dwSectorsNeeded = toc.id[dwEntry].dwTtlSectors;
//    } else {
        dwSectorsNeeded = toc.id[dwEntry].dwTtlSectors;		// xipkernel size = 0x9B4
//    }
	
	Uart_SendString("Sector addr on NAND: ");
	Uart_SendDWORD(toc.id[dwEntry].sgList[0].dwSector, TRUE);
    Uart_SendString("TotalSector: ");
    Uart_SendDWORD(dwSectorsNeeded, TRUE);

    dwRAM    = VIRTUAL_TO_PHYSICAL(toc.id[dwEntry].dwLoadAddress);

    JumpAddr = toc.id[dwEntry].dwJumpAddress ? VIRTUAL_TO_PHYSICAL(toc.id[dwEntry].dwJumpAddress) :
                                               VIRTUAL_TO_PHYSICAL(toc.id[dwEntry].dwLoadAddress);
                                               
    //
    // Load the disk image directly into RAM
    // BUGBUG: recover from read failures
    //
	Uart_SendString("Reading Kernel Image from NAND\r\n");
    i = 0;
	while (dwSectorsNeeded && i < MAX_SG_SECTORS)
	{
        dwSector = toc.id[dwEntry].sgList[i].dwSector;
        dwLength = toc.id[dwEntry].sgList[i].dwLength;

		Uart_SendString("    dwSector: ");
		Uart_SendDWORD(dwSector, TRUE);
		Uart_SendString("    dwLength: ");
		Uart_SendDWORD(dwLength, TRUE);
		Uart_SendString("    dwRAM: ");
		Uart_SendDWORD(dwRAM, TRUE);

        // read each sg segment
        while (dwLength) {
            if ( !FMD_ReadSector(dwSector,
                                (LPBYTE)dwRAM,
                                NULL, 1) )
            {
                Uart_SendString("ERR_DISK_OP_FAIL2: ");
                Uart_SendDWORD(dwSector, TRUE);

	    		dwSector++;
				continue;

//                return ERR_DISK_OP_FAIL2;
            }
            
    		dwSector++;
    		dwLength--;
            dwRAM += SECTOR_SIZE;
        }

        dwSectorsNeeded -= toc.id[dwEntry].sgList[i].dwLength;
        i++;
    }

    //  We only do this if the dwRAM is not zero (The default tocblock1 
    //  set the dwRAM to be 0)
    if (toc.chainInfo.dwLoadAddress == 0) {
        return ERR_SUCCESS;
    }

    // Load the Chain.bin stored on NAND to the SDRAM
//	if ( toc.id[dwEntry].dwImageType == 6 )		// For WinCE 4.2 Image
//	if ( 1 )		// For WinCE 4.2 Image
//	{
//		dwRAM = VIRTUAL_TO_PHYSICAL(toc.id[dwEntry].dwLoadAddress);
//		dwSectorsNeeded = toc.id[dwEntry].sgList->dwLength;
//		dwSector = toc.id[dwEntry].sgList->dwSector;
//	}
//	else
	{
		dwRAM = VIRTUAL_TO_PHYSICAL(toc.chainInfo.dwLoadAddress);		// 0x303c0000
		dwSectorsNeeded = toc.chainInfo.dwLength;						// 0x20
		dwSector = toc.chainInfo.dwFlashAddress;						// 0x103c0

//		dwSectorsNeeded = 0x20;
//		dwSector = 0x104C0;
	}

#if 0
	// Copy UUID to SDRAM drv_glob area from NAND
    Uart_SendString("Reading UUID from NAND : ");

	for ( i = 0; i < 8; i++ )
	{
		*pbUUID = toc.udid[i];
//		Uart_SendByte(*pbUUID);
//		Uart_SendDWORD(*pbUUID, FALSE);
//	    Uart_SendString(": ");
		pbUUID++;
	}
    Uart_SendString("\r\n");
#endif

//	Uart_SendString("Reading Chain from NAND\r\n");
//	Uart_SendString("LoadAddr: ");
//	Uart_SendDWORD(dwRAM, TRUE);
//	Uart_SendString("NAND SectorAddr: ");
//	Uart_SendDWORD(dwSector, TRUE);
//	Uart_SendString("Length: ");
//	Uart_SendDWORD(dwSectorsNeeded, TRUE);

#if 1
    while(dwSectorsNeeded) {
        
        if (!FMD_ReadSector(dwSector, 
                            (LPBYTE) dwRAM,
                            NULL, 1) ) {
            Uart_SendString("Failed reading Chain.bin:");
            Uart_SendDWORD(dwSector, TRUE);

			dwSector++;
			continue;
        }

        dwSector++;
        dwSectorsNeeded--;
        dwRAM += SECTOR_SIZE;
    }
#endif

//    Uart_SendString("RETURN SUCCESS");
//    Uart_SendString("\r\n                     ");

	return ERR_SUCCESS;
}

