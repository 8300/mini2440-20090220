//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//

//#include "..\..\KERNEL\HAL\ARM\TIMER.C"

#if 1
#include <windows.h>

#include "s2440.h"
#include "warning.h"

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------
#define FROM_BCD(n)     ((((n) >> 4) * 10) + ((n) & 0xf))

BOOL 
OEMGetRealTime(LPSYSTEMTIME lpst) 
{
    volatile RTCreg *s2440RTC = (RTCreg *)RTC_BASE;
    
    lpst->wSecond    = FROM_BCD(s2440RTC->rBCDSEC );
    lpst->wMinute    = FROM_BCD(s2440RTC->rBCDMIN );
    lpst->wHour      = FROM_BCD(s2440RTC->rBCDHOUR);

    lpst->wDayOfWeek = s2440RTC->rBCDDATE - 1;

    lpst->wDay       = FROM_BCD(s2440RTC->rBCDDAY );
    lpst->wMonth     = FROM_BCD(s2440RTC->rBCDMON );
    lpst->wYear      = FROM_BCD(s2440RTC->rBCDYEAR) + 2000;

    return TRUE;
}

//------------------------------------------------------------------------------
//------------------------------------------------------------------------------

#define TO_BCD(n)       ((((DWORD)(n) / 10) << 4) | ((DWORD)(n) % 10))

BOOL 
OEMSetRealTime(LPSYSTEMTIME lpst) 
{
    volatile INTreg *s2440INT = (INTreg *)INT_BASE;
    volatile RTCreg *s2440RTC = (RTCreg *)RTC_BASE;
    
    s2440RTC->rRTCCON = (1 << 3) | (1 << 0);        /* RTC Control Enable & Reset   */
    
    s2440RTC->rBCDSEC  = (unsigned char)TO_BCD(lpst->wSecond );
    s2440RTC->rBCDMIN  = (unsigned char)TO_BCD(lpst->wMinute );
    s2440RTC->rBCDHOUR = (unsigned char)TO_BCD(lpst->wHour   );

    s2440RTC->rBCDDATE = (unsigned char)(lpst->wDayOfWeek + 1);
    s2440RTC->rBCDDAY  = (unsigned char)TO_BCD(lpst->wDay    );
    s2440RTC->rBCDMON  = (unsigned char)TO_BCD(lpst->wMonth  );
    s2440RTC->rBCDYEAR = (unsigned char)TO_BCD(((DWORD)lpst->wYear % 100));

    s2440RTC->rRTCCON = (0 << 0);                   /* RTC Control Disable          */

    s2440INT->rSRCPND  =  BIT_RTC;                  /* RTC Alarm Interrupt Clear    */
    s2440INT->rINTPND  =  BIT_RTC;
    s2440INT->rINTMSK &= ~BIT_RTC;                  /* RTC Alarm Enable             */

    return TRUE;
}
#endif
