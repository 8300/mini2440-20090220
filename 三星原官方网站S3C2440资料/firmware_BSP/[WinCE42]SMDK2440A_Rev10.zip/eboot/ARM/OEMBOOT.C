/******************************************************************************
 *
 * System On Chip(SOC)
 *
 * Copyright (c) 2002 Software Center, Samsung Electronics, Inc.
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of Samsung 
 * Electronics, Inc("Confidential Information"). You Shall not disclose such 
 * Confidential Information and shall use it only in accordance with the terms 
 * of the license agreement you entered into Samsung.
 *
 *-----------------------------------------------------------------------------
 *
 *  S3C2440 BSP (WinCE3.0 & PocketPC2002)
 *
 * oemboot.c : OEM specific bootloader routines
 *
 * @author  zartoven@samsung.com (SOC, SWC, SAMSUNG Electronics)
 *
 * @date    2002/04/09
 * 
 * Log:
 *  2002/04/09  Start(From ODO's BSP)
 *      
 ******************************************************************************
 */
#include "warning.h"
 
#include "..\..\..\kernel\hal\debug.c"


unsigned int 
PowerOnSelfTest(void) 
{
    return 1;
}
