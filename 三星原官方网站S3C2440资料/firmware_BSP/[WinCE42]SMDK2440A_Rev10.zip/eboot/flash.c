//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//
/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.

Module Name:
    ethdown.c

Abstract:
    This contains an example of a registered TFTP server
    process.  It is the EthDown() routine that handles the download
    of .BIN files to RAM.

Functions:


Notes:

--*/
#include <windows.h>
#include <halether.h>
#include <pehdr.h>

#include "loader.h"
#include "blcommon.h"
#include "warning.h"

extern const PTOC g_pTOC;
extern DWORD g_dwTocEntry;
extern DWORD g_ImageType;
extern MultiBINInfo g_BINRegionInfo;
//
//  Stub function so that we can use blcommon
//

/*
    @func   BOOL | OEMIsFlashAddr | Tests whether the address provided resides in NOR flash.
    @rdesc  TRUE = Specified address resides in flash, FALSE = Specified address doesn't reside in flash.
    @comm
    @xref
*/
BOOL OEMIsFlashAddr( DWORD dwPhysStart )
{
    //EdbgOutputDebugString("OEMIsFlashAddr: 0x%x, %d\r\n", dwPhysStart, bRc);
    return FALSE;
}


/*
    @func   LPBYTE | OEMMapMemAddr | Remaps a specified address to a file cache location.
            The file cache is used as a temporary store for flash images before they're written to flash.
    @rdesc  Corresponding address within a file cache area.
    @comm
    @xref
*/
LPBYTE OEMMapMemAddr( DWORD dwImageStart, DWORD dwAddr )
{
    //EdbgOutputDebugString("OEMMapMemAddr: 0x%x, 0x%x, ", dwImageStart, dwAddr);

    if ( g_ImageType & IMAGE_TYPE_MXIP )
    {
        DWORD i, Length=0;

        // we don't know the segments length, so parse our BIN table for the length
        for ( i = 0; i < g_BINRegionInfo.dwNumRegions; i++ )
        {
            if ( (dwAddr >= g_BINRegionInfo.Region[i].dwRegionStart) &&
                 (dwAddr <  g_BINRegionInfo.Region[i].dwRegionStart + g_BINRegionInfo.Region[i].dwRegionLength) )
            {
                dwAddr = (dwAddr - g_BINRegionInfo.Region[i].dwRegionStart) + FLASH_CACHE + Length;
                break;
            }

            // bump length
            Length += g_BINRegionInfo.Region[i].dwRegionLength;
        }
    }

    //EdbgOutputDebugString("0x%x \r\n", dwAddr);

    return (LPBYTE)dwAddr;
}


/*
    @func   BOOL | OEMStartEraseFlash | Called at the start of image download, this routine begins the flash erase process.
    @rdesc  TRUE = Success, FALSE = Failure.
    @comm
    @xref
*/
BOOL OEMStartEraseFlash( DWORD dwStartAddr, DWORD dwLength )
{
    //EdbgOutputDebugString( "OEMStartEraseFlash: Addr:0x%x Len:0x%x\n", dwStartAddr, dwLength);
    return TRUE;
}


/*
    @func   void | OEMContinueEraseFlash | Called frequenty during image download, this routine continues the flash erase process.
    @rdesc  N/A.
    @comm
    @xref
*/
void OEMContinueEraseFlash()
{
    //EdbgOutputDebugString("OEMContinueEraseFlash\r\n");
}


/*
    @func   BOOL | OEMFinishEraseFlash | Called following the image download, this routine completes the flash erase process.
    @rdesc  TRUE = Success, FALSE = Failure.
    @comm
    @xref
*/
BOOL OEMFinishEraseFlash()
{
    //EdbgOutputDebugString("OEMFinishEraseFlash\r\n");
    return TRUE;
}


/*
    @func   BOOL | OEMWriteFlash | Writes data to flash (the source location is determined using OEMMapMemAddr).
    @rdesc  TRUE = Success, FALSE = Failure.
    @comm
    @xref
*/
BOOL OEMWriteFlash (DWORD dwStartAddr, DWORD dwLength)
{
    //EdbgOutputDebugString("OEMWriteFlash 0x%x 0x%x\r\n", dwStartAddr, dwLength);
    return TRUE;
}


