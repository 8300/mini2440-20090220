/**********************************************************************
  File:		    posmodul.h
  Description:	this file provides assembly defines for the various
				structs used to access hardware registers
  
 *********************************************************************
              Copyright (c) 1996 Philips Electronics, Inc.
              Copyright (c) 1995-2000 Microsoft Corporation.  All rights reserved.
 *********************************************************************/

#ifndef __POSMODUL__
#define __POSMODUL__

#define PoseidonModule_videoControl 0x28
#define PoseidonModule_videoLowBufferAndDf 0x34
#define PoseidonModule_memoryConfiguration0 0x0
#define PoseidonModule_memoryConfiguration1 0x4
#define PoseidonModule_memoryConfiguration2 0x8
#define PoseidonModule_memoryConfiguration3 0xC
#define PoseidonModule_memoryConfiguration4 0x10
#define PoseidonModule_memoryConfiguration5 0x14
#define PoseidonModule_memoryConfiguration6 0x18
#define PoseidonModule_memoryConfiguration7 0x1C
#define PoseidonModule_memoryConfiguration8 0x20
#define PoseidonModule_sibControl 0x74
#define PoseidonModule_interrupt1 0x100
#define PoseidonModule_interrupt2 0x104
#define PoseidonModule_interrupt3 0x108
#define PoseidonModule_interrupt4 0x10C
#define PoseidonModule_interrupt5 0x110
#define PoseidonModule_interrupt6 0x114
#define PoseidonModule_interrupt1Enable 0x118
#define PoseidonModule_interrupt2Enable 0x11C
#define PoseidonModule_interrupt3Enable 0x120
#define PoseidonModule_interrupt4Enable 0x124
#define PoseidonModule_interrupt5Enable 0x128
#define PoseidonModule_interrupt6Enable 0x12C
#define PoseidonModule_rtcLow 0x144
#define PoseidonModule_rtcHigh 0x140
#define PoseidonModule_timerControl 0x150
#define PoseidonModule_perTimer 0x154
#define PoseidonModule_spiControl 0x160
#define PoseidonModule_spi 0x164
#define PoseidonModule_mfioSelect 0x190
#define PoseidonModule_mfioDataOutput 0x184
#define PoseidonModule_mfioDirection 0x188
#define PoseidonModule_mfioPowerDown 0x198
#define PoseidonModule_ioPowerDown 0x194
#define PoseidonModule_masterClock 0x1C0
#define PoseidonModule_powerControl 0x1C4
#define PoseidonModule_ioControl 0x180
#define PoseidonModule_uartA_control1 0xB0
#define PoseidonModule_uartB_control1 0xC8
#define PoseidonModule_uartA_control2 0xB4
#define PoseidonModule_uartB_control2 0xCC
#define PoseidonModule_uartA_hold 0xC4
#define PoseidonModule_uartB_hold 0xDC
#define PoseidonModule_mbusControl1 0xE0
#define PoseidonModule_irControl1 0xA0
#define PoseidonModule_chiControl 0x1D8
#define GlacierModule_ioDataOutput 0x0
#define GlacierModule_mfioDataOutput 0x2
#define GlacierModule_ioDirection 0x4
#define GlacierModule_mfioDirection 0x6
#define GlacierModule_reserved0 0x8
#define GlacierModule_mfioSelect 0xA
#define GlacierModule_ioDataInput 0xC
#define GlacierModule_mfioDataInput 0xE
#define GlacierModule_ioPosInterruptEnable 0x10
#define GlacierModule_mfioPosInterruptEnable 0x12
#define GlacierModule_ioNegInterruptEnable 0x14
#define GlacierModule_mfioNegInterruptEnable 0x16
#define GlacierModule_ioPosInterrupt 0x18
#define GlacierModule_mfioPosInterrupt 0x1A
#define GlacierModule_ioNegInterrupt 0x1C
#define GlacierModule_mfioNegInterrupt 0x1E
#define GlacierModule_control 0x20
#endif
