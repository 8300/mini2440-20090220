// Copyright (c) 1999-2000 Microsoft Corporation.  All rights reserved.
//
// This file defines the base address of the PCMCIA memory are used for PCMCIA tracing.
// This number is already defined elswhere, but I needed it to be defined in a platform
// independant fashion so that public files can reference it.  This file should normally
// only be included by pcmtrace.h

#include "p2.h"

#define __PCMDBG_BASE              PCMCIA0_16_CMN_WIN_BASE
#define __PCMDBG_MEMORY_SIZE       PCMCIA_CMN_WIN_SIZE

