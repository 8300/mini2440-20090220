#define MIN_ALPHA		0
#define MAX_ALPHA		8
#define MIN_HUE			0
#define MAX_HUE			90
#define MIN_BRIGHT		-128
#define MAX_BRIGHT		127
#define MIN_CBGAIN		0
#define MAX_CBGAIN		255
#define MIN_CRGAIN		0
#define MAX_CRGAIN		255

#define	COARSE_SCALE	3
#define	FINE_SCALE		0

#define	OVL_NORMAL		1
#define	OVL_ALPHA		4
#define	OVL_COLKEY		5

typedef struct _CAMINFO
{
	WORD	nSrcWidth;		// original input width
	WORD	nSrcHeight;		// original input height
	WORD	nSrcBytes;		// # of bytes in a pixel.
	float	fScale;			// scaling value for image scaler, Output_Size = fScale * Original_Size
} CAMINFO, *LPCAMINFO;

typedef struct _CAM_GAMMATABLE
{
	short	gamma_table[1024];
} CAM_GAMMATABLE, *LPCAM_GAMMATABLE;

typedef struct _CAM_WBTABLE
{
	WORD	WBTable[16];
} CAM_WBTABLE, *LPCAM_WBTABLE;

// show Camera 
//		dwLenIn = 1 : Normal overlay
//		dwLenIn = 4 : Alphablending 
//		dwLenIn = 5 : Colorkey overlay
#define IOCTL_CAM_SHOW			CTL_CODE( FILE_DEVICE_VIDEO, 1, METHOD_NEITHER,FILE_ANY_ACCESS)

// hide Camera 
#define IOCTL_CAM_HIDE			CTL_CODE( FILE_DEVICE_VIDEO, 2, METHOD_NEITHER,FILE_ANY_ACCESS)

// Set Diplay position 
//		dwLenIn = MAKELONG(left, top)
//		dwLenOut = MAKELONG(width, height)
#define IOCTL_CAM_SETPOS		CTL_CODE( FILE_DEVICE_VIDEO, 3, METHOD_NEITHER,FILE_ANY_ACCESS)

// play 
#define IOCTL_CAM_CONT			CTL_CODE( FILE_DEVICE_VIDEO, 4, METHOD_NEITHER,FILE_ANY_ACCESS)

// stop
#define IOCTL_CAM_STOP			CTL_CODE( FILE_DEVICE_VIDEO, 5, METHOD_NEITHER,FILE_ANY_ACCESS)

// copy camera image to pBufOut (RGB565 format)
//		dwLenIn = 0 : top-down image
//		dwLenIn = 1 : bottom-up image
#define IOCTL_CAM_COPY			CTL_CODE( FILE_DEVICE_VIDEO, 6, METHOD_OUT_DIRECT,FILE_ANY_ACCESS)

// set colorkey
//		dwLenIn = RGB(R-value, G-value, B-value)
#define IOCTL_CAM_SETCOLKEY		CTL_CODE( FILE_DEVICE_VIDEO, 7, METHOD_NEITHER,FILE_ANY_ACCESS)

// set alpha value
//		dwLenIn = alpha value[0-8]
#define IOCTL_CAM_SETALPHA		CTL_CODE( FILE_DEVICE_VIDEO, 8, METHOD_NEITHER,FILE_ANY_ACCESS)

// get camera information
//		pBufOut = LPCAMINFO;
#define IOCTL_CAM_GETINFO		CTL_CODE( FILE_DEVICE_VIDEO, 9, METHOD_OUT_DIRECT,FILE_ANY_ACCESS)

// set scale for image_scaler
//		dwLenIn = scalemode (0:FINE, 3:COARSE)
//		pBufIn = (float*)&scale;
#define IOCTL_CAM_SETSCALE		CTL_CODE( FILE_DEVICE_VIDEO, 10, METHOD_IN_DIRECT,FILE_ANY_ACCESS)

// set hue value
//		dwLenIn = MAKELONG(hue_value[0-90], coord.[0-4]) ; if coord==0 then all coord. set
#define IOCTL_CAM_SETHUE		CTL_CODE( FILE_DEVICE_VIDEO, 11, METHOD_NEITHER,FILE_ANY_ACCESS)

// set gamma
//		gamma_off : dwLenIn = 0
//		gamma_on  : pBufIn = gamma_table; dwLenIn = sizeof(gamma_table=2048); 
#define IOCTL_CAM_SETGAMMA		CTL_CODE( FILE_DEVICE_VIDEO, 12, METHOD_IN_DIRECT,FILE_ANY_ACCESS)

// set White balance coordinate
//		pBufIn = WBtable;
#define IOCTL_CAM_SETWBCOORD	CTL_CODE( FILE_DEVICE_VIDEO, 13, METHOD_IN_DIRECT,FILE_ANY_ACCESS)

// set Auto Exposure accumulation limit
//		dwLenIn = MAKELONG(LowerLimit[0-255], UpperLimit[0-255]);
#define IOCTL_CAM_SETAELIMIT	CTL_CODE( FILE_DEVICE_VIDEO, 14, METHOD_NEITHER,FILE_ANY_ACCESS)

// set ADC offset value
//		dwLenIn = RGB((BYTE)R-offset[-127 - 128], (BYTE)G-offset[-127 - 128], (BYTE)B-offset[-127 - 128]);
#define IOCTL_CAM_SETADCOFS		CTL_CODE( FILE_DEVICE_VIDEO, 15, METHOD_NEITHER,FILE_ANY_ACCESS)

// set ADC offset value
//		Decimal_X_gain[5.4] = (unsigned char)(fGain[0.0-8.0]*0x20);
//		dwLenIn = RGB(Decimal_R_gain, Decimal_G_gain, Decimal_B_gain);
#define IOCTL_CAM_SETWBGAIN		CTL_CODE( FILE_DEVICE_VIDEO, 16, METHOD_NEITHER,FILE_ANY_ACCESS)

// set CbGain & CrGain
//		Decimal_Cx_gain[7.6] = (unsigned char)(fGain[0.0-2.0]*0x80);
//		dwLenIn = MAKELONG(Decimal_Cr_gain, Decimal_Cb_gain);
#define IOCTL_CAM_SETCBCRGAIN	CTL_CODE( FILE_DEVICE_VIDEO, 17, METHOD_NEITHER,FILE_ANY_ACCESS)

// set Luminance Enhancement Gain
//		Decimal_H_gain[4.3] = (unsigned char)(fHGain[0.0-8.0]*0x10);
//		Decimal_V_gain[4.3] = (unsigned char)(fVGain[0.0-8.0]*0x10);
//		Decimal_Main_gain[6.5] = (unsigned char)(fMainGain[0.0-4.0]*0x40);
//		dwLenIn = MAKELONG(Decimal_H_gain, Decimal_V_gain);
//		dwLenOut = Decimal_Main_Gain;
#define IOCTL_CAM_SETLEGAIN		CTL_CODE( FILE_DEVICE_VIDEO, 18, METHOD_NEITHER,FILE_ANY_ACCESS)

// set brightness
//		dwLenIn = (BYTE)brightness[-127 - 128];
#define IOCTL_CAM_SETBRIGHTNESS CTL_CODE( FILE_DEVICE_VIDEO, 19, METHOD_NEITHER,FILE_ANY_ACCESS)

// set Clip point & color supress 
//		dwLenIn = CSlantEn[0-1] << 31 | CSlant_val[0-1,[7.6]decimal] << 16 | Clip2[0-255] << 8 | Clip1[0-255];
#define IOCTL_CAM_SETCLIP		CTL_CODE( FILE_DEVICE_VIDEO, 20, METHOD_NEITHER,FILE_ANY_ACCESS)

// set Slice limit
//		dwLenIn = slice_limit[0-255];
#define IOCTL_CAM_SETSLICELMT	CTL_CODE( FILE_DEVICE_VIDEO, 21, METHOD_NEITHER,FILE_ANY_ACCESS)

// set White balance accumulation Limit
//		dwLenIn = MAKELONG(LowerLimit[0-255], UpperLimit[0-255]);
#define IOCTL_CAM_WBACCLMT		CTL_CODE( FILE_DEVICE_VIDEO, 22, METHOD_NEITHER,FILE_ANY_ACCESS)

// set Color supress Luma Edge limit
//		dwLenIn = MAKELONG(LowerLimit[0-255], UpperLimit[0-255]);
#define IOCTL_CAM_CSEDGELMT		CTL_CODE( FILE_DEVICE_VIDEO, 23, METHOD_NEITHER,FILE_ANY_ACCESS)

// Camera V-Sync Interrupt Handler Enable
#define IOCTL_CAM_ENVINT		CTL_CODE( FILE_DEVICE_VIDEO, 24, METHOD_NEITHER,FILE_ANY_ACCESS)

// Camera V-Sync Interrupt Handler Disable
#define IOCTL_CAM_DISVINT		CTL_CODE( FILE_DEVICE_VIDEO, 25, METHOD_NEITHER,FILE_ANY_ACCESS)

// set Camera
//		pBufIn = (LPTSTR)szCameraName;
#define IOCTL_CAM_SETCAMERA		CTL_CODE( FILE_DEVICE_VIDEO, 26, METHOD_IN_DIRECT,FILE_ANY_ACCESS)