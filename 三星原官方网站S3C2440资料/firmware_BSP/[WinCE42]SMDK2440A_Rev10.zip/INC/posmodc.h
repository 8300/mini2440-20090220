/*********************************************************************
  File:		    posmodc.h
  Description:	this file provides headers for C access to Poseidon
				registers.
  
 *********************************************************************
              Copyright (c) 1996 Philips Electronics, Inc.
              Copyright (c) 1996-2000 Microsoft Corporation.  All rights reserved.
 *********************************************************************/

#ifndef __POSMODC__
#define __POSMODC__

#include <poseidon.h>

typedef volatile struct UartRegs__
	{
	ULONG	control1;
	ULONG	control2;
	ULONG	dmaControl1;
	ULONG	dmaControl2;
	ULONG	dmacnt;
	ULONG	hold;
	} UartRegs;

typedef volatile struct PoseidonModuleModule__
	{
	ULONG	memoryConfiguration0;
	ULONG	memoryConfiguration1;
	ULONG	memoryConfiguration2;
	ULONG	memoryConfiguration3;
	ULONG	memoryConfiguration4;
	ULONG	memoryConfiguration5;
	ULONG	memoryConfiguration6;
	ULONG	memoryConfiguration7;
	ULONG	memoryConfiguration8;
	ULONG	unused0;

	ULONG	videoControl;
	ULONG	videoRateAndScreen;
	ULONG	videoHighBuffer;
	ULONG	videoLowBufferAndDf;
	ULONG	videoRedPalette;
	ULONG	videoGreenPalette;
	ULONG	videoBluePalette;
	ULONG	videoDither2Of3;
	ULONG	videoDitherNOf4;
	ULONG	videoDither4Of5;
	ULONG	videoDither3Of5;
	ULONG	videoDither6Of7;
	ULONG	videoDither5Of7;
	ULONG	videoDither4Of7;

	ULONG	sibSize;
	ULONG	sibSoundRxStart;
	ULONG	sibSoundTxStart;
	ULONG	sibTelRxStart;
	ULONG	sibTelTxStart;
	ULONG	sibControl;
	ULONG	sibSoundHold;
	ULONG	sibTelHold;
	ULONG	sibSf0Aux;
	ULONG	sibSf1Aux;
	ULONG	sibSf0Status;
	ULONG	sibSf1Status;
	ULONG	sibDMA;
	ULONG	unused1[3];

	ULONG	irControl1;
	ULONG	irControl2;
	ULONG	irHold;
	ULONG	unused2;

	UartRegs	uartA;
	UartRegs	uartB;

	ULONG	mbusControl1;
	ULONG	mbusControl2;
	ULONG	mbusDMAStartAddr;
	ULONG	mbusDMALength;
	ULONG	mbusDMACount;
	ULONG	mbusCommand;
	ULONG	mbusData;
	ULONG	unused3;

	ULONG	interrupt1;
	ULONG	interrupt2;
	ULONG	interrupt3;
	ULONG	interrupt4;
	ULONG	interrupt5;
	ULONG	interrupt6;
/*
 * These are defined in poseidon.h:
 *
 * #define interrupt1Clear interrupt1
 * #define interrupt2Clear interrupt2
 * #define interrupt3Clear interrupt3
 * #define interrupt4Clear interrupt4
 * #define interrupt5Clear interrupt5
 */
	ULONG	interrupt1Enable;
	ULONG	interrupt2Enable;
	ULONG	interrupt3Enable;
	ULONG	interrupt4Enable;
	ULONG	interrupt5Enable;
	ULONG	interrupt6Enable;
	ULONG	unused4[4];

	ULONG	rtcHigh;
	ULONG	rtcLow;
	ULONG	alarmHigh;
	ULONG	alarmLow;
	ULONG	timerControl;
	ULONG	perTimer;
	ULONG	unused5[2];

	ULONG	spiControl;
	ULONG	spi;
	ULONG	unused6[6];

	ULONG	ioControl;
	ULONG	mfioDataOutput;
	ULONG	mfioDirection;
	ULONG	mfioDataInput;

	ULONG	mfioSelect;
	ULONG	ioPowerDown;
	ULONG	mfioPowerDown;
	ULONG	unused7[9];
	ULONG	masterClock;

	ULONG	powerControl;

	ULONG	siuTest;
	ULONG	unused8[3];
	ULONG	chiControl;
	ULONG	chiPointerEnable;
	ULONG	chiRxPointerA;
	ULONG	chiRxPointerB;
	ULONG	chiTxPointerA;
	ULONG	chiTxPointerB;
	ULONG	chiSize;
	ULONG	chiRxStart;
	ULONG	chiTxStart;
	ULONG	chiHold;
	} PoseidonModule;

#define POSEIDONMODULE	((PoseidonModule *) kPoseidonModuleAddress)

#endif /* __POSMODC__ */
