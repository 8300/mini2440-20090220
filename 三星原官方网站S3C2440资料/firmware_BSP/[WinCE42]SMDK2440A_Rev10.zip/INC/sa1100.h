// Copyright (c) 1999-2000 Microsoft Corporation.  All rights reserved.
/*
* SA1100 defines
*/

#define EXT(d, b) ((((unsigned int)(d))>>(b))&1)
#define EXTV(d, hb, lb)\
 (((((unsigned int)(d))>>(lb))&((((unsigned int)0xffffffff)<<(31-(hb)))>>((lb)+(31-(hb))))) & 0xffffffff)


/*  System Control Module IC Register Locations     */
#define IC_BASE     0xA9050000 /*  SCM IC Base      */

struct icreg {
	int icip; // R
	int icmr; // RW
	int iclr; // RW
	int icr_0x0C;
	int icfp; //R
	int icr_0x14;
	int icr_0x18;
	int icr_0x1C;
	int icpr; // R
};

// SA1100 Interrupt controller bit positions
#define 		RTC_ALM		 0x80000000
#define		HZ_TIC		 0x40000000
#define		OS_TIMER3	 0x20000000
#define		OS_TIMER2	 0x10000000
#define		OS_TIMER1	 0x08000000
#define		OS_TIMER0	 0x04000000
#define		IC_DMA_CH5	 0x02000000
#define		IC_DMA_CH4	 0x01000000
#define		IC_DMA_CH3	 0x00800000
#define		IC_DMA_CH2	 0x00400000
#define		IC_DMA_CH1	 0x00200000
#define		IC_DMA_CH0	 0x00100000
#define		SERIAL_4B	 0x00080000  // SSP
#define		SERIAL_4A	 0x00040000  // MCP
#define		SERIAL_3		 0x00020000  // UART
#define		SERIAL_2		 0x00010000  // HSSP/UART
#define		SERIAL_1B	 0x00008000  // UART Interrupt
#define		SERIAL_1A	 0x00004000  // SDLC Interrupt
#define		SERIAL_0		 0x00002000  // UDC 
#define		LCD_CTRL		 0x00001000
#define		GPIO_GRP		 0x00000800
#define		GPIO_10		 0x00000400
#define		GPIO_9		 0x00000200
#define		GPIO_8		 0x00000100
#define		GPIO_7		 0x00000080
#define		GPIO_6		 0x00000040
#define		GPIO_5		 0x00000020
#define		GPIO_4		 0x00000010
#define 		GPIO_3 		 0x00000008
#define 	 	GPIO_2		 0x00000004
#define		GPIO_1		 0x00000002
#define		GPIO_0		 0x00000001


/*   System Control Module GPIO Register Locations     */
#define GPIO_BASE     0xA9040000 /*  SCM GP BASE         */

struct gpioreg {
	int gplr; // R
	int gpdr; // RW
	int gpsr; // W
	int gpcr; // W
	int grer; // RW
	int gfer; // RW
	int gedr; // RW
	int gafr; // RW
};

#define OST_BASE	0xA9000000

struct ostreg {
	int osmr0;
	int osmr1;
	int osmr2;
	int osmr3;
	int oscr;
	int ossr;
	int ower;
	int oier;
};

#define OSSR_M_M0 0x00000001
#define OSSR_M_M1 0x00000002
#define OSSR_M_M2 0x00000004
#define OSSR_M_M3 0x00000008
#define OIER_M_E0 0x00000001
#define OIER_M_E1 0x00000002
#define OIER_M_E2 0x00000004
#define OIER_M_E3 0x00000008

//Real time clock defines
#define RTC_BASE     0xA9010000

struct rtcreg{
   int rtar;
   int rcnr;
   int rttr;
   int pad;
   int rtsr;
   };

// RTC Status reg bits
#define RTC_AL    0x00000001     // Alarm detected
#define RTC_HZ    0x00000002     // 1 HZ rising edge detected
#define RTC_ALE   0x00000004     // Alarm interrupt enabled
#define RTC_HZE   0x00000008     // 1 HZ interrupt enabled

#define VIDEO_BASE   0xAB100000

struct lcd_regs {
  int Control0;     /* LCCR0 */
  int Status;       /* LCSR  */
  int Reserved1;    /* Pad   */
  int Reserved2;    /* Pad   */
  int DMA1Base;     /* DBAR1 */
  int DMA1Current;  /* DCAR1 */
  int DMA2Base;     /* DBAR2 */
  int DMA2Current;  /* DCAR2 */
  int Control1;     /* LCCR1 */
  int Control2;     /* LCCR2 */
  int Control3;     /* LCCR3 */
};

/* LCD Control Register 0 Bits */
#define LCD0_M_LEN 0x00000001
#define LCD0_M_CMS 0x00000002
#define LCD0_M_SDS 0x00000004
#define LCD0_M_PAS 0x00000080
#define LCD0_M_BLE 0x00000100
#define LCD0_M_DPD 0x00000200
#define LCD0_M_FDD 0x000FF000
#define LCD0_V_LEN 0
#define LCD0_V_CMS 1
#define LCD0_V_SDS 2
#define LCD0_V_PAS 7
#define LCD0_V_BLE 8
#define LCD0_V_DPD 9
#define LCD0_V_FDD 12

/* LCD control Register 1 Bits */
#define LCD1_M_PPL 0x000003FF
#define LCD1_M_HSW 0x0000FC00
#define LCD1_M_ELW 0x00FF0000
#define LCD1_M_BLW 0xFF000000
#define LCD1_V_PPL 0
#define LCD1_V_HSW 10
#define LCD1_V_ELW 16
#define LCD1_V_BLW 24

/* LCD control Register 2 Bits */
#define LCD2_M_LPP 0x000003FF
#define LCD2_M_VSW 0x0000FC00
#define LCD2_M_EFW 0x00FF0000
#define LCD2_M_BFW 0xFF000000
#define LCD2_V_LPP 0
#define LCD2_V_VSW 10
#define LCD2_V_EFW 16
#define LCD2_V_BFW 24

/* LCD control Register 2 Bits */
#define LCD3_M_PCD 0x000000FF
#define LCD3_M_ACB 0x0000FF00
#define LCD3_M_API 0x000F0000
#define LCD3_M_VSP 0x00100000
#define LCD3_M_HSP 0x00200000
#define LCD3_M_PCP 0x00400000
#define LCD3_M_OEP 0x00800000
#define LCD3_V_PCD 0
#define LCD3_V_ACB 8
#define LCD3_V_API 16
#define LCD3_V_VSP 20
#define LCD3_V_HSP 21
#define LCD3_V_PCP 22
#define LCD3_V_OEP 23

struct sspreg {
	int sscr0;
	int sscr1;
	int ssppad0;
	int ssdr;
	int ssppad1;
	int sssr;
};

/* SSP CR0 */
#define SSPCR0_M_DSS 0x0000000F
#define SSPCR0_M_FRF 0x00000030
#define SSPCR0_M_SSE 0x00000080
#define SSPCR0_M_SCR 0x0000FF00
#define SSPCR0_V_DSS 0
#define SSPCR0_V_FRF 4
#define SSPCR0_V_SSE 7
#define SSPCR0_V_SCR 8

/* SSP CR1 */
#define SSPCR1_M_RIM 0x00000001
#define SSPCR1_M_TIN 0x00000002
#define SSPCR1_M_LBM 0x00000004
#define SSPCR1_V_RIM 0
#define SSPCR1_V_TIN 1
#define SSPCR1_V_LBM 2

/* SSP status */
#define SSPSR_M_TNF 0x00000002
#define SSPSR_M_RNE 0x00000004
#define SSPSR_M_BSY 0x00000008
#define SSPSR_M_TFS 0x00000010
#define SSPSR_M_RFS 0x00000020
#define SSPSR_M_ROR 0x00000040
#define SSPSR_V_TNF 1
#define SSPSR_V_RNE 2
#define SSPSR_V_BSY 3
#define SSPSR_V_TFS 4
#define SSPSR_V_RFS 5
#define SSPSR_V_ROR 6

#define SSP_BASE 0xA8070060
