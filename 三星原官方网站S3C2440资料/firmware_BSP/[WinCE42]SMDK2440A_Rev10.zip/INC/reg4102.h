// Copyright (c) 1999-2000 Microsoft Corporation.  All rights reserved.
/* Defines for Reference Platform control registers ( Read-only ) */

//
// Definition of ASIC register base address
//
#define REGISTERBASE    0xab000000      // ASIC I/O register base address
#define BCU_BASE        (REGISTERBASE + 0x0000)     // BCU register base address
#define DMAAU_BASE      (REGISTERBASE + 0x0020)     // DMAAU register base address
#define DCU_BASE        (REGISTERBASE + 0x0040)     // DCU register base address
#define CMU_BASE        (REGISTERBASE + 0x0060)     // CMU register base address
#define ICU_BASE        (REGISTERBASE + 0x0080)     // ICU register base address
#define PMU_BASE        (REGISTERBASE + 0x00a0)     // PMU register base address
#define RTC_BASE        (REGISTERBASE + 0x00c0)     // RTC register base address
#define DSU_BASE        (REGISTERBASE + 0x00e0)     // DSU register base address
#define GIU_BASE        (REGISTERBASE + 0x0100)     // GIU register base address
#define PIU_BASE        (REGISTERBASE + 0x0120)     // PIU register base address
#define AIU_BASE        (REGISTERBASE + 0x0160)     // AIU register base address
#define KIU_BASE        (REGISTERBASE + 0x0180)     // KIU register base address
#define RTC_BASE2       (REGISTERBASE + 0x01c0)     // RTC2 register base address
#define ICU_BASE2       (REGISTERBASE + 0x0200)     // ICU2 register base address
#define LED_BASE        (REGISTERBASE + 0x0240)     // LED register base address
#define PIU_BASE2       (REGISTERBASE + 0x02a0)     // PIU2 register base address

// BCU registers
#define BCUCNTREG       0x00        // BCU control register 1
#define BCUCNTREG2      0x02        // BCU control register 2
#define BCUSPEEDREG     0x0a        // BCU access cycle change register
#define BCUERRSTREG     0x0c        // BCU BUS error status register
#define BCURFCNTREG     0x0e        // BCU refresh control register
#define REVIDREG        0x10        // revision ID register
#define BCURFCOUNTREG   0x12        // BCU refresh count register
#define CLKSPEEDREG     0x14        // clock speed register

// DMAAU registers
#define AIUIBALREG      0x00        // AIU IN DMA base address register low
#define AIUIBAHREG      0x02        // AIU IN DMA base address register high
#define AIUIALREG       0x04        // AIU IN DMA address register low
#define AIUIAHREG       0x06        // AIU IN DMA address register high
#define AIUOBALREG      0x08        // AIU OUT DMA base address register low
#define AIUOBAHREG      0x0a        // AIU OUT DMA base address register high
#define AIUOALREG       0x0c        // AIU OUT DMA address register low
#define AIUOAHREG       0x0e        // AIU OUT DMA address register high
#define FIRBALREG       0x10        // FIR DMA base address register low
#define FIRBAHREG       0x12        // FIR DMA base address register high
#define FIRALREG        0x14        // FIR DMA address register low
#define FIRAHREG        0x16        // FIR DMA address register high

// DCU registers
#define DMARSTREG       0x00        // DMA reset register
#define DMAIDLERG       0x02        // DMA idle register
#define DMASENREG       0x04        // DMA sequencer enable register
#define DMAMSKREG       0x06        // DMA mask register
#define DMAREQREG       0x08        // DMA request register
#define DMATDREG        0x0a        // DMA transfer direction register

// CMU registers
#define CMUCLKMSK       0x00        // CMU clock mask register

// ICU registers
#define ICU_SYSINTREG   0x00        // system interrupt register
#define ICU_PIUINTREG   0x02        // PIU interrupt register
#define ICU_AIUINTREG   0x04        // AIU interrupt register
#define ICU_KIUINTREG   0x06        // KIU interrupt register
#define ICU_GIUINTREG   0x08        // GIU interrupt register
#define ICU_DSIUINTREG  0x0a        // DSIU interrupt register
#define ICU_MSYSINTREG  0x0c        // system interrupt mask register
#define ICU_MPIUINTREG  0x0e        // PIU interrupt mask register
#define ICU_MAIUINTREG  0x10        // AIU interrupt mask register
#define ICU_MKIUINTREG  0x12        // KIU interrupt mask register
#define ICU_MGIUINTREG  0x14        // GPIO[15:0] interrupt mask register
#define ICU_MDSIUINTREG 0x16        // DSIU interrupt mask register
#define ICU_NMIREG      0x18        // NMI register
#define ICU_SOFTINTREG  0x1a        // software interrupt register

// ICU2 register
#define ICU_SYSINT2REG      0x00    // system interrupt 2 register
#define ICU_GIUINTHREG      0x02    // GPIO[31:16] interrupt register
#define ICU_FIRINTHREG      0x04    // FIR interrupt register
#define ICU_MSYSINT2REG     0x06    // system interrupt mask 2 register
#define ICU_MGIUINTHREG     0x08    // GPIO [31:16] interrupt mask register
#define ICU_MFIRINTHREG     0x0a    // FIR interrupt mask register

// PMU registers
#define PMUINTREG       0x00        // PMU interrupt/status register
#define PMUCNTREG       0x02        // PMU control register

// RTC registers
#define ETIMELREG       0x00        // Elapsed time [15:0] register
#define ETIMEMREG       0x02        // Elapsed time [31:16] register
#define ETIMEHREG       0x04        // Elapsed time [47:32] register
#define ECMPLREG        0x08        // Elapsed compare [15:0] register
#define ECMPMREG        0x0a        // Elapsed compare [31:16] register
#define ECMPHREG        0x0c        // Elapsed compare [47:32] register
#define RTCLLREG        0x10        // RTC long 1 [15:0] register
#define RTCLHREG        0x12        // RTC long 1 [23:16] register
#define RTCLCNTLREG     0x14        // RTC long 1 count [15:0] register
#define RTCLCNTHREG     0x16        // RTC ling 1 count [23:16] register
#define RTCL2LREG       0x18        // RTC long 2 [15:0] register
#define RTCL2HREG       0x1a        // RTC long 2 [23:16] register
#define RTCL2CNTLREG    0x1c        // RTC long 2 count [15:0] register
#define RTCL2CNTHREG    0x1e        // RTC ling 2 count [23:16] register

#define TCLKLREG        0x00       // TCLK [15:0] register
#define TCLKHREG        0x02       // TCLK [24:16] register
#define TCLKCNTLREG     0x04       // TCLK count [15:0] register
#define TCLKCNTHREG     0x06       // TCLK count [24:16] register
#define RTCINTREG       0x1e       // RTC interrupt register

// GIU registers
#define GIUIOSELL       0x00        // GPIO[15:0] input/output select register
#define GIUIOSELH       0x02        // GPIO[31:16] input/output select register
#define GIUPIODL        0x04        // GPIO[15:0] input/output data register
#define GIUPIODH        0x06        // GPIO[31:16] input/output data register
#define GIUINTSTATL     0x08        // GPIO[15:0] interrupt status register
#define GIUINTSTATH     0x0a        // GPIO[31:16] interrupt status register
#define GIUINTENL       0x0c        // GPIO[15:0] interrupt enable register
#define GIUINTENH       0x0e        // GPIO[31:16] interrupt enable register
#define GIUINTTYPL      0x10        // GPIO[15:0] interrupt type select register
#define GIUINTTYPH      0x12        // GPIO[31:16] interrupt type select register
#define GIUINTALSELL    0x14        // GPIO[15:0] interrupt active level select register
#define GIUINTALSELH    0x16        // GPIO[31:16] interrupt active level select register
#define GIUINTHTSELL    0x18        // GPIO[15:0] interrupt hold/through select register
#define GIUINTHTSELH    0x1a        // GPIO[31:16] interrupt hold/through select register
#define GIUPODATL       0x1c        // GPIO[32:47] output data register
#define GIUPODATH       0x1e        // GPIO[49:48] output data register

// PIU registers
#define PIUCNTREG       0x02        // PIU control register
#define PIUINTREG       0x04        // PIU interrupt cause register
#define PIUSIVLREG      0x06        // PIU data sampling interval register
#define PIUSTBLREG      0x08        // PIU AD converter start delay register
#define PIUCMDREG       0x0a        // PIU AD command register
#define PIUASCNREG      0x10        // PIU AD port scan register
#define PIUAMSKREG      0x12        // PIU AD scan mask register
#define PIUCIVLREG      0x1e        // PIU check interval register

#define PIUPB00REG      0x00        // PIU page buffer 00 register
#define PIUPB01REG      0x02        // PIU page buffer 01 register
#define PIUPB02REG      0x04        // PIU page buffer 02 register
#define PIUPB03REG      0x06        // PIU page buffer 03 register
#define PIUPB10REG      0x08        // PIU page buffer 10 register
#define PIUPB11REG      0x0a        // PIU page buffer 11 register
#define PIUPB12REG      0x0c        // PIU page buffer 12 register
#define PIUPB13REG      0x0e        // PIU page buffer 13 register
#define PIUAB0REG       0x10        // PIU AD scan buffer 0 rgister
#define PIUAB1REG       0x12        // PIU AD scan buffer 1 rgister
#define PIUAB2REG       0x14        // PIU AD scan buffer 2 rgister
#define PIUAB3REG       0x16        // PIU AD scan buffer 3 rgister
#define PIUPB04REG      0x1c        // PIU page buffer 04 register
#define PIUPB14REG      0x1e        // PIU page buffer 14 register

// AIU registers
#define SDMADATREG      0x00        // speaker DMA data register
#define MDMADATREG      0x02        // mike DMA data register
#define SODATREG        0x06        // speaker output data register
#define SCNTREG         0x08        // speaker output control register
#define SCNVRREG        0x0a        // speaker conversion rate register
#define SCNVCUNTREG     0x0c        // speaker conversion count register
#define MIDATREG        0x10        // mike input data register
#define MCNTREG         0x12        // mike input control register
#define MCNVRREG        0x14        // mike conversion rate register
#define MCNVCUNTREG     0x16        // mike conversion count register
#define DVALIDREG       0x18        // data valid register
#define SEQREG          0x1a        // sequential register
#define INTREG          0x1c        // interrupt register

// KIU registers
#define KIUDAT0         0x00        // KIU data0 register
#define KIUDAT1         0x02        // KIU data1 register
#define KIUDAT2         0x04        // KIU data2 register
#define KIUDAT3         0x06        // KIU data3 register
#define KIUDAT4         0x08        // KIU data4 register
#define KIUDAT5         0x0a        // KIU data5 register
#define KIUSCANREP      0x10        // KIU scan/repeat register
#define KIUSCANS        0x12        // KIU scan status register
#define KIUWKS          0x14        // KIU wait keyscan stable register
#define KIUWKI          0x16        // KIU wait keyscan interval register
#define KIUINT          0x18        // KIU interrupt register
#define KIURST          0x1a        // KIU reset register
#define KIUGPEN         0x1c        // KIU general purpose output enable register
#define SCANLINE        0x1e        // KIU scan line register

// LED registers
#define LEDHTSREG       0x00        // LED H time set register
#define LEDLTSREG       0x02        // LED L time set register
#define LEDHLTCLREG     0x04        // LED hi time count L register
#define LEDHLTCHREG     0x06        // LED hi time count H register
#define LEDCNTREG       0x08        // LED control register
#define LEDASTCREG      0x0a        // LED auto stop time count register
#define LEDINTREG       0x0c        // LED interrupt register


// SYSINTREG
#define DozePIUIntr     (1<<13)     // Doze PIU interrupt
#define SoftIntr        (1<<11)     // Software interrupt
#define WrberrIntr      (1<<10)     // write back bus error interrupt
#define SIUIntr         (1<<9)      // SIU interrupt
#define GIUIntr         (1<<8)      // GIU interrupt
#define KIUIntr         (1<<7)      // KIU interrupt
#define AIUIntr         (1<<6)      // AIU interrupt
#define PIUIntr         (1<<5)      // PIU interrupt
#define EtimerIntr      (1<<3)      // elapsed timer interrupt
#define RtcLongIntr     (1<<2)      // RTC Long 1 interrupt
#define PowerIntr       (1<<1)      // power switch interrupt
#define BatIntr         (1<<0)      // battery alarm interrupt

// SYSINT2REG
#define DSIUIntr        (1<<5)      // DSIU interrupt
#define FIRIntr         (1<<4)      // FIR interrupt
#define TCLKIntr        (1<<3)      // TCLK interrupt
#define HSPIntr         (1<<2)      // HSP interrupt
#define LEDIntr         (1<<1)      // LED interrupt
#define RTCL2Intr       (1<<0)      // RTC long 2 interrupt

// PMUINTREG
#define GPIOIntr3       (1<<15)     // GPIO[3] interrupt
#define GPIOIntr2       (1<<14)     // GPIO[2] interrupt
#define GPIOIntr1       (1<<13)     // GPIO[1] interrupt
#define GPIOIntr0       (1<<12)     // GPIO[0] interrupt
#define DCDSTIntr       (1<<10)     // DCD signal interrupt
#define RTCIntr         (1<<9)      // elapsed timer interrupt
#define BATTINHIntr     (1<<8)      // BATTINH interrupt
#define BattLockIntr    (1<<7)      // battery lock interrupt
#define CardLockIntr    (1<<6)      // card lock interrupt
#define TimeoutRstIntr  (1<<5)      // HAL timer reset interrupt
#define RTCRSTIntr      (1<<4)      // RTC reset interrupt
#define RSTSWIntr       (1<<3)      // reset switch interrupt
#define DMSRSTIntr      (1<<2)      // deadman's switch interrupt
#define BattIntr        (1<<1)      // battery alarm interrupt
#define PowerSWIntr     (1<<0)      // power switch interrupt

// RTCINTREG
#define RTCIntr3        (1<<3)      // TCLK timer interrupt
#define RTCIntr2        (1<<2)      // RTC long 2 interrupt
#define RTCIntr1        (1<<1)      // RTC long 1 interrupt
#define RTCIntr0        (1<<0)      // Elapsed timer interrupt

// GIU interrupts
#define DCDChgIntr      (1<<15)     // DCD signal change interrupt
#define BcklightIntr    (1<<8)      // Backlight switch interrupt
#define DebugIntr       (1<<7)      // Interrupt from debug board
#define PCMCIAIntr      (1<<6)      // PCMCIA interrupt
#define PanelIntr       (1<<3)      // Touch panel cover interrupt
#define NotifyIntr      (1<<2)      // Notification switch interrupt
#define BatLockIntr     (1<<0)      // Battery lock switch interrupt

// PIU interrupt
#define PadCmdIntr      (1<<6)      // PIU command scan interrupt
#define PadADPIntr      (1<<5)      // PIU AD port scan interrupt
#define PadPage1Intr    (1<<4)      // PIU data buffer page 1 interrupt
#define PadPage0Intr    (1<<3)      // PIU data buffer page 0 interrupt
#define PadDLostIntr    (1<<2)      // PIU data lost interrupt
#define PenChgIntr      (1<<0)      // PIU pen change interrupt

// AIU interrupt
#define SPEndIntr       (1<<3)      // Speaker DMA 2 page interrupt
#define SPIntr          (1<<2)      // Speaker DMA 1 page interrupt
#define SPIdleIntr      (1<<1)      // Speaker idle interrupt

// KIU interrupt
#define KDatLostIntr    (1<<2)      // KIU key data lost interrupt
#define KDatRdyIntr     (1<<1)      // KIU key data scan interrupt
#define KScanIntr       (1<<0)      // KIU key scan interrupt

// Interrupts groupe
#define INTRGRP_TOUCH   (PadADPIntr | PadPage1Intr | PadPage0Intr | PadDLostIntr)
#define INTRGRP_KEY     (KDatLostIntr | KDatRdyIntr)
#define INTRGRP_AUDIO   (SPEndIntr | SPIntr | SPIdleIntr)
#define INTRGRP_GPIO    (BcklightIntr | NotifyIntr | BatLockIntr)
#define INTRGRP_POW     (PowerIntr | BatIntr)

//
// PMU control bits
//
#define GPIO3MSK        (1<<15)
#define GPIO2MSK        (1<<14)
#define GPIO1MSK        (1<<13)
#define GPIO0MSK        (1<<12)
#define GPIO3TRG        (1<<11)
#define GPIO2TRG        (1<<10)
#define GPIO1TRG        (1<<9)
#define GPIO0TRG        (1<<8)
#define STANDBYMOD      (1<<7)
#define HALTIMERRST     (1<<2)

/* DSU registers */
// redef error
//#define DSU_BASE         0xab0000e0   // DSU register base address
#define DSUCNTREG        0x00       // DSU control register
#define DSUSETREG        0x02       // DSU read time set register
#define DSUCLRREG        0x04       // DSU clear register
#define DSUTIMREG        0x06       // DSU elapsed time register
#define DSULOADREG       0x08       // DSU count register


// GPIO ports
#define DCDChg          (1<<15)
#define RSPWR1          (1<<14)
#define IRPWR1          (1<<13)
#define AMPPWR1         (1<<12)
#define LCDDPWR1        (1<<11)
#define LCDPWR11        (1<<10)
#define Bcklight        (1<<8)

/* Serial I/O registers */
#define SIU_BASE         0xab000140    // SIU register base address
#define SIURXDATREG      0x00       // SIU Rx data register
#define SIUTXDATREG      0x02       // SIU Tx data register
#define SIUCNTREG        0x04       // SIU control register
#define SIUDLENGTHREG    0x06       // SIU RxTx data length register
#define SIUINTREG        0x08       // SIU interrupt register
#define SIURS232CREG     0x0a       // SIU RS232C control register
#define SIUBAUDSELREG    0x0c       // SIU baudrate select register



/* PCMCIA Controller registers */
#define PCMCIA_BASE4102  0xb40003e0      //  PCMCIA control register base address
#define INDEXREG         0x00           // PCMCIA index register
#define DATAREG          0x01           // DATA write register for PCMCIA



// SOFT interrupt
// #define SoftIntr         0x0001  /* INTB interrupt  :rename or not? */

// NMI
#define NMIorINT         0x0001     /* BatIntr is NMI or INTB */

//
// Interrupt Clear Register & Bit  (W1C)
//

/* LCD display register */
#define DISP_BASE4102       0xa0000000  // LCD memory base address
                                       // VRAM area = 0x0a000000 - 0x0a1fffff(h)

// PMUINTREG
#define BatIntr_clr          0x0002     // PMUINTREG writing
#define PowerIntr_clr        0x0001     // PMUINTREG writing

// RTC Unit
#define RtcLongIntr_clr      0x0001     // RTCINTREG writing
#define AlarmIntr_clr        0x0002     // RTCINTREG writing (ElapseTimeIntr)

//PCMCIA controller
#define IsaIntr_clr_index     0x83      // PCMCIA controler's index register writing
#define IsaIntr_clr           0x0       // PCMCIA controler's DATA register writing

// PIU Unit
#define PIUIntr_clr          0x001f     // PIUINTREG writing

// ADU Unit
#define ADUIntr_clr          0x000f     // ADUINTRREG writing

// KIU Unit
#define KIUIntr_clr          0x001f     // KIUINTREG writing

// GIU Unit
#define GIsmUIntr_clr          0x1fff     // GIUINTSTREG writing

// SIU Unit
#define SIUIntr_clr          0x07ff    // SIUINTREG writing

// BCU Unit
#define BERRST              (1<<0)      // bus error reset

// Software interrupt
#define SoftIntr_clr         0x0000    // SOFTINTREG(0xab00009a) writing

// args for InitGA()
#define COLDBOOT    0
#define WARMBOOT    1

#define SAVE_ICU_REGS

// CPU registers
#define REGCPU_AT       0x00
#define REGCPU_V0       0x04
#define REGCPU_V1       0x08
#define REGCPU_A0       0x0C
#define REGCPU_A1       0x10
#define REGCPU_A2       0x14
#define REGCPU_A3       0x18
#define REGCPU_T0       0x1C
#define REGCPU_T1       0x20
#define REGCPU_T2       0x24
#define REGCPU_T3       0x28
#define REGCPU_T4       0x2C
#define REGCPU_T5       0x30
#define REGCPU_T6       0x34
#define REGCPU_T7       0x38
#define REGCPU_S0       0x3C
#define REGCPU_S1       0x40
#define REGCPU_S2       0x44
#define REGCPU_S3       0x48
#define REGCPU_S4       0x4C
#define REGCPU_S5       0x50
#define REGCPU_S6       0x54
#define REGCPU_S7       0x58
#define REGCPU_T8       0x5C
#define REGCPU_T9       0x60
#define REGCPU_K0       0x64
#define REGCPU_K1       0x68
#define REGCPU_GP       0x6C
#define REGCPU_SP       0x70
#define REGCPU_S8       0x74
#define REGCPU_RA       0x78

// CP0 registers
#define REGCP0_INDEX        0x80
#define REGCP0_RANDOM       0x84
#define REGCP0_ENTRYLO0     0x88
#define REGCP0_ENTRYLO1     0x8C
#define REGCP0_CONTEXT      0x90
#define REGCP0_PAGEMASK     0x94
#define REGCP0_WIRED        0x98
#define REGCP0_COUNT        0x9C
#define REGCP0_ENTRYHI      0xA0
#define REGCP0_COMPARE      0xA4
#define REGCP0_PSR      0xA8
#define REGCP0_CAUSE        0xAC
#define REGCP0_EPC      0xB0
#define REGCP0_CONFIG       0xB4
#define REGCP0_LLADDR       0xB8
#define REGCP0_WATCHLO      0xBC
#define REGCP0_XCONTEXT     0xC0
#define REGCP0_PERR     0xC4
#define REGCP0_TAGLO        0xC8
#define REGCP0_TAGHI        0xCC
#define REGCP0_ERROREPC     0xD0

#ifdef SAVE_ICU_REGS
#define REGGA_MSYSINTREG    0x100
#define REGGA_MPIUINTREG    0x102
#define REGGA_MAIUINTREG    0x104
#define REGGA_MKIUINTREG    0x106
#define REGGA_MGIUINTREG    0x108
#define REGGA_MDSIUINTREG   0x10A
#define REGGA_MSYSINTREG2   0x10C
#define REGGA_MGIUINTHREG   0x10E
#define REGGA_MFIRINTHREG   0x110
#endif

