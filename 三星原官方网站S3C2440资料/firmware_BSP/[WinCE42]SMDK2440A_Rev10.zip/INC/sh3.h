// Copyright (c) 1999-2000 Microsoft Corporation.  All rights reserved.

/*
SH3 Timer Registers 
*/

#define REG16BIT(x)	(*(volatile unsigned short *)(x))

// SH3 interrupt controller registers
#define INTC_PRA	REG16BIT(0xfffffee2)	// intr priority level A
#define INTC_PRB	REG16BIT(0xfffffee4)	// intr priority level B

// SH3 Timer unit registers

#define TMUADDR	((volatile struct TMU_REGS *)0xfffffe90)

struct TMU_REGS {
	BYTE	tocr;    	        // [00] timer output control (8 bit)
	BYTE	pad1;
	BYTE	tstr;		        // [02] timer start register (8 bit)
	BYTE	pad2;
	DWORD	tcor0;		        // [04] timer constant 0 (32 bit)
	DWORD	tcnt0;		        // [08] timer count 0 (32 bit)
	WORD	tcr0;		        // [0c] timer control 0 (16 bit)
	WORD	pad3;
	DWORD	tcor1;		        // [10] timer constant 1 (32 bit)
	DWORD	tcnt1;		        // [14] timer count 1 (32 bit)
	WORD	tcr1;		        // [18] timer control 1 (16 bit)
	WORD	pad4;
	DWORD	tcor2;		        // [1c] timer constant 2 (32 bit)
	DWORD	tcnt2;		        // [20] timer count 2 (32 bit)
	WORD	tcr2;		        // [24] timer control 2 (16 bit)
	WORD	pad5;
	DWORD	tcpr2;		        // [28] input capture 2 (32 bit)
};

#define RTCADDR ((volatile struct RTC_REGS *)0xfffffec0)

struct RTC_REGS {
    BYTE    r64cnt;             // [00] 64-Hz Counter        
    BYTE    pad1;
    BYTE    rseccnt;            // [02] Second Counter
    BYTE    pad2;
    BYTE    rmincnt;            // [04] Minute Counter
    BYTE    pad3;
    BYTE    rhrcnt;             // [06] Hour Counter
    BYTE    pad4;
    BYTE    rwkcnt;             // [08] Week Counter
    BYTE    pad5;
    BYTE    rdaycnt;            // [0a] Date Counter
    BYTE    pad6;
    BYTE    rmoncnt;            // [0c] Month Counter
    BYTE    pad7;
    BYTE    ryrcnt;             // [0e] Year Counter
    BYTE    pad8;
    BYTE    rsecar;             // [10] Second Counter
    BYTE    pad9;
    BYTE    rminar;             // [12] Minute alarm
    BYTE    pad10;
    BYTE    rhrar;              // [14] Hour alarm
    BYTE    pad11;
    BYTE    rwkar;              // [16] Day of week alarm
    BYTE    pad12;
    BYTE    rdayar;             // [18] Date alarm
    BYTE    pad13;
    BYTE    rmonar;             // [1a] Month alarm
    BYTE    pad14;
    BYTE    rcr1;               // [1c] RTC control register 1
    BYTE    pad15;
    BYTE    rcr2;               // [1e] RTC control register 2
};


// Bits for TSTR:
#define TMU_START0	0x01
#define TMU_START1	0x02
#define TMU_START2	0x04

// Bits for TCRn:
#define TMUCR_UNF	0x100	// counter underflowed
#define TMUCR_UNIE	0x20	// underflow interrupt enable

#define TMUCR_RISE	0x00	// count on rising edge of clock
#define TMUCR_FALL	0x08	// count on falling edge of clock
#define TMUCR_BOTH	0x10	// count on both edges of clock

#define TMUCR_D4	0x00	// PERIPHERAL clock / 4
#define TMUCR_D16	0x01	// PERIPHERAL clock / 16
#define TMUCR_D64	0x02	// PERIPHERAL clock / 64
#define TMUCR_D256	0x03	// PERIPHERAL clock / 256
#define TMUCR_RTC	0x04	// real time clock output (16 kHz)
#define TMUCR_EXT	0x05	// external clock input

