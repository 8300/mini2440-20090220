// Copyright (c) 1999-2000 Microsoft Corporation.  All rights reserved.
/* Defines for Reference Platform control registers ( Read-only ) */
/*	File Specific to Mips R4300 Cpu 			  */

#if defined(R4300) || defined(IDT32364)
//
// Definition of ASIC register base address
//

#define REGISTERBASE       0xab000000      // ASIC I/O register base address
#define RTC_BASE           0xa8000000      // RTC register base address

// Defines for DS 1685/1687 RTC chip used for R4300 Cpu board
#define RTC_SECS           (RTC_BASE+0x00)      // Seconds (0-59)
#define RTC_SECS_ALARM     (RTC_BASE+0x01)      // Seconds Alarm (0-59)
#define RTC_MINUTES        (RTC_BASE+0x02)      // Minutes (0-59)
#define RTC_MINUTES_ALARM  (RTC_BASE+0x03)      // Minutes Alarm (0-59)
#define RTC_HOURS          (RTC_BASE+0x04)      // Hours (1-12)
#define RTC_HOURS_ALARM    (RTC_BASE+0x05)      // Hours Alarm (1-12)
                                                //    or (0-23)
#define RTC_DAYOFWEEK      (RTC_BASE+0x06)      // Day of week (1-7)
#define RTC_DAYOFMONTH     (RTC_BASE+0x07)      // Day of Month (1-31)
#define RTC_MONTH          (RTC_BASE+0x08)      // Month (1-12)
#define RTC_YEAR           (RTC_BASE+0x09)      // Day of Year (0-99)

#define RTC_REG_A          (RTC_BASE+0x0A)      // Register A
#define RTC_REG_B          (RTC_BASE+0x0B)      // Register B
#define RTC_REG_C          (RTC_BASE+0x0C)      // Register C - READ-ONLY
#define RTC_REG_D          (RTC_BASE+0x0D)      // Register D - READ-ONLY

#define RTC_EXT_REG_A      (RTC_BASE+0x4A)      // Extended Register A
#define RTC_EXT_REG_B      (RTC_BASE+0x4B)      // Extended Register B

// RTC Register A bit map masks
#define RTC_CNTDOWN_CHAIN_ON    0x00            // (DV2) reset count down chain
                                                // 0x40 - reset, 00-enabled
#define RTC_OSC_ON              0x20            // (DV1) 1 - Osc ON , 0 - OFF
#define RTC_EXT_BANKSEL         0x10            // (DV0) Extended bank select
#define RTC_EXT_BANKUNSEL       0xEF            // (DV0) Extended bank Unselect
#define RTC_BANK0_SEL           0x00            // (DV0) 0 - BANK0
#define RTC_1msRATE_SEL        	0x06            // (RS3-RS0) 976 Us,EREGB-0
#define RTC_15msRATE_SEL        0x0A            // (RS3-RS0) 15.625 ms,EREGB-0
#define RTC_31msRATE_SEL        0x0B            // ( -"-)  31.25ms      EREGB-0

// RTC Register B bit map masks
#define RTC_UPDATE_INHIBIT      0x80            // (SET) while reading time
                                                //   inhibit updates
#define RTC_PERDIC_INT_ENB      0x40            // (PIE) Peridic Int Enable
#define RTC_ALARM_INT_ENB       0x20            // (AIE) Alarm Int Enable
#define RTC_Update_INT_ENB      0x10            // (UIE) Update Int Enable
#define RTC_SQUAREWAVE_ENB      0x08            // (SQWE) Square Wave Enable
#define RTC_DATA_MODE_BIN       0x04            // (DM) Calender info in BCD
#define RTC_DATA_MODE_BCD       0x00            // (DM) Calender info in Binary
#define RTC_24HR_MODE           0x02            // (24/12) 24 hr mode
#define RTC_12HR_MODE           0x00            // (24/12) 12 hr mode
#define RTC_DAYLIGHT_SAV_ENB    0x01            // (DSE) Day light savings enb

// RTC Register C bit map masks
#define RTC_IRQF                0x80
#define RTC_PERDIC_INT_FLAG     0x40
#define RTC_ALARM_INT_FLAG      0x20
#define RTC_UPDTE_ENDEDINT_FLAG 0x10

// RTC Extended Bank Reg's - set DV0=1
#define RTC_CENTURY             (RTC_BASE+0x48) // 0-99
#define RTC_DATE_ALARM          (RTC_BASE+0x49) // Alarm on a certain day [1-31]


/* PCMCIA Contoroller registers */
#define PCMCIA_BASE4102  0xb40003e0      //  PCMCIA control register base address
#define INDEXREG         0x00           // PCMCIA index register
#define DATAREG          0x01           // DATA write register for PCMCIA



// SOFT interrupt
// #define SoftIntr         0x0001  /* INTB interrupt  :rename or not? */

// NMI
#define NMIorINT         0x0001     /* BatIntr is NMI or INTB */

//
// ROSE Interrupt Clear Register & Bit  (W1C)
//

// Software interrupt
#define SoftIntr_clr         0x0000    // SOFTINTREG(0xab00009a) writing

// args for ROSE_InitGA()
#define COLDBOOT    	0
#define WARMBOOT    	1


// CPU registers
#define REGCPU_AT       0x00
#define REGCPU_V0       0x04
#define REGCPU_V1       0x08
#define REGCPU_A0       0x0C
#define REGCPU_A1       0x10
#define REGCPU_A2       0x14
#define REGCPU_A3       0x18
#define REGCPU_T0       0x1C
#define REGCPU_T1       0x20
#define REGCPU_T2       0x24
#define REGCPU_T3       0x28
#define REGCPU_T4       0x2C
#define REGCPU_T5       0x30
#define REGCPU_T6       0x34
#define REGCPU_T7       0x38
#define REGCPU_S0       0x3C
#define REGCPU_S1       0x40
#define REGCPU_S2       0x44
#define REGCPU_S3       0x48
#define REGCPU_S4       0x4C
#define REGCPU_S5       0x50
#define REGCPU_S6       0x54
#define REGCPU_S7       0x58
#define REGCPU_T8       0x5C
#define REGCPU_T9       0x60
#define REGCPU_K0       0x64
#define REGCPU_K1       0x68
#define REGCPU_GP       0x6C
#define REGCPU_SP       0x70
#define REGCPU_S8       0x74
#define REGCPU_RA       0x78

// CP0 registers
#define REGCP0_INDEX        0x80
#define REGCP0_RANDOM       0x84
#define REGCP0_ENTRYLO0     0x88
#define REGCP0_ENTRYLO1     0x8C
#define REGCP0_CONTEXT      0x90
#define REGCP0_PAGEMASK     0x94
#define REGCP0_WIRED        0x98
#define REGCP0_COUNT        0x9C
#define REGCP0_ENTRYHI      0xA0
#define REGCP0_COMPARE      0xA4
#define REGCP0_PSR      0xA8
#define REGCP0_CAUSE        0xAC
#define REGCP0_EPC      0xB0
#define REGCP0_CONFIG       0xB4
#define REGCP0_LLADDR       0xB8
#define REGCP0_WATCHLO      0xBC
#define REGCP0_XCONTEXT     0xC0
#define REGCP0_PERR     0xC4
#define REGCP0_TAGLO        0xC8
#define REGCP0_TAGHI        0xCC
#define REGCP0_ERROREPC     0xD0
#endif	//R4300
