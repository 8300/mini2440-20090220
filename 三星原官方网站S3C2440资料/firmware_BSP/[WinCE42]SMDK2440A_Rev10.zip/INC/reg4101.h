// Copyright (c) 1999-2000 Microsoft Corporation.  All rights reserved.
/* Defines for Reference Platform control registers ( Read-only ) */
#define ICU_BASE        0xab000080   // ICU register base address
#define ICU_SYSINTREG      0x00    /* Level 1 system register */
#define ICU_PIUINTREG      0x02    /* Level 2 PIU register */
#define ICU_ADUINTREG      0x04    /* Level 2 ADU register */
#define ICU_KIUINTREG      0x06    /* Level 2 KIU register */
#define ICU_GIUINTREG      0x08    /* Level 2 GIU register */
#define ICU_SIUINTREG      0x0a    /* Level 2 SIU register */
#define ICU_MSYSINTREG     0x0c    /* Level 1 mask system register */
#define ICU_MPIUINTREG     0x0e    /* Level 2 mask PIU register */
#define ICU_MADUINTREG     0x10    /* Level 2 mask ADU register */
#define ICU_MKIUINTREG     0x12    /* Level 2 mask KIU register */
#define ICU_MGIUINTREG     0x14    /* Level 2 mask GIU register */
#define ICU_MSIUINTREG     0x16    /* Level 2 mask SIU register */
#define ICU_NMIREG         0x18    /* NMI register */
#define ICU_SOFTINTREG     0x1a    /* Soft interrupt register */

/* BCU registers */
#define BCU_BASE         0xab000000  // BCU register base address
#define BCUCNTREG        0x00        // BCU control register
#define BCUBRREG         0x02        // BCU Bus restrain register
#define BCUBRCNTREG      0x04        // BCU Bus restrain count register
#define BCUBCLREG        0x06        // BCU CPU restrain clear register
#define BCUBCLCNTREG     0x08        // BCU CPU restrain clear count register
#define BCUSPEEDREG      0x0a        // BCU Access cycle change register
#define BCUERRENREG      0x0c        // BCU Bus error enable register
#define BCUERRCNTREG     0x0e        // BCU reflesh counter register
#define	PREVIDREG	 0x10	     // G/A revision ID

/* DMA Adress registers */
#define DMAAD_BASE       0xab000020  // DMA address register base address
#define PADDMAADRLREG    0x00        // PAT DMA address Low register
#define PADDMAADRHREG    0x02        // PAT DMA address High register
#define SRXDMAADRLREG    0x04        // Serial Rx DMA Address Low register
#define SRXDMAADRHREG    0x06        // Serial Rx DMA Address High register
#define STXDMAADRLREG    0x08        // Serial Tx DMA Address Low register
#define STXDMAADRHREG    0x0a        // Serial Tx DMA Address High register
#define AUDDMAADRLREG    0x0c        // Audio DMA Address Low register
#define AUDDMAADRHREG    0x0e        // Audio DMA Address High register
#define KEYDMAADRLREG    0x10        // Key DMA Address Low register
#define KEYDMAADRHREG    0x12        // Key DMA Address High register

/* DMA Controller register */
#define DMAC_BASE        0xab000040  // DMA control register base address
#define DMARSTREG        0x00        // DMA reset register
#define DMAIDLEREG       0x02        // DMA Idle register
#define DMASENREG        0x04        // DMA sequencer enable register
#define DMAMSKREG        0x06        // DMA mask register
#define DMAREQREG        0x08        // DMA request register

/* CMU register */
#define CMU_BASE         0xab000060  // CMU register base address
#define CMUCTLREG        0x00        // CMU control register

/* Power Management registers */
#define PMU_BASE         0xab0000a0  // PMU register base address
#define PMUINTREG        0x00        // PMU interrupt/status register
#define PMUCNTREG        0x02        // PMU control register



/* Interval Timer & RTC Registers */
#define RTCU_BASE        0xab0000c0     // Interrupt register base address
#define ETIMELREG        0x04      /* Elapsed time L register */
#define ETIMEMREG        0x06      /* Elapsed time M register */
#define ETIMEHREG        0x08      /* Elapsed time H register */
#define ECMPHREG         0x0a      /* Elapsed compare L register */
#define ECMPLREG         0x0c      /* Elapsed compare M register */
#define ECMPMREG         0x0e      /* Elapsed compare H register */
#define RTCLLREG         0x10      /* RTC long L register */
#define RTCLHREG         0x12      /* RTC long H register */
#define RTCLCNTLREG      0x14      /* RTC long count L register */
#define RTCLCNTHREG      0x16      /* RTC long count H register */
#define TCLKCNTLREG      0x18      /* TCLK count L register */
#define TCLKCNTHREG      0x1a      /* TCLK count H register */
#define RTCINTREG        0x1c      /* RTC interrupt register */

/* DSU registers */
#define DSU_BASE         0xab0000e0   // DSU register base address
#define DSUCNTREG        0x00       // DSU control register
#define DSUSETREG        0x02       // DSU read time set register
#define DSUCLRREG        0x04       // DSU clear register
#define DSUTIMREG        0x06       // DSU elapsed time register
#define DSULOADREG       0x08       // DSU count register

/* GPIO registers */
#define GIU_BASE         0xab000100     // GIU register base address
#define GOUTENREG        0x00       // GPIO output enable register
#define GPOTDATREG       0x02       // GPIO port data register
#define GINTSTREG        0x04       // GPIO interrupt status register
#define GINTENREG        0x06       // GPIO interrupt enable register
#define GCINTSREG        0x08       // GPIO change point interrupt register
#define GLINTSREG        0x0a       // GPIO interrupt Level specified register

/* Touch Panel Controller registers */
#define PIU_BASE         0xab000120     // PIU register base address
#define PIUDATAREG       0x00       // PIU Touch panel point data register
#define PIUCNTREG        0x02       // PIU control register
#define PIUINTREG        0x04       // PIU interrupt couse register
#define PIUSIVLREG       0x06       // PIU data sampling interval register
#define PIUSTBLREG       0x08       // PIU AD converter start delay register
#define	PIUDOZEREG	0x0a

/* Serial I/O registers */
#define SIU_BASE         0xab000140    // SIU register base address
#define SIURXDATREG      0x00       // SIU Rx data register
#define SIUTXDATREG      0x02       // SIU Tx data register
#define SIUCNTREG        0x04       // SIU control register
#define SIUDLENGTHREG    0x06       // SIU RxTx data length register
#define SIUINTREG        0x08       // SIU interrupt register
#define SIURS232CREG     0x0a       // SIU RS232C control register
#define SIUBAUDSELREG    0x0c       // SIU baudrate select register



/* Audio registers */
#define ADU_BASE         0xab000162    // ADU register base address
#define ADUDATREG        0x00       // ADU data register
#define ADURESETREG      0x02       // ADU reset register
#define ADUMODEREG       0x04       // ADU Mode select register
#define ADUSEQENREG      0x06       // ADU Sequencer enable register
#define ADUMUTEREG       0x08       // ADU Mute control register
#define ADUSTATREG       0x0a       // ADU status register
#define ADUSTPPAGEREG    0x0c       // ADU DMA stop at page register
#define ADUVALIDREG      0x0e       // ADU counter valid bits register
#define ADUINTRREG       0x10       // ADU interrupt register
#define ADUCOUNT0REG     0x12       // ADU counter 0 register
#define ADUCOUNT1REG     0x14       // ADU counter 1 register
#define ADUREPNUMREG     0x16       // ADU PWM repeat number register
#define ADUBUSENREG      0x18       // ADU bus I/F enable register


/* Key Scanner register */
#define KIU_BASE         0xab000180      // KIU register base address
#define KIUDATREG        0x00       // KIU Keydata register
#define KIUASCANREG      0x04       // KIU Key auto scan register
#define KIUASTOPREG      0x06       // KIU Key auto stop register
#define KIUSCANREG       0x08       // KIU Key scan register
#define KIUSTOPREG       0x0a       // KIU Key stop register
#define KIUSAPREG        0x0c       // KIU Key stop at page register
#define KIUSCANSREG      0x0e       // KIU Scan status register
#define KIUWKSREG        0x10       // KIU Wait keyscan stable register
#define KIUWKIREG        0x12       // KIU Wait keyscan interval register
#define KIUSRNREG        0x14       // KIU stop repeat number register
#define KIUINTREG        0x16       // KIU interrupt register
#define	KIURSTREG        0x18       // KIU reset register
#define	KIUENREG         0x1a       // KIU enable register
#define	KIUDOZEREG	0x1c

// Level 1 system interrupt / mask
#define BatIntr     0x0001       /* Battery is decreased when power on */
#define PowerIntr   0x0002       /* PowerSW is ON when power on */
#define RtcLongIntr 0x0004       /* Interrupt from RTC Long counter */
#define AlarmIntr   0x0008       /* Compare the value of ElapseTimeX register with the value of ElapseCmpX registers */
#define IsaIntr     0x0010       /* Interrupt from PCMCIA controller */
#define PIUIntr     0x0020       /* Interrupt from PIU unit */
#define ADUIntr     0x0040       /* Interrupt from ADU unit */
#define KIUIntr     0x0080       /* Interrupt from KIU unit */
#define GIUIntr     0x0100       /* Interrupt from GIU unit */
#define SIUIntr     0x0200       /* Interrupt from SIU unit */
#define WrberrIntr  0x0400       /* Inform Bus Error */
#define SoftIntr    0x0800       /* Interrupt from SOFTINTREG */

// Level 2 PIU interrupt / mask
#define PadChgIntr       0x0001  /* Detects Pen touches Pad panel and releases it */
#define PadDataRdyIntr   0x0002  /* Indicates to finish scanning a set of Pad data */
#define PadDataLostIntr  0x0004  /* Lost scan data */
#define PadIntr          0x0008  /* Crossed the Pad data to a page boundary in DMA transfer */
#define PadEndIntr       0x0010  /* Crossed the Pad data to a page boundary in the case of acting KeyInter in DMA transfer */

// Level 2 ADU interrupt / mask
#define AudioStartIntr   0x0001  /* Informs ADU ceaquencer starts operating for new combination "M" and "N" */
#define AudioIDLEIntr    0x0002  /* Informs ADU ceaquencer's status is IDLE */
#define AudIntr          0x0004  /* Crossed the Audio data to a page boundary in DMA transfer */
#define AudioEndIntr     0x0008  /* Crossed the Audio data to a page boundary in the case of acting AudioIntr in DMA transfer */

// Level 2 KIU interrupt / mask
#define KeySenseIntr     0x0001  /* Detects Key input */
#define KeyDataRdyIntr   0x0002  /* Indicates to finish scanning a set of key data */
#define KeyDataLostIntr  0x0004  /* Lost scan data */
#define KeyIntr          0x0008  /* Crossed the Key data to a page boundary in DMA transfer */
#define KeyEndIntr       0x0010  /* Crossed the Key data to a page boundary in the case of acting KeyIntr in DMA transfer */

// Level 2 GIU interrupt / mask
#define CardLockIntr     0x0001   /* Sets Interrupt in the case of changing the port's level */
#define BattLockIntr     0x0200   /* Sets Interrupt in the case of changing the port's level */
#define LcdRstIntr       0x0004   /* Sets Interrupt in the case of changing the port's level */
#define LcdBrupIntr      0x0008   /* Sets Interrupt in the case of changing the port's level */
#define LcdBrdnIntr      0x0010   /* Sets Interrupt in the case of changing the port's level */
#define DebIntIntr       0x0020   /* Sets Interrupt in the case of changing the port's level */
#define SIOPowEnIntr     0x0040  /* Sets Interrupt in the case of changing the port's level */
#define IrdaPowEnIntr    0x0080  /* Sets Interrupt in the case of changing the port's level */
#define PadPowEnIntr     0x0100  /* Sets Interrupt in the case of changing the port's level */
#define LcdPwrIntr       0x0200  /* Sets Interrupt in the case of changing the port's level */
#define LcdDpwrIntr      0x0400  /* Sets Interrupt in the case of changing the port's level */
#define GPIO2            0x0800   /* reserved */
#define GPIO1            0x8000   /* reserved */
#define GIUmask          0x7000    /* If you use G/A Ver 1.0 , you must mask on bit12 - 14. */
#define DCDChg		 0x2000   /* Sets Interrupt in the case of changing the port's level */
// Level 2 SIU interrupt /mask
#define txIntr           0x0001  /* Crossed the send data to a page boundary in DMA transfer */
#define txEndIntr        0x0002  /* Crossed the send data to a page boundary in the case of acting txIntr in DMA transfer */
#define rxIntr           0x0004  /* Crossed the received data to a page boundary in DMA transfer */
#define rxEndIntr        0x0008  /* Crossed the received data to a page boundary in the case of acting rxIntr in DMA transfer */
#define rxGetCharIntr    0x0010  /* Informs to finish received character */
#define rxLostCharIntr   0x0020  /* Informs to lost a received character */
#define CTSchgIntr       0x0040  /* Changes CTS status */
#define DSRchgIntr       0x0080  /* Changes DSR status */
#define DCDchgIntr       0x0100  /* Changes DCD status */
#define FEIntr           0x0200  /* Detects flaming error */
#define BrkIntr          0x0400  /* Detects Break signal */

// SOFT interrupt
// #define SoftIntr         0x0001  /* INTB interrupt */

// NMI
#define NMIorINT         0x0001     /* BatIntr is NMI or INTB */

//
// Interrupt Clear Register & Bit  (W1C)
//

/* 
  Interrupt clear bits for each unit in G/A.
*/

// PMUINTREG
#define BatIntr_clr          0x0002     // PMUINTREG writing
#define PowerIntr_clr        0x0001     // PMUINTREG writing

// RTC Unit
#define RtcLongIntr_clr      0x0001     // RTCINTREG writing
#define AlarmIntr_clr        0x0002     // RTCINTREG writing (ElapseTimeIntr)

//PCMCIA controller
#define IsaIntr_clr_index     0x83      // PCMCIA controler's index register writing
#define IsaIntr_clr           0x0       // PCMCIA controler's DATA register writing

// PIU Unit
#define PIUIntr_clr          0x001f     // PIUINTREG writing

// ADU Unit
#define ADUIntr_clr          0x000f     // ADUINTRREG writing

// KIU Unit
#define KIUIntr_clr          0x001f     // KIUINTREG writing

// GIU Unit
#define GIUIntr_clr          0x1fff     // GIUINTSTREG writing

// SIU Unit
#define SIUIntr_clr          0x07ff    // SIUINTREG writing

// BCU Unit
#define WrberrIntr_clr       0x0001    //BCUERRENREG writing

// Software interrupt
#define SoftIntr_clr         0x0000    // SOFTINTREG(0xab00009a) writing

// args for InitGA()
#define	COLDBOOT	0
#define	WARMBOOT	1


#define	INTRGRP_TCH	(PadIntr | PadEndIntr | PadDataRdyIntr | PadDataLostIntr)
#define	INTRGRP_TCH_CHG	(PadChgIntr)
#define	INTRGRP_KEY	(KeySenseIntr | KeyDataRdyIntr | KeyDataLostIntr | KeyIntr | KeyEndIntr)
//#define	INTRGRP_SERIAL	(txIntr | txEndIntr | rxIntr | rxEndIntr | rxLostCharIntr| \
//			 CTSchgIntr | DSRchgIntr | DCDchgIntr | FEIntr | BrkIntr)
// For Debug 96.6.17
#define	INTRGRP_SERIAL	(txIntr | txEndIntr | rxIntr | rxEndIntr | rxLostCharIntr| \
			 CTSchgIntr | DSRchgIntr | FEIntr | BrkIntr)
#define	INTRGRP_AUDIO	(AudioIDLEIntr | AudIntr | AudioEndIntr)
#define INTRGRP_GPIO    (DCDChg | BattLockIntr)
#define INTRGRP_POW     (PowerIntr  | BatIntr)



#define	SAVE_ICU_REGS

// CPU registers
#define	REGCPU_AT		0x00
#define	REGCPU_V0		0x04
#define	REGCPU_V1		0x08
#define	REGCPU_A0		0x0C
#define	REGCPU_A1		0x10
#define	REGCPU_A2		0x14
#define	REGCPU_A3		0x18
#define	REGCPU_T0		0x1C
#define	REGCPU_T1		0x20
#define	REGCPU_T2		0x24
#define	REGCPU_T3		0x28
#define	REGCPU_T4		0x2C
#define	REGCPU_T5		0x30
#define	REGCPU_T6		0x34
#define	REGCPU_T7		0x38
#define	REGCPU_S0		0x3C
#define	REGCPU_S1		0x40
#define	REGCPU_S2		0x44
#define	REGCPU_S3		0x48
#define	REGCPU_S4		0x4C
#define	REGCPU_S5		0x50
#define	REGCPU_S6		0x54
#define	REGCPU_S7		0x58
#define	REGCPU_T8		0x5C
#define	REGCPU_T9		0x60
#define	REGCPU_K0		0x64
#define	REGCPU_K1		0x68
#define	REGCPU_GP		0x6C
#define	REGCPU_SP		0x70
#define	REGCPU_S8		0x74
#define	REGCPU_RA		0x78

// CP0 registers
#define	REGCP0_INDEX		0x80
#define	REGCP0_RANDOM		0x84
#define	REGCP0_ENTRYLO0		0x88
#define	REGCP0_ENTRYLO1		0x8C
#define	REGCP0_CONTEXT		0x90
#define	REGCP0_PAGEMASK		0x94
#define	REGCP0_WIRED		0x98
#define	REGCP0_COUNT		0x9C
#define	REGCP0_ENTRYHI		0xA0
#define	REGCP0_COMPARE		0xA4
#define	REGCP0_PSR		0xA8
#define	REGCP0_CAUSE		0xAC
#define	REGCP0_EPC		0xB0
#define	REGCP0_CONFIG		0xB4
#define	REGCP0_LLADDR		0xB8
#define	REGCP0_WATCHLO		0xBC
#define	REGCP0_XCONTEXT		0xC0
#define	REGCP0_PERR		0xC4
#define	REGCP0_TAGLO		0xC8
#define	REGCP0_TAGHI		0xCC
#define	REGCP0_ERROREPC		0xD0

#ifdef SAVE_ICU_REGS
#define	REGGA_MSYSINTREG	0x100
#define	REGGA_MPIUINTREG	0x102
#define	REGGA_MADUINTREG	0x104
#define	REGGA_MKIUINTREG	0x106
#define	REGGA_MGIUINTREG	0x108
#define	REGGA_MSIUINTREG	0x10A
#endif


#define BUS_SPEED_VALUE		0x2321			//Default bus speed for R4101/Odo
