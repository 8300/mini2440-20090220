// Copyright (c) 1999-2000 Microsoft Corporation.  All rights reserved.

/*
SH4 Timer Registers 
*/

#define REG16BIT(x)	(*(volatile unsigned short *)(x))

// SH4 interrupt controller registers
#define INTC_PRA	REG16BIT(0xffd00004)	// intr priority level A
#define INTC_PRB	REG16BIT(0xffd000c4)	// intr priority level B

// SH4 Timer unit registers

#define TMUADDR	((volatile struct TMU_REGS *)0xffd80000)

struct TMU_REGS {
	BYTE	tocr;    	        // [00] timer output control (8 bit)
	BYTE	pad1[3];
	BYTE	tstr;		        // [04] timer start register (8 bit)
	BYTE	pad2;
	DWORD	tcor0;		        // [08] timer constant 0 (32 bit)
	DWORD	tcnt0;		        // [0c] timer count 0 (32 bit)
	WORD	tcr0;		        // [10] timer control 0 (16 bit)
	WORD	pad3;
	DWORD	tcor1;		        // [14] timer constant 1 (32 bit)
	DWORD	tcnt1;		        // [18] timer count 1 (32 bit)
	WORD	tcr1;		        // [1c] timer control 1 (16 bit)
	WORD	pad4;
	DWORD	tcor2;		        // [20] timer constant 2 (32 bit)
	DWORD	tcnt2;		        // [24] timer count 2 (32 bit)
	WORD	tcr2;		        // [28] timer control 2 (16 bit)
	WORD	pad5;
	DWORD	tcpr2;		        // [2c] input capture 2 (32 bit)
};

#define RTCADDR ((volatile struct RTC_REGS *)0xffc80000)

struct RTC_REGS {
    BYTE    r64cnt;             // [00] 64-Hz Counter        
    BYTE    pad1[3];
    BYTE    rseccnt;            // [04] Second Counter
    BYTE    pad2[3];
    BYTE    rmincnt;            // [08] Minute Counter
    BYTE    pad3[3];
    BYTE    rhrcnt;             // [0c] Hour Counter
    BYTE    pad4[3];
    BYTE    rwkcnt;             // [10] Week Counter
    BYTE    pad5[3];
    BYTE    rdaycnt;            // [14] Date Counter
    BYTE    pad6[3];
    BYTE    rmoncnt;            // [18] Month Counter
    BYTE    pad7[3];
    WORD    ryrcnt;             // [1c] Year Counter
    WORD    pad8;
    BYTE    rsecar;             // [20] Second Counter
    BYTE    pad9[3];
    BYTE    rminar;             // [24] Minute alarm
    BYTE    pad10[3];
    BYTE    rhrar;              // [28] Hour alarm
    BYTE    pad11[3];
    BYTE    rwkar;              // [2c] Day of week alarm
    BYTE    pad12[3];
    BYTE    rdayar;             // [30] Date alarm
    BYTE    pad13[3];
    BYTE    rmonar;             // [34] Month alarm
    BYTE    pad14[3];
    BYTE    rcr1;               // [38] RTC control register 1
    BYTE    pad15[3];
    BYTE    rcr2;               // [3c] RTC control register 2
};


// Bits for TSTR:
#define TMU_START0	0x01
#define TMU_START1	0x02
#define TMU_START2	0x04

// Bits for TCRn:
#define TMUCR_UNF	0x100	// counter underflowed
#define TMUCR_UNIE	0x20	// underflow interrupt enable

#define TMUCR_RISE	0x00	// count on rising edge of clock
#define TMUCR_FALL	0x08	// count on falling edge of clock
#define TMUCR_BOTH	0x10	// count on both edges of clock

#define TMUCR_D4	0x00	// PERIPHERAL clock / 4
#define TMUCR_D16	0x01	// PERIPHERAL clock / 16
#define TMUCR_D64	0x02	// PERIPHERAL clock / 64
#define TMUCR_D256	0x03	// PERIPHERAL clock / 256
#define TMUCR_D1024 0x04    // PERIPHERAL clock / 1024
#define TMUCR_RESVD 0x05    // Reserved (cannot be set)
#define TMUCR_RTC	0x06	// real time clock output (16 kHz)
#define TMUCR_EXT	0x07	// external clock input
