/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
Copyright (c) 1995-2000 Microsoft Corporation.  All rights reserved.

Module Name:  

  cmtthal.h

Abstract:  

  this file provides headers used exclusively by the
  HAL routines

  
Functions:

  
Notes:


Revision History:

--*/

#define CPURTCSHORT_PERIOD	1       /* 1miliseconds */

//#define	kPeriodicTimerVal	0x47d	/* 1 mS at 1.15 MHz */
//#define	kPeriodicTimerVal	0x2ceb	/* 10 mS at 1.15 MHz */
//#define	kPeriodicTimerVal	0x3ee3	/* 14 mS at 1.15 MHz */
//#define	kPeriodicTimerVal	0x3b1b	/* 13 mS at 1.15 MHz */
#define kModemPeriodicValue	0x1000  // need to set this for real!

// Ok, the memory map (DRAM) is a little messy, but the following
//     guideline should help:
//
//	kScreenBufferAddr	0x80008000	(bootblit only)
//	kCmttGlobalVirtualBase	0x80009000
//	kCmttDMABufferBase	0x8000A000
//	kSWModemVariables	0x8000D000
//	FRAMEBUFFER_ADDRESS     0x80380000
//
/* cmtt memory starts at this value */
#define kStartOfCmttDRAM			  0x8001D000

/* DMA Buffers start here */
#define kCmttDMABufferBase			  0x8000A000

/* Serial buffers */
#define kCmttSerialADMABufferOffset	  0x00000000
#define kCmttSerialBDMABufferOffset	  0x00000400
#define kCmttSerialDMABufferLength	  0x00000400

// move the telcom buffer down for testing
#define kCmttTelcomOutDMABufferOffset 0x00000800
#define kCmttTelcomOutDMABufferLength 0x000000C0
#define kCmttTelcomInDMABufferOffset  0x000008C0
#define kCmttTelcomInDMABufferLength  0x000000C0
// for now, cut buffer short to match telecom.
#define kCmttAudioMonitorDMABufferOffset  0x00000980
#define kCmttAudioMonitorDMABufferLength  0x000000C0	// = kCmttTelecomOutDMABufferLength
#define kCmttAudioDMABufferOffset	  0x00000A40
#define kCmttAudioDMABufferLength	  0x00001000	// 0xC0 

/* Audio buffers (in and out are the same buffer) */
//#define kCmttAudioDMABufferOffset	  0x00000800
//#define kCmttAudioDMABufferLength	  0x00001000
//#define kCmttAudioDMABufferLength	  0x00001000

/* Telecom buffers */
//#define kCmttTelcomOutDMABufferOffset 0x00001800
//#define kCmttTelcomOutDMABufferLength 0x000000C0
//#define kCmttTelcomInDMABufferOffset  0x000018C0
//#define kCmttTelcomInDMABufferLength  0x000000C0

/* Compression buffers */
#define kCmttCompressionBufferOffset   0x00000F80
#define kCmttCompressionBufferLength   0x00000040
#define kCmttDecompressionBufferOffset 0x00001000
#define kCmttDecompressionBufferLength 0x000003C0

#define kCmttDMABufferTotalLength	  0x00001A40	// 1980

/* cmtt globals start after display buffer and go to 0xA000 */
#define ERRFALSE(exp)		extern char __ERRXX[(exp) != 0]

// changes to include struct "AUDIO_TELCOM_STATE"
//#define kCmttGlobalsLen				  88
#define kCmttGlobalsLen				  124
#define kCmttGlobalsAddr			  (kCmttDMABufferBase - kCmttGlobalsLen)
#define kCmttGlobalsVirtualBase		  0x80009000
#define kCmttGlobalsVirtualOffset	  (kCmttGlobalsAddr - kCmttGlobalsVirtualBase)
#define kCmttGlobalsMaxLen			  0x780	/* decimal 1920 bytes */

/* SW Modem variables start here */
#define kSWModemVariables			  0x8000D000
#define kSWModemVariablesLength			  0x0000D000

/*  the frame buffers for bootblit() start here.*/
#ifdef BOOTLOADER
#define kScreenBufferAddr             0x80082000
#else
#define kScreenBufferAddr             0x80002000
#endif

//  the real frame buffers are put at the end.
#define FRAMEBUFFER_ADDRESS           0x80380000
#define FBA_PHYS              	      (FRAMEBUFFER_ADDRESS & 0x1FFFFFFF)

// The amount of time we will ignore DCD events after we go to sleep
#define kDCDDebounceTime                          0x00007fff

#ifndef ASM_ONLY
#include <winbase.h>
// include sib.h for AUDIO_TELECOM_STATE
//#include <sib.h>

void BootBlit();

typedef volatile struct {
	ULONG		RTCRollover;
	ULONG		AlarmRollover;
	ULONG		Cmtt1Interrupt1Wake;
	ULONG		Cmtt1Interrupt2Wake;
	ULONG		Cmtt1Interrupt3Wake;
	ULONG		Cmtt1Interrupt4Wake;
	ULONG		Cmtt1Interrupt5Wake;
	ULONG		Cmtt1Interrupt6Wake;
// Use this for power state.
	short		autoPowerDownState;		//short		BatteriesChanged;
	short		modemActive;
	short		touchActive;
	USHORT		batteryAdcReading;
	USHORT		adcReadings[6];
	ULONG		audioRxActive;
	UCHAR		globalLedCommand[8];
	ULONG		pcmciaIREQActive;
	ULONG		journalSystemIdle;
	SYSTEMTIME	baseSystemTime;
// Added for telcom/swmdm function
//	AUDIO_TELECOM_STATE	AudioTelecomMode;
	ULONG		audioOwner;
	ULONG		wakeKey;
	ULONG		dcdSleepTime;
// Added for power management drvr.
	ULONG		Cmtt1Interrupt1Save;
	ULONG		Cmtt1Interrupt2Save;
	ULONG		Cmtt1Interrupt3Save;
	ULONG		Cmtt1Interrupt4Save;
	ULONG		Cmtt1Interrupt5Save;
	ULONG		Cmtt1Interrupt6Save;
} CmttGlobals;

// Alert at compile time if size of our structure changes versus our size constant
ERRFALSE(sizeof(CmttGlobals) == kCmttGlobalsLen);

#define CMTTGLOBALS	((CmttGlobals *) kCmttGlobalsAddr)
#endif

#define CmttGlobals_RTCRollover				0
#define CmttGlobals_AlarmRollover			4
#define CmttGlobals_Cmtt1Interrupt1Wake		8
#define CmttGlobals_Cmtt1Interrupt2Wake		12
#define CmttGlobals_Cmtt1Interrupt3Wake		16
#define CmttGlobals_Cmtt1Interrupt4Wake		20
#define CmttGlobals_Cmtt1Interrupt5Wake		24
#define CmttGlobals_Cmtt1Interrupt6Wake		28
// use this for power state.
#define CmttGlobals_autoPowerDownState		32
//#define CmttGlobals_BatteriesChanged		32
#define CmttGlobals_modemActive				34
#define CmttGlobals_touchActive				36
#define CmttGlobals_batteryAdcReading		38
#define CmttGlobals_adcReadings				40
#define CmttGlobals_audioRxActive			52
#define CmttGlobals_globalLedCommand		56
#define CmttGlobals_pcmciaIREQActive		64
#define CmttGlobals_journalSystemIdle		68
#define CmttGlobals_baseSystemTime			72
// added for telcom/swmdm function
#define CmttGlobals_audioOwner			88
#define CmttGlobals_wakeKey			92
#define CmttGlobals_dcdSleepTime		96
// Added for power management drvr.
#define CmttGlobals_Cmtt1Interrupt1Save		100
#define CmttGlobals_Cmtt1Interrupt2Save		104
#define CmttGlobals_Cmtt1Interrupt3Save		108
#define CmttGlobals_Cmtt1Interrupt4Save		112
#define CmttGlobals_Cmtt1Interrupt5Save		116
#define CmttGlobals_Cmtt1Interrupt6Save		120

/* boot blit constant */
#define kBootScreen	0xbfc00000

/* mask matrix constants */
#define kInterruptMaskMatrixRowWidthBytes 20	/* width of a row is 5 cols * 4 bytes/col */
#define kInterruptMaskMatrixColWidthBytes 4		/* width of a col is a long (4 bytes) /*

/*  wake key table. */
#define	ModemNeedResetMask	0x00000001	/* bit 0 */


#define SYSINTR_RTC_INT5MASK			kRTCMask
#define SYSINTR_RTC_ALARM_INT5MASK		kAlarmMask
#define SYSINTR_RESCHED_INT5MASK		kPeriodicMask
/*  add SYSINTR_RESCHED_INT1MASK for power management. */
#define SYSINTR_RESCHED_INT1MASK		kRescheduleMask
//#define SYSINTR_RESCHED_INT1MASK		kIntVideoDFMask

#define SYSINTR_AUDIO_INT1MASK			(kAudioSoundHalfMask | kAudioSoundFullMask)

#define SYSINTR_TELECOM_INT1MASK		(kSIBTelHalfMask |  kSIBTelFullMask)
#define SYSINTR_SIB_INT1MASK			(kSIBSF0Mask | kSIBPositiveMask)
#define SYSINTR_SIB_INT3MASK			kSIBRingDetectPosMask
#define SYSINTR_MINICARD_INT3MASK		kMiniCard2BusyPosMask
#define SYSINTR_MAGICBUS_INT2MASK		(kMagicBusTXBufferAvailableMask | kMagicBusTXErrorMask | kMagicBusEmptyMask | kMagicBusRXErrorMask | \
											kMagicBusCmdDetMask | kMagicBusDMAFullMask | kMagicBusPositiveMask | kMagicBusNegativeMask)
#define SYSINTR_IRDA_INT2MASK			(kIrDARXMask | kIrDATXMask | kIrDADMAFullMask | kIrDADMAHalfMask)
#define SYSINTR_MMODULE_INT3MASK		kMModuleCardWaitPosMask
#define SYSINTR_KEYBOARD_INT4MASK		kKeyboardAttentionNegMask
//  On-Button interrupt is no longer associated with keyboard.
//#define SYSINTR_KEYBOARD_INT5MASK		(kKeyboardSPIInPosMask | kKeyboardOnButtonPosMask)
#define SYSINTR_KEYBOARD_INT5MASK		kKeyboardSPIInPosMask
#define SYSINTR_SERIAL_INT2MASK			(kSerialRXMask | kSerialTXMask)
#define SYSINTR_SERIAL_INT3MASK			kSerialCTSPosMask
#define SYSINTR_SERIAL_INT4MASK			kSerialCTSNegMask
#define SYSINTR_SERIAL_INT5MASK			(kSerialDCDNegMask | kSerialDCDPosMask)

#define SYSINTR_PCMCIA_STATE_INT5MASK	kMModulePosMask
/*  add for power.*/
#define SYSINTR_TOUCHSAMPLE_INT1MASK    kTouchSampleMask

/* defines for interrupt mask matrix */
#define MASK_INDEX_SIB_1				0
#define MASK_INDEX_SIB_3				4
#define MASK_INDEX_SERIAL_2				8
#define MASK_INDEX_SERIAL_3				12
#define MASK_INDEX_SERIAL_4				16
#define MASK_INDEX_SERIAL_5				20
#define MASK_INDEX_KEYBOARD_4			24
#define MASK_INDEX_KEYBOARD_5			28
#define MASK_INDEX_MMODULE_3			32
#define MASK_INDEX_MINICARD_3			36
#define MASK_INDEX_MAGICBUS_2			40
#define MASK_INDEX_IRDA_2				44
#define MASK_INDEX_AUDIO_1				48
#define MASK_INDEX_TELECOM_1			52
#define MASK_INDEX_PCMCIA_STATE_5		56

#define NUM_INT_MASKS					15			/* Number of masks in the mask array */
