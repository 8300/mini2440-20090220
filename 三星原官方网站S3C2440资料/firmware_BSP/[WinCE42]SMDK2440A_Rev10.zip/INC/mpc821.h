// Copyright (c) 1999-2000 Microsoft Corporation.  All rights reserved.
/*
 * Definitions of the parameter area RAM.
 * Note that different structures are overlaid
 * at the same offsets for the different modes
 * of operation.
 *
 */


#ifndef ASM_ONLY

/***************************************************************
  Declare smc_regs structure outside of PDA to enable external 
  use in drivers.
***************************************************************/

struct smc_regs {
	volatile unsigned short	smc_smcmr;	/* SMC mode reg */
	volatile unsigned char	RESERVED34[0x2]; /* Reserved area */

	volatile unsigned char	RESERVED35; /* Reserved area */
	volatile unsigned char	smc_smce;	/* SMC event reg */

	volatile unsigned char	RESERVED36[0x3]; /* Reserved area */
	volatile unsigned char	smc_smcm;	/* SMC mask reg */

	volatile unsigned char	RESERVED37[0x6]; /* Reserved area */
};

/*****************************************************************
	HDLC parameter RAM
*****************************************************************/

struct hdlc_pram {
	/*
	 * SCC parameter RAM
	 */
	unsigned short	tbase;		/* TX BD base address */
	unsigned short	rbase;		/* RX BD base address */
	unsigned short	mrblr;		/* Rx buffer length */
	unsigned char	tfcr;		/* Tx function code */
	unsigned char	rfcr;		/* Rx function code */
	unsigned long	rstate;		/* Rx internal state */
	unsigned long	rptr;		/* Rx internal data pointer */
	unsigned short	rcount;		/* Rx internal byte count */
	unsigned short	rbptr;		/* rb BD Pointer */
	unsigned long	rtemp;		/* Rx temp */
	unsigned long	tstate;		/* Tx internal state */
	unsigned long	tptr;		/* Tx internal data pointer */
	unsigned short	tcount;		/* Tx byte count */
	unsigned short	tbptr;		/* Tx BD pointer */
	unsigned long	ttemp;		/* Tx temp */
	unsigned long	rcrc;		/* temp receive CRC */
	unsigned long	tcrc;		/* temp transmit CRC */

	/*
	 * HDLC specific parameter RAM
	 */
	unsigned char	RESERVED1[4];	/* Reserved area */
	unsigned long	c_mask;		/* CRC constant */
	unsigned long	c_pres;		/* CRC preset */
	unsigned short	crcec;		/* CRC error counter */
	unsigned short	disfc;		/* discarded frame counter */
	unsigned short	nmarc;		/* nonmatching address rx cnt */
	unsigned short	abtsc;		/* abort sequence counter */
	unsigned short	mflr;		/* maximum frame length reg */
	unsigned short	retrc;		/* frame retransmission cnt */
	unsigned short	rfthr;		/* received frames threshold */
	unsigned short	max_cnt;	/* maximum length counter */
	unsigned short	hmask;		/* user defined frm addr mask */
	unsigned short	rfcnt;		/* received frames count */
	unsigned short	haddr2;	    /* user defined frm address 2 */
	unsigned short	haddr1;	    /* user defined frm address 1 */
	unsigned short	haddr4;	    /* user defined frm address 4 */
	unsigned short	haddr3;	    /* user defined frm address 3 */
	unsigned short	tmp_mb;	    /* temp */
	unsigned short	tmp;	    /* temp */
};


/*****************************************************************
	ASYNC HDLC parameter RAM
*****************************************************************/

struct async_hdlc_pram {
	/*
	 * SCC parameter RAM
	 */
	unsigned short	tbase;		/* TX BD base address */
	unsigned short	rbase;		/* RX BD base address */
	unsigned short	mrblr;		/* Rx buffer length */
	unsigned char	tfcr;		/* Tx function code */
	unsigned char	rfcr;		/* Rx function code */
	unsigned long	rstate;		/* Rx internal state */
	unsigned long	rptr;		/* Rx internal data pointer */
	unsigned short	rcount;		/* Rx internal byte count */
	unsigned short	rbptr;		/* rb BD Pointer */
	unsigned long	rtemp;		/* Rx temp */
	unsigned long	tstate;		/* Tx internal state */
	unsigned long	tptr;		/* Tx internal data pointer */
	unsigned short	tcount;		/* Tx byte count */
	unsigned short	tbptr;		/* Tx BD pointer */
	unsigned long	ttemp;		/* Tx temp */
	unsigned long	rcrc;		/* temp receive CRC */
	unsigned long	tcrc;		/* temp transmit CRC */

	/*
	 * ASYNC HDLC specific parameter RAM
	 */
	unsigned char	RESERVED1[4];	/* Reserved area */
	unsigned long	c_mask;		/* CRC constant */
	unsigned long	c_pres;		/* CRC preset */
	unsigned short	eof;		/* end of flag character */
	unsigned short	bof;		/* begining of flag character */
	unsigned char	RESERVED2a[2];	/* Reserved area */
	unsigned short	esc;		/* control escape character */
	unsigned short	zero;		/* zero */
	unsigned char	RESERVED2b[2];	/* Reserved area */
	unsigned short	rfthr;		/* received frames threshold */
	unsigned char	RESERVED3[2];	/* Reserved area */
	unsigned char	RESERVED4[4];	/* Reserved area */
	unsigned long	txctl_tbl;	/* Tx ctl char mapping table */
	unsigned long	rxctl_tbl;	/* Rx ctl char mapping table */
	unsigned short	nof;		/* Number of opening flags */
};


/*****************************************************************
	UART parameter RAM
*****************************************************************/

/*
 * bits in uart control characters table
 */
#define	CC_INVALID	0x8000		/* control character is valid */
#define	CC_REJ		0x4000		/* don't store char in buffer */
#define	CC_CHAR		0x00ff		/* control character */

/* UART */
struct uart_pram {
	/*
	 * SCC parameter RAM
	 */
  unsigned short  tbase;      /* TX BD base address */
  unsigned short  rbase;      /* RX BD base address */
  unsigned short  mrblr;      /* Rx buffer length */
  unsigned char   tfcr;       /* Tx function code */
  unsigned char   rfcr;       /* Rx function code */
  unsigned long   rstate;     /* Rx internal state */
  unsigned long   rptr;       /* Rx internal data pointer */
  unsigned short  rcount;     /* Rx internal byte count */
  unsigned short  rbptr;      /* rb BD Pointer */
  unsigned long   rx_temp;    /* Rx temp */
  unsigned long   tstate;     /* Tx internal state */
  unsigned long   tptr;       /* Tx internal data pointer */
  unsigned short  tcount;     /* Tx byte count */
  unsigned short  tbptr;      /* Tx BD pointer */
  unsigned long   ttemp;      /* Tx temp */
  unsigned long   rcrc;       /* temp receive CRC */
  unsigned long   tcrc;       /* temp transmit CRC */

  /*
   * UART specific parameter RAM
   */
  unsigned char   RESERVED1[8];   /* Reserved area */
  unsigned short  idlc;       /* rx idle counter (internal) */
  unsigned short  max_idl;    /* maximum idle characters */
  unsigned short  parec;      /* Rx parity error counter */
  unsigned short  brkcr;      /* break count register */
  unsigned short  nosec;      /* Rx noise counter */
  unsigned short  frmer;      /* Rx framing error counter */
  unsigned short  brkln;      /* Reaceive break length */
  unsigned short  brkec;      /* Rx break character counter */
  unsigned short  uaddr2;     /* address character 2 */
  unsigned short  uaddr1;     /* address character 1 */
  unsigned short  toseq;      /* Tx out of sequence char */
  unsigned short  rtemp;      /* temp storage */
  unsigned short  cc[8];      /* Rx control characters */
  unsigned short  rccr;       /* Rx control char register */
  unsigned short  rccm;       /* Rx control char mask */
  unsigned short  rlbc;       /* Receive last break char */
};


/*****************************************************************
	BISYNC parameter RAM
*****************************************************************/

struct bisync_pram {
	/*
	 * SCC parameter RAM
	 */
    unsigned short  tbase;      /* TX BD base address */
    unsigned short  rbase;      /* RX BD base address */
    unsigned short  mrblr;      /* Rx buffer length */
    unsigned char   tfcr;       /* Tx function code */
    unsigned char   rfcr;       /* Rx function code */
    unsigned long   rstate;     /* Rx internal state */
    unsigned long   rptr;       /* Rx internal data pointer */
    unsigned short  rcount;     /* Rx internal byte count */
    unsigned short  rbptr;      /* rb BD Pointer */
    unsigned long   rtemp;      /* Rx temp */
    unsigned long   tstate;     /* Tx internal state */
    unsigned long   tptr;       /* Tx internal data pointer */
    unsigned short  tcount;     /* Tx byte count */
    unsigned short  tbptr;      /* Tx BD pointer */
    unsigned long   ttemp;      /* Tx temp */
    unsigned long   rcrc;       /* temp receive CRC */
    unsigned long   tcrc;       /* temp transmit CRC */

    /*
     * BISYNC specific parameter RAM
     */
    unsigned char   RESERVED1[4];   /* Reserved area */
    unsigned long   crcc;       /* CRC Constant Temp Value */
    unsigned short  ptcrc;      /* Preset Transmitter CRC-16/LRC */
    unsigned short  prcrc;      /* Preset Receiver CRC-16/LRC */
    unsigned short  bsync;      /* BISYNC SYNC Character */
    unsigned short  parec;      /* Receive Parity Error Counter */
    unsigned short  cc[2];      /* Rx control characters */
    unsigned short  bdle;       /* BISYNC DLE Character */
    unsigned short  cc1[4];     /* Rx control characters */
    unsigned short  rccm;       /* Receive Control Character Mask */
    unsigned short  cc2[2];     /* Rx control characters */
};

/*****************************************************************
	IOM2 parameter RAM
	(overlaid on tx bd[5] of SCC channel[2])
*****************************************************************/
struct iom2_pram {
	unsigned short	monitor_data;	/* monitor data */
	unsigned short	ci_data;	/* ci data */
	unsigned short	rstate;		/* receiver state */
	unsigned short	tstate;		/* transmitter state */
};

/*****************************************************************
	SPI/SMC parameter RAM
	(overlaid on tx bd[6,7] of SCC channel[2])
*****************************************************************/

#define	SPI_R	0x8000		/* Ready bit in BD */

struct spi_pram {
    unsigned short  tbase;      /* Tx BD Base Address */
    unsigned short  rbase;      /* Rx BD Base Address */
    unsigned short  mrblr;      /* Rx buffer length */
    unsigned char   tfcr;       /* Tx function code */
    unsigned char   rfcr;       /* Rx function code */
    unsigned long   rstate;     /* Rx internal state */
    unsigned long   rptr;       /* Rx internal data pointer */
    unsigned short  rcount;     /* Rx internal byte count */
    unsigned short  rbptr;      /* rb BD Pointer */
    unsigned long   rtemp;      /* Rx temp */
    unsigned long   tstate;     /* Tx internal state */
    unsigned long   tptr;       /* Tx internal data pointer */
    unsigned short  tcount;     /* Tx byte count */
    unsigned short  tbptr;      /* Tx BD pointer */
    unsigned long   ttemp;      /* Tx temp */
};

typedef struct smc_uart_pram {
    unsigned short  tbase;      /* Tx BD Base Address */
    unsigned short  rbase;      /* Rx BD Base Address */
    unsigned short  mrblr;      /* Rx buffer length */
    unsigned char   tfcr;       /* Tx function code */
    unsigned char   rfcr;       /* Rx function code */
    unsigned long   rstate;     /* Rx internal state */
    unsigned long   rptr;       /* Rx internal data pointer */
    unsigned short  rcount;     /* Rx internal byte count */
    unsigned short  rbptr;      /* rb BD Pointer */
    unsigned long   rtemp;      /* Rx temp */
    unsigned long   tstate;     /* Tx internal state */
    unsigned long   tptr;       /* Tx internal data pointer */
    unsigned short  tcount;     /* Tx byte count */
    unsigned short  tbptr;      /* Tx BD pointer */
    unsigned long   ttemp;      /* Tx temp */
    unsigned short  idlc;       /* Temporary IDLE Counter */
    unsigned short  max_idl;    /* Maximum IDLE Characters */
    unsigned short  brkec;      /* Rx Break Condition Counter */
    unsigned short  brkln;      /* Last Rx Break Length */
    unsigned short  r_mask;     /* Temporary bit mask */
    unsigned short  brkcr;      /* Break Count Register (Tx) */
}smc_uart_pram;

typedef struct smc_trnsp_pram {
    unsigned short  tbase;      /* Tx BD Base Address */
    unsigned short  rbase;      /* Rx BD Base Address */
    unsigned short  mrblr;      /* Rx buffer length */
    unsigned char   tfcr;       /* Tx function code */
    unsigned char   rfcr;       /* Rx function code */
    unsigned long   rstate;     /* Rx internal state */
    unsigned long   rptr;       /* Rx internal data pointer */
    unsigned short  rcount;     /* Rx internal byte count */
    unsigned short  rbptr;      /* rb BD Pointer */
    unsigned long   rtemp;      /* Rx temp */
    unsigned long   tstate;     /* Tx internal state */
    unsigned long   tptr;       /* Tx internal data pointer */
    unsigned short  tcount;     /* Tx byte count */
    unsigned short  tbptr;      /* Tx BD pointer */
    unsigned long   ttemp;      /* Tx temp */
    unsigned short  reserved[5];    /* Reserved */
} smc_trnsp_pram;

typedef struct centronics_pram {
   unsigned short  tbase;      /* Tx BD Base Address */
   unsigned short  rbase;      /* Rx BD Base Address */
   unsigned short  mrblr;      /* Rx buffer length */
   unsigned char   smask;      /* Status Mask */
   unsigned char   fcr;        /* function code */
   unsigned long   rstate;     /* Rx internal state */
   unsigned long   rptr;       /* Rx internal data pointer */
   unsigned short  rcount;     /* Rx internal byte count */
   unsigned short  rbptr;      /* rb BD Pointer */
   unsigned long   rtemp;      /* Rx temp */
   unsigned long   tstate;     /* Tx internal state */
   unsigned long   tptr;       /* Tx internal data pointer */
   unsigned short  tcount;     /* Tx byte count */
   unsigned short  tbptr;      /* Tx BD pointer */
   unsigned long   ttemp;      /* Tx temp */
   unsigned short  sl_cnt;     /* Silence Counter */
   unsigned short  max_sl;     /* Maximum Silence period */
   unsigned short  char2;      /* CONTROL char 2 */
   unsigned short  char1;      /* CONTROL char 1 */
   unsigned short  char4;      /* CONTROL char 4 */
   unsigned short  char3;      /* CONTROL char 3 */
   unsigned short  char6;      /* CONTROL char 6 */
   unsigned short  char5;      /* CONTROL char 5 */
   unsigned short  char8;      /* CONTROL char 8 */
   unsigned short  char7;      /* CONTROL char 7 */
   unsigned short  rccr;       /* Rx Char Control Register */
   unsigned short  rccm;       /* Rx Control Char Mask */
} centronics_pram;

struct idma_pram {
	unsigned short	ibptr;	/* IDMA buffer descriptor pointer */
	unsigned short	ibase;	/* IDMA BD Base Address */
	unsigned long	istate;	/* IDMA internal state */
	unsigned long	itemp;	/* IDMA temp */
};

struct ethernet_pram {
	/*
	 * SCC parameter RAM
	 */
	unsigned short	tbase;		/* TX BD base address */
	unsigned short	rbase;		/* RX BD base address */
	unsigned short	mrblr;		/* Rx buffer length */
	unsigned char	tfcr;		/* Tx function code */
	unsigned char	rfcr;		/* Rx function code */
	unsigned long	rstate;		/* Rx internal state */
	unsigned long	rptr;		/* Rx internal data pointer */
	unsigned short	rcount;		/* Rx internal byte count */
	unsigned short	rbptr;		/* rb BD Pointer */
	unsigned long	rtemp;		/* Rx temp */
	unsigned long	tstate;		/* Tx internal state */
	unsigned long	tptr;		/* Tx internal data pointer */
	unsigned short	tcount;		/* Tx byte count */
	unsigned short	tbptr;		/* Tx BD pointer */
	unsigned long	ttemp;		/* Tx temp */
	unsigned long	rcrc;		/* temp receive CRC */
	unsigned long	tcrc;		/* temp transmit CRC */

	/*
	 * ETHERNET specific parameter RAM
	 */
	unsigned long	c_pres;		/* preset CRC */
	unsigned long	c_mask;		/* constant mask for CRC */
	unsigned long	crcec;		/* CRC error counter */
	unsigned long	alec;		/* alighnment error counter */
	unsigned long	disfc;		/* discard frame counter */
	unsigned short	ret_lim;	/* retry limit threshold */
	unsigned short	pads;		/* short frame PAD characters */
	unsigned short	mflr;		/* maximum frame length reg */
	unsigned short	ret_cnt;	/* retry limit counter */
	unsigned short	maxd1;		/* maximum DMA1 length reg */
	unsigned short	minflr;		/* minimum frame length reg */
	unsigned short	maxd;		/* rx max DMA */
	unsigned short	maxd2;		/* maximum DMA2 length reg */
	unsigned short	max_b;		/* max bd byte count */
	unsigned short	dma_cnt;	/* rx dma counter */
	unsigned short	gaddr2;		/* group address filter 2 */
	unsigned short	gaddr1;		/* group address filter 1 */
	unsigned short	gaddr4;		/* group address filter 4 */
	unsigned short	gaddr3;		/* group address filter 3 */
	unsigned long	tbuf0_data0;	/* save area 0 - current frm */
	unsigned long	tbuf0_data1;	/* save area 1 - current frm */
	unsigned long	tbuf0_rba0;
	unsigned long	tbuf0_crc;
	unsigned short	paddr_h;	/* physical address (MSB) */
	unsigned short	tbuf0_bcnt;
	unsigned short	paddr_l;	/* physical address (LSB) */
	unsigned short	paddr_m;	/* physical address */
	unsigned short	rfbd_ptr;	/* rx first bd pointer */
	unsigned short	p_per;		/* persistence */
	unsigned short	tlbd_ptr;	/* tx last bd pointer */
	unsigned short	tfbd_ptr;	/* tx first bd pointer */
	unsigned long	tbuf1_data0;	/* save area 0 - next frame */
	unsigned long	tbuf1_data1;	/* save area 1 - next frame */
	unsigned long	tbuf1_rba0;
	unsigned long	tbuf1_crc;
	unsigned short	tx_len;		/* tx frame length counter */
	unsigned short	tbuf1_bcnt;
	unsigned short	iaddr2;		/* individual address filter 2*/
	unsigned short	iaddr1;		/* individual address filter 1*/
	unsigned short	iaddr4;		/* individual address filter 4*/
	unsigned short	iaddr3;		/* individual address filter 3*/
	unsigned short	taddr_h;	/* temp address (MSB) */
	unsigned short	boff_cnt;	/* back-off counter */
	unsigned short	taddr_l;	/* temp address (LSB) */
	unsigned short	taddr_m;	/* temp address */
};

struct transparent_pram {
	/*
	 * SCC parameter RAM
	 */
    unsigned short  tbase;      /* TX BD base address */
    unsigned short  rbase;      /* RX BD base address */
    unsigned short  mrblr;      /* Rx buffer length */
    unsigned char   tfcr;       /* Tx function code */
    unsigned char   rfcr;       /* Rx function code */
    unsigned long   rstate;     /* Rx internal state */
    unsigned long   rptr;       /* Rx internal data pointer */
    unsigned short  rcount;     /* Rx internal byte count */
    unsigned short  rbptr;      /* rb BD Pointer */
    unsigned long   rtemp;      /* Rx temp */
    unsigned long   tstate;     /* Tx internal state */
    unsigned long   tptr;       /* Tx internal data pointer */
    unsigned short  tcount;     /* Tx byte count */
    unsigned short  tbptr;      /* Tx BD pointer */
    unsigned long   ttemp;      /* Tx temp */
    unsigned long   rcrc;       /* temp receive CRC */
    unsigned long   tcrc;       /* temp transmit CRC */

    /*
     * TRANSPARENT specific parameter RAM
     */
    unsigned long   crc_p;      /* CRC Preset */
    unsigned long   crc_c;      /* CRC constant */
};

struct timer_pram {
	/*
	 * RISC timers parameter RAM
	 */
	unsigned short	tm_ptr;		/* RISC timer table pointer */
	unsigned short	tm_base;	/* RISC timer table base adr */
	unsigned short	r_tmv;		/* RISC timer valid register */
	unsigned short	r_tmr;		/* RISC timer mode register */
	unsigned long	tm_cmd;		/* RISC timer cmd register */
	unsigned long	tm_cnt;		/* RISC timer internal cnt */
};

struct ucode_pram {
	/*
	 * RISC ucode parameter RAM
	 */
	unsigned short	d_ptr;		/* MISC Dump area pointer */
	unsigned short	rev_num;	/* Ucode Revision Number */
	unsigned long	temp1;		/* MISC Temp1 */
	unsigned long	temp2;		/* MISC Temp2 */
};

struct i2c_pram {
	/*
	 * I2C parameter RAM
	 */
   unsigned short  tbase;      /* TX BD base address */
   unsigned short  rbase;      /* RX BD base address */
   unsigned short  mrblr;      /* Rx buffer length */
   unsigned char   tfcr;       /* Tx function code */
   unsigned char   rfcr;       /* Rx function code */
   unsigned long   rstate;     /* Rx internal state */
   unsigned long   rptr;       /* Rx internal data pointer */
   unsigned short  rcount;     /* Rx internal byte count */
   unsigned short  rbptr;      /* rb BD Pointer */
   unsigned long   rtemp;      /* Rx temp */
   unsigned long   tstate;     /* Tx internal state */
   unsigned long   tptr;       /* Tx internal data pointer */
   unsigned short  tcount;     /* Tx byte count */
   unsigned short  tbptr;      /* Tx BD pointer */
   unsigned long   ttemp;      /* Tx temp */
};

/*
 * definitions of PDA memory structures
 */

typedef struct pda {
/* BASE + 0x0000: INTERNAL REGISTERS */
/* SIU */
	volatile unsigned long	siu_mcr;	/* module configuration reg */
	volatile unsigned long	siu_sypcr;	/* System protection cnt */
	unsigned char   RESERVED58a[0x4];
	volatile unsigned short	siu_swsr;	/* sw service */
	unsigned char   RESERVED58b[0x2];
	volatile unsigned long	siu_sipend;	/* Interrupt pend reg */
	volatile unsigned long	siu_simask;	/* Interrupt mask reg */
	volatile unsigned long	siu_siel;	/* Interrupt edge level mask reg */
    unsigned char   RESERVED58c[0x3];
	volatile unsigned char	siu_sivec;	/* Interrupt vector */
	volatile unsigned long	siu_tesr;	/* Transfer error status */
	volatile unsigned char	RESERVED1[0xc];/* Reserved area */
	volatile unsigned long	dma_sdcr;	/* SDMA configuration reg */
	unsigned char   RESERVED55[0x4c];
/* PCMCIA */

    volatile unsigned long  pcmcia_pbr0;    /* PCCard Base   Register 0   */
    volatile unsigned long  pcmcia_por0;    /* PCCard Option Register 0   */
    volatile unsigned long  pcmcia_pbr1;    /* PCCard Base   Register 1   */
    volatile unsigned long  pcmcia_por1;    /* PCCard Option Register 1   */
    volatile unsigned long  pcmcia_pbr2;    /* PCCard Base   Register 2   */
    volatile unsigned long  pcmcia_por2;    /* PCCard Option Register 2   */
    volatile unsigned long  pcmcia_pbr3;    /* PCCard Base   Register 3   */
    volatile unsigned long  pcmcia_por3;    /* PCCard Option Register 3   */
    volatile unsigned long  pcmcia_pbr4;    /* PCCard Base   Register 4   */
    volatile unsigned long  pcmcia_por4;    /* PCCard Option Register 4   */
    volatile unsigned long  pcmcia_pbr5;    /* PCCard Base   Register 5   */
    volatile unsigned long  pcmcia_por5;    /* PCCard Option Register 5   */
    volatile unsigned long  pcmcia_pbr6;    /* PCCard Base   Register 6   */
    volatile unsigned long  pcmcia_por6;    /* PCCard Option Register 6   */
    volatile unsigned long  pcmcia_pbr7;    /* PCCard Base   Register 7   */
    volatile unsigned long  pcmcia_por7;    /* PCCard Option Register 7   */
             unsigned char  RESERVED7Ca[0x20];
    volatile unsigned long  pcmcia_pgcra;   /* General Control Register A */
    volatile unsigned long  pcmcia_pgcrb;   /* General Control Register B */
    volatile unsigned long  pcmcia_pscr;    /* Status Changed Register    */
             unsigned char  RESERVED7Cb[0x4];
    volatile unsigned long  pcmcia_pipr;    /* Input Pins Register */
             unsigned char  RESERVED7Cc[0x4];
    volatile unsigned long  pcmcia_per;     /* Interrupt Enable Register  */

	volatile unsigned char	RESERVED2[0x4];/* Reserved area */
/* MEMC */
	volatile unsigned long	memc_br0;	/* base register 0 */
	volatile unsigned long	memc_or0;	/* option register 0 */
	volatile unsigned long	memc_br1;	/* base register 1 */
	volatile unsigned long	memc_or1;	/* option register 1 */
	volatile unsigned long	memc_br2;	/* base register 2 */
	volatile unsigned long	memc_or2;	/* option register 2 */
	volatile unsigned long	memc_br3;	/* base register 3 */
	volatile unsigned long	memc_or3;	/* option register 3 */
	volatile unsigned long	memc_br4;	/* base register 3 */
	volatile unsigned long	memc_or4;	/* option register 3 */
	volatile unsigned long	memc_br5;	/* base register 3 */
	volatile unsigned long	memc_or5;	/* option register 3 */
	volatile unsigned long	memc_br6;	/* base register 3 */
	volatile unsigned long	memc_or6;	/* option register 3 */
	volatile unsigned long	memc_br7;	/* base register 3 */
	volatile unsigned long	memc_or7;	/* option register 3 */
	unsigned char	RESERVED3[0x24];	/* Reserved area */
	volatile unsigned long	memc_mar;	/* Memory address */
	volatile unsigned long	memc_mcr;	/* Memory command */
	volatile unsigned char	RESERVED4[0x4];	/* Reserved area */
	volatile unsigned long	memc_mamr;	/* Machine A mode */
	volatile unsigned long	memc_mbmr;	/* Machine B mode */
	volatile unsigned short	memc_mptpr;	/* Memory preidic timer prescalar */
	volatile unsigned short	memc_mstat;	/* Memory status */
	volatile unsigned long	memc_mdr;	/* Memory data */
	volatile unsigned char	RESERVED5[0x80];/* Reserved area */
/* SYSTEM INTEGRATION TIMERS */
	volatile unsigned short	RESERVED5A[1];	/* Reserved area */
	volatile unsigned short	simt_tbscr;	/* Time base stat&ctr */

	volatile unsigned long	simt_tbreff0;	/* Time base reference 0 */
	volatile unsigned long	simt_tbreff1;	/* Time base reference 1 */
	volatile unsigned char	RESERVED6[0x14];/* Reserved area */

	volatile unsigned char	RESERVED6A[0x2];/* Reserved area */
	volatile unsigned short	simt_rtcsc;	/* Realtime clk stat&cntr 1 */

	volatile unsigned long	simt_rtc;	/* Realtime clock */
	volatile unsigned long	simt_rtsec;	/* Realtime alarm seconds */
	volatile unsigned long	simt_rtcal;	/* Realtime alarm */
	volatile unsigned char	RESERVED56[0x10];/* Reserved area */

	volatile unsigned char	RESERVED56A[0x2];/* Reserved area */
	volatile unsigned short	simt_piscr;	/* PIT stat&ctrl */

	volatile unsigned long	simt_pitc;	/* PIT counter */
	volatile unsigned long	simt_pitr;	/* PIT */
	volatile unsigned char	RESERVED7[0x34];/* Reserved area */
/* CLOCKS, RESET */
	volatile unsigned long	clkr_sccr;	/* System clk cntrl */
	volatile unsigned long	clkr_plprcr;	/* PLL reset&ctrl */
	volatile unsigned long	clkr_rsr;	/* reset status */

    volatile unsigned long  clkr_RESERVED1[29];/* Reserved area */


/* SYSTEM INTEGRATION TIMERS AND KEYS */
    volatile unsigned long simtk_tbscrk;
    volatile unsigned long simtk_tbreff0k;
    volatile unsigned long simtk_tbreff1k;
    volatile unsigned long simtk_tbk;
    volatile unsigned long simtk_RESERVED1[4];
    volatile unsigned long simtk_rtcsck;
    volatile unsigned long simtk_rtck;
    volatile unsigned long simtk_rtseck;
    volatile unsigned long simtk_rtcalk;
    volatile unsigned long simtk_RESERVED2[4];
    volatile unsigned long simtk_piscrk;
    volatile unsigned long simtk_pitck;
    volatile unsigned long simtk_RESERVED3[14];


/* CLOCKS, RESET KEYS */
    volatile unsigned long clkrk_sccrk;
    volatile unsigned long clkrk_plprcrk;
    volatile unsigned long clkrk_rsrk;
    volatile unsigned long clkrk_RESERVED1[29];

/* UNUSED REGIONS */
    volatile unsigned long UNUSED1[0x100];
    volatile unsigned long UNUSED2[0x10];

/* LCD */
	volatile unsigned long	lcd_lccr;	/* configuration Reg */
	volatile unsigned long	lcd_lchcr;	/* Horizontal ctl Reg */
	volatile unsigned long	lcd_lcvcr;	/* Vertical ctl Reg */
	unsigned char	RESERVED67[4];
	volatile unsigned long	lcd_lcfaa;	/* Frame buffer A Address */
	volatile unsigned long	lcd_lcfba;	/* Frame buffer B Address */
	volatile unsigned char	RESERVED9a[0x3];/* Reserved area */
	volatile unsigned char	lcd_lcsr;	/* Status Reg */
	volatile unsigned char	RESERVED9b[0x4];/* Reserved area */
/* I2C */
	unsigned char	RESERVED59[3];
	volatile unsigned char	i2c_i2mod;	/* i2c mode */
	unsigned char	RESERVED60[3];
	volatile unsigned char	i2c_i2add;	/* i2c address */
	unsigned char	RESERVED61[3];
	volatile unsigned char	i2c_i2brg;	/* i2c brg */
	unsigned char	RESERVED62[3];
	volatile unsigned char	i2c_i2com;	/* i2c command */
	unsigned char	RESERVED63[3];
	volatile unsigned char	i2c_i2cer;	/* i2c event */
	volatile unsigned char	RESERVED10a[0x3];/* Reserved area */
	volatile unsigned char	i2c_i2cmr;	/* i2c mask */
	volatile unsigned char	RESERVED10b[0x88];/* Reserved area */
/* DMA */
	volatile unsigned char	RESERVED11[0x4];/* Reserved area */
	volatile unsigned long	dma_sdar;	/* SDMA address reg */
	volatile unsigned char	RESERVED13[0x3];/* Reserved area */
	volatile unsigned char	dma_sdsr;	/* SDMA status reg */
	volatile unsigned char	RESERVED14[0x3];/* Reserved area */
	volatile unsigned char	dma_sdmr;	/* SDMA mask reg */
	volatile unsigned char	RESERVED15[0x3];/* Reserved area */
	volatile unsigned char	dma_idsr1;	/* IDMA1 status reg */
	volatile unsigned char	RESERVED16[0x3];/* Reserved area */
	volatile unsigned char	dma_idmr1;	/* IDMA1 mask reg */
	volatile unsigned char	RESERVED17[0x3];/* Reserved area */
	volatile unsigned char	dma_idsr2;	/* IDMA2 status reg */
	volatile unsigned char	RESERVED18a[0x3];/* Reserved area */
	volatile unsigned char	dma_idmr2;	/* IDMA2 mask reg */
	volatile unsigned char	RESERVED18b[0x10];/* Reserved area */
/* CPM Interrupt Controller */
	volatile unsigned char	RESERVED19a[0x2];/* Reserved area */
	volatile unsigned short	cpmi_civr;	/* CP interrupt vector reg */
	volatile unsigned char	RESERVED19b[0xc];/* Reserved area */
	volatile unsigned long	cpmi_cicr;	/* CP interrupt configuration reg */
	volatile unsigned long	cpmi_cipr;	/* CP interrupt pending reg */
	volatile unsigned long	cpmi_cimr;	/* CP interrupt mask reg */
	volatile unsigned long	cpmi_cisr;	/* CP interrupt in-service reg */
/* I/O port */
	volatile unsigned short	pio_papar;	/* port A pin assignment reg */
	volatile unsigned short	pio_padir;	/* port A data direction reg */
	volatile unsigned short	pio_padat;	/* port A data register */
	volatile unsigned short	pio_paodr;	/* port A open drain reg */
	volatile unsigned char	RESERVED20[0x8];	/* Reserved area */
	volatile unsigned short	pio_pcpar;	/* port C pin assignment reg */
	volatile unsigned short	pio_pcdir;	/* port C data direction reg */
	volatile unsigned short	pio_pcdat;	/* port C data register */
	volatile unsigned short	pio_pcso;	/* port C special options */
	unsigned char	RESERVED64a[2];
	volatile unsigned short	pio_pcint;	/* port C interrupt cntrl reg */
	unsigned char	RESERVED64b[4];
	volatile unsigned short	pio_pdpar;	/* port D pin assignment reg */
	volatile unsigned short	pio_pddir;	/* port D Data Direction reg */
	volatile unsigned short	pio_pddat;	/* port D data reg */
	unsigned char	RESERVED65[2];
	volatile unsigned char	RESERVED21[0x8];	/* Reserved area */
/* CPM Timer */
	volatile unsigned char	RESERVED22a[0x2];	/* Reserved area */
	volatile unsigned short	timer_tgcr;	/* timer global configuration  reg */
	volatile unsigned char	RESERVED22b[0xc];	/* Reserved area */
	volatile unsigned short	timer_tmr2;	/* timer 2 mode reg */
	volatile unsigned short	timer_tmr1;	/* timer 1 mode reg */
	volatile unsigned short	timer_trr2;	/* timer 2 referance reg */
	volatile unsigned short	timer_trr1;	/* timer 1 referance reg */
	volatile unsigned short	timer_tcr2;	/* timer 2 capture reg */
	volatile unsigned short	timer_tcr1;	/* timer 1 capture reg */
	volatile unsigned short	timer_tcn2;	/* timer 2 counter reg */
	volatile unsigned short	timer_tcn1;	/* timer 1 counter reg */
	volatile unsigned short	timer_tmr4;	/* timer 4 mode reg */
	volatile unsigned short	timer_tmr3;	/* timer 3 mode reg */
	volatile unsigned short	timer_trr4;	/* timer 4 referance reg */
	volatile unsigned short	timer_trr3;	/* timer 3 referance reg */
	volatile unsigned short	timer_tcr4;	/* timer 4 capture reg */
	volatile unsigned short	timer_tcr3;	/* timer 3 capture reg */
	volatile unsigned short	timer_tcn4;	/* timer 4 counter reg */
	volatile unsigned short	timer_tcn3;	/* timer 3 counter reg */
	volatile unsigned short	timer_ter2;	/* timer 2 event reg */
	volatile unsigned short	timer_ter1;	/* timer 1 event reg */
	volatile unsigned short	timer_ter4;	/* timer 4 event reg */
	volatile unsigned short	timer_ter3;	/* timer 3 event reg */
	volatile unsigned char	RESERVED23[0x8];	/* Reserved area */

/* CP */
	volatile unsigned char	RESERVED24[0x2];	/* Reserved area */
	volatile unsigned short	cp_cr;		/* command register */

	volatile unsigned char	cp_resv1;	/* Reserved reg */
	volatile unsigned char	RESERVED25;	/* Reserved area */
	volatile unsigned short	cp_rccr;	/* main configuration reg */

	volatile unsigned long	cp_resv2;	/* Reserved reg */

	volatile unsigned short	cp_rctr2;	/* ram break register 2 */
	volatile unsigned short	cp_rctr1;	/* ram break register 1 */

	volatile unsigned short	cp_rctr4;	/* ram break register 4 */
	volatile unsigned short	cp_rctr3;	/* ram break register 3 */

	volatile unsigned short	cp_rter;	/* RISC timers event reg */
	volatile unsigned char	RESERVED26[0x2];	/* Reserved area */

	volatile unsigned short	cp_rtmr;	/* RISC timers mask reg */
	volatile unsigned char	RESERVED27[0x2];	/* Reserved area */

	volatile unsigned char	RESERVED28[0x14];	/* Reserved area */

/* BRG */
	volatile unsigned long	brgc1;		/* BRG1 configuration reg */
	volatile unsigned long	brgc2;		/* BRG2 configuration reg */
	volatile unsigned long	brgc3;		/* BRG3 configuration reg */
	volatile unsigned long	brgc4;		/* BRG4 configuration reg */
/* SCC registers */
	struct scc_regs {
		volatile unsigned long	scc_gsmra; /* SCC general mode reg */
		volatile unsigned long	scc_gsmrb; /* SCC general mode reg */

		volatile unsigned char	RESERVED29[0x2]; /* Reserved area */
		volatile unsigned short	scc_psmr;  /* protocol specific mode register */
		volatile unsigned short	scc_dsr;   /* SCC data sync reg */
		volatile unsigned short	scc_todr;  /* SCC transmit on demand */

		volatile unsigned char	RESERVED30[0x2];/* Reserved area */
		volatile unsigned short	scc_scce;	/* SCC event reg */

		volatile unsigned char	scc_sccs;	/* SCC status reg */
		volatile unsigned char	RESERVED31[0x1];/* Reserved area */
		volatile unsigned short	scc_sccm;	/* SCC mask reg */

		volatile unsigned char	RESERVED32[0x8]; /* Reserved area */
	} scc_regs[2], scc_null[2];
/* SMC */
	struct smc_regs smc_regs[2];
/* SPI */
	volatile unsigned char	RESERVED38a[0x2]; /* Reserved area */
	volatile unsigned short	spi_spmode;	      /* SPI mode reg */

	volatile unsigned char	RESERVED39a[0x1]; /* Reserved area */
	volatile unsigned char	spi_spie;	      /* SPI event reg */
	volatile unsigned char	RESERVED38b[0x2]; /* Reserved area */

	volatile unsigned char	RESERVED40a[0x1];	/* Reserved area */
	volatile unsigned char	spi_spim;	/* SPI mask reg */
	volatile unsigned char	RESERVED39b[0x2];	/* Reserved area */

	volatile unsigned char	RESERVED41a[0x2];	/* Reserved area */
	volatile unsigned char	spi_spcom;	/* SPI command reg */
	volatile unsigned char	RESERVED40b[0x1];	/* Reserved area */

/* PIP */
	volatile unsigned short	pip_pipc;	/* pip configuration reg */
	volatile unsigned char	RESERVED41b[0x2];	/* Reserved area */

	volatile unsigned short	pip_ptpr;	/* pip timing parameters reg */
	volatile unsigned char	RESERVED42[0x2];	/* Reserved area */

	volatile unsigned long	pip_pbdir;	/* port b data direction reg */
	volatile unsigned long	pip_pbpar;	/* port b pin assignment reg */

	volatile unsigned char	RESERVED43[0x2];	/* Reserved area */
	volatile unsigned short	pip_pbodr;	/* port b open drain reg */

	volatile unsigned long	pip_pbdat;	/* port b data reg */

	volatile unsigned char	RESERVED44[0x18];	/* Reserved area */

/* Serial Interface */
	volatile unsigned long	si_simode;	/* SI mode register */

	volatile unsigned char	si_sicmr;	/* SI command register */
	volatile unsigned char	si_sistr;	/* SI status register */
	volatile unsigned char	RESERVED45; /* Reserved area */
	volatile unsigned char	si_sigmr;	/* SI global mode register */

	volatile unsigned char	RESERVED46[0x4]; /* Reserved area */

	volatile unsigned long	si_sicr;	/* SI clock routing */
	volatile unsigned long	si_sirp;	/* SI ram pointers */

	volatile unsigned char	RESERVED47[0x10c]; /* Reserved area */

	volatile unsigned short	si_siram[0x100]; /* SI routing ram */

	volatile unsigned short	lcda_lcolr[0x100];/* lcd color Ram for Rev A.X */

	volatile unsigned char	RESERVED48[0x1000]; /* Reserved area */

/* BASE + 0x2000: user data memory */
	volatile unsigned char	udata_bd_ucode[0x400];	/*user data bd's Ucode*/
	volatile unsigned char	udata_bd_ucode2[0x400];	/*user data bd's Ucode*/
	volatile unsigned char	udata_bd[0x600];	    /*user data Ucode*/
	volatile unsigned char	ucode_ext2[0x100];	/*Extension ram for ucode2 */
	volatile unsigned char	ucode_ext[0x100];	/*Extension ram for ucode  */
	volatile unsigned char	RESERVED49[0xC00];	/* Reserved area */

/* BASE + 0x3c00: PARAMETER RAM */
	union {
		struct scc_pram {
			union {
				struct hdlc_pram	h;
				struct uart_pram	u;
				struct bisync_pram	b;
				struct transparent_pram	t;
				struct async_hdlc_pram	a;
				unsigned char	RESERVED50[0x80];
			} pscc;		/* scc parameter area (protocol dependent) */
			union {
				struct {
					struct i2c_pram	i2c;
					unsigned char	RESERVED56[0x18];
					struct idma_pram	idma1;
				} i2c_idma;
				struct {
					struct spi_pram	spi;
					unsigned char	RESERVED57[0x8];
					struct timer_pram	timer;
					struct idma_pram	idma2;
				} spi_timer_idma;
				struct {
					union {
						smc_uart_pram u;
						smc_trnsp_pram t;
						centronics_pram c;
					} psmc;
					unsigned char	modem_param[0x40];
				} smc_modem;
				struct {
					unsigned char   RESERVED54[0x30]; 
					struct ucode_pram	ucode;
				} pucode;
			} pothers;
		} scc;
		struct ethernet_pram	enet_scc;
		unsigned char	pr[0x100];
	} pram[4];

} PDA;

#endif // ASM_ONLY

//
// Define MPC8xx Special Purpose Registers
//

#define PVR        287      // Processor Version Reg.
#define DEC         22      // Decrementer Reg.
#define SRR1        27      // Save/Restore Register 1
#define ICR        148      // Instruction Compare Reg.
#define DER        149      // Debug Enable Reg.
#define ICTRL      158      // Instruction Support Control Reg.
#define IC_CST     560      // I-Cache Control/Status Reg.
#define IC_ADR     561      // I-Cache Address Reg.
#define IC_DAT     562      // I-Cache Data Reg.
#define DC_CST     568      // D-Cache Control/Status Reg.
#define DC_ADR     569      // D-Cache Address Reg.
#define DC_DAT     570      // D-Cache Data Reg.
#define IMMR       638      // Internal Memory Map Reg.
#define EIE         80      // External Interrupt Enable Reg.
#define EID         81      // External Interrupt Disable Reg.


//
// Define internal register offsets from IMMR.
//

#define MEMC_BR1_OFFSET 0x108

#define MDR_OFFSET  0x17c
#define MCR_OFFSET  0x168

#define BR0_OFFSET  0x100
#define OR0_OFFSET  0x104
#define BR1_OFFSET  0x108
#define OR1_OFFSET  0x10c
#define BR2_OFFSET  0x110
#define OR2_OFFSET  0x114
#define BR3_OFFSET  0x118
#define OR3_OFFSET  0x11c
#define MAMR_OFFSET 0x170
#define SCCR_OFFSET   0x280
#define PLPRCR_OFFSET 0x284
#define SIUMCR_OFFSET 0
#define SYPCR_OFFSET 4
#define RTCSC_OFFSET 0x220

#define MPTPR_OFFSET 0x178
#define TBSCR_OFFSET 0x202
#define PISCR_OFFSET 0x242
