/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
Copyright (c) 1995-2000 Microsoft Corporation.  All rights reserved.

@doc INTERNAL DRIVERS PDD TOUCH_PANEL

@module tchaud.h |

    This module contains structures common to the touch and audio drivers, concerning the
	layout of and definitions for the Touch/Audio ASIC.

Environment:

<tab>    Windows CE

Revision History:

--*/
#ifndef _TCHAUD_H
#define _TCHAUD_H

#define PAD(label,amt)  UCHAR Pad##label[amt]

//
// @doc INTERNAL DRIVERS PDD TOUCH_PANEL
// @struct TCHAUD_ASIC_REGISTERS |
// Layout of the Touch/Audio ASIC Registers.
//
// @field USHORT | ioAdcCntr |
// ADC Control Register
//
// @field USHORT | ioAdcStr |
// ADC Status Register
//
// @field USHORT | ucbCntr |
// UCB Control Register
//
// @field USHORT | ucbStr |
// UCB Status Register
//
// @field USHORT | ucbRegister |
// Data to be sent to UCB
//
// @field USHORT | ioSoundCntr |
// Sound Control Register
//
// @field USHORT | ioSoundStr |
// Sound Status Register
//
// @field USHORT | intrMask |
// Interrupt Mask Register
//


typedef struct {
    //
    // System Registers.
    //

    USHORT ioAdcCntr;     	// offset 0x0000
    PAD(0,0x2);
    USHORT ioAdcStr;   		// offset 0x0004
    PAD(1,0x2);
    USHORT ucbCntr;             // offset 0x0008
    PAD(2,0x2);
    USHORT ucbStr;            	// offset 0x000C
    PAD(3,0x2);
    USHORT ucbRegister;      	// offset 0x0010
    PAD(4,0x2);
    USHORT ioSoundCntr;         // offset 0x0014
    PAD(5,0x2);
    USHORT ioSoundStr;        	// offset 0x0018
    PAD(6,0x2);
    USHORT intrMask;        	// offset 0x001C
} TCHAUD_ASIC_REGISTERS, *PTCHAUD_ASIC_REGISTERS;

// Definitions for the ioAdcCntr
#define ioAdcCntrDoSample (1<<14)
#define ioAdcCntrPenState (1<<13)
#define ioAdcCntrPenTimingEn (1<<10)

// Definitions for the ioAdcStr
#define ioAdcStrPenIntr (1<<4)
#define ioAdcStrUcbIntr (1<<3)
#define ioAdcStrPenTmgIntr (1<<2)

// Definitions for the ucbCntr
#define ucbCntrUcbReset (1<<15)
#define ucbCntrUcbPowerDown (1<<14)
#define ucbCntrWriteBit (1<<4)

// Definitions for the ucbStr
#define ucbStrRegIntr (1<<0)

// Definitions for the ioSoundCntr
#define ioSoundCntrRecordEn (1<<15)
#define ioSoundCntrPlaybackEn (1<<14)

// Definitions for the ioSoundStr
#define ioSoundStrRecordIntr (1<<15)
#define ioSoundStrRecordEndIntr (1<<14)
#define ioSoundStrPlaybackIntr (1<<13)
#define ioSoundStrPlaybackEndIntr (1<<12)

// Definitions for the intrMask
#define intrMaskPenIntrMask (1<<4)
#define intrMaskUcbIntrMask (1<<3)
#define intrMaskPenTmngIntrMask (1<<2)
#define intrMaskSoundIntrMask (1<<1)
#define intrMaskRegIntrMask (1<<0)

//
// @doc INTERNAL DRIVERS PDD TOUCH_PANEL
// @struct TOUCHPANEL_POINT_SAMPLE |
//
// Defines the layout of one coordinate pair sample by the ADC.
//

typedef struct {
    USHORT XSample;     //@field X Coordinate.
    USHORT YSample;     //@field Y Coordinate.
} TOUCHPANEL_POINT_SAMPLE, *PTOUCHPANEL_POINT_SAMPLE;

// Name of mutex for accessing touch/audio registers
#define TCHAUD_MUTEX_NAME  TEXT("TCHAUD")

// Prototype functions from drvlib
#ifdef __cplusplus
extern "C" {
#endif
void TchAudLock(HANDLE hMutex, PULONG pSem);
void TchAudUnlock(HANDLE hMutex, PULONG pSem);
BOOL TchAudReadReg(USHORT Reg,USHORT *pVal,PTCHAUD_ASIC_REGISTERS pTchAudRegs,
                   BOOL bInPowerHandler);
BOOL TchAudWriteReg(USHORT Reg,USHORT Val,PTCHAUD_ASIC_REGISTERS pTchAudRegs,
                    BOOL bInPowerHandler);
BOOL TchAudAndReg(USHORT Reg,USHORT Val,PTCHAUD_ASIC_REGISTERS pTchAudRegs,
                  BOOL bInPowerHandler);
BOOL TchAudOrReg(USHORT Reg,USHORT Val,PTCHAUD_ASIC_REGISTERS pTchAudRegs,
                 BOOL bInPowerHandler);

#ifdef __cplusplus
}
#endif

    
#endif // _TCHAUD_H
