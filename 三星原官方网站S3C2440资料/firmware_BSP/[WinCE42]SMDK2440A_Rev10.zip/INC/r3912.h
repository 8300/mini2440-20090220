/*++

Copyright (c) 1996-2000 Microsoft Corporation.  All rights reserved.

Module Name:

    r3912.h

Abstract:
    I/O definition for R3912 processor internal registers.

Environment:

    Kernel mode (unmapped) only

History:

Note:
   SHx base, MIPS R4100 base not supported.

 --*/

#ifndef _R3912_H_
#define _R3912_H_

/* Defines for Reference Platform control registers */

#define R3912_SYSTEM_ASIC_REGS_BASE	0xb0c00000	// for kseg1
#define R3912_PHYSICAL_ADDR_OFFSET 	0x10c00000
#define R3912_REGS_SIZE                 0x200
/*
   BIU Register
*/

#define OFF_BIU_MEM_CONFIG0		0x000
#define BIU_ENDCLKOUTTRI		(1 << 30)
#define BIU_DISDQMINIT			(1 << 29)
#define BIU_ENSDRAMPD			(1 << 28)
#define BIU_SHOWDINO			(1 << 27)
#define BIU_ENRMAP2			(1 << 26)
#define BIU_ENRMAP1			(1 << 25)
#define BIU_ENWRINPAGE			(1 << 24)
#define BIU_ENCS3USER			(1 << 23)
#define BIU_ENCS2USER			(1 << 22)
#define BIU_ENCS1USER			(1 << 21)
#define BIU_ENCS1DRAM			(1 << 20)
#define BIU_BANK1CONFMASK		(3 << 18)
#define BIU_BANK1CONF_16SDRAM		(3 << 18)	/* Bank 1 as 16 bit SDRAM */
#define BIU_BANK1CONF_8SDRAM		(2 << 18)	/* Bank 1 as 8 bit SDRAM */
#define BIU_BANK1CONF_32DRAM		(1 << 18)	/* Bank 1 as 32 bit DRAM/HDRAM */
#define BIU_BANK1CONF_16DRAM		(0 << 18)	/* Bank 1 as 16 bit DRAM/HDRAM */
#define BIU_BANK0CONFMASK		(3 << 16)
#define BIU_BANK0CONF_16SDRAM		(3 << 16)	/* Bank 1 as 16 bit SDRAM */
#define BIU_BANK0CONF_8SDRAM		(2 << 16)	/* Bank 1 as 8 bit SDRAM */
#define BIU_BANK0CONF_32DRAM		(1 << 16)	/* Bank 1 as 32 bit DRAM/HDRAM */
#define BIU_BANK0CONF_16DRAM		(0 << 16)	/* Bank 1 as 16 bit DRAM/HDRAM */
#define BIU_ROWSEL1MASK			(3 << 14)
#define BIU_ROWSEL1_TYPE1		(0 << 14)	/* Row Address 18, 17:9 */
#define BIU_ROWSEL1_TYPE2		(1 << 14)	/* Row Address 22,18,20,19,17:9 */
#define BIU_ROWSEL1_TYPE3		(2 << 14)	/* Row Address 22,21,19,17:9 */
#define BIU_ROWSEL1_TYPE4		(3 << 14)	/* Row Address 23,21,19,17:9 */
#define BIU_ROWSEL0MASK			(3 << 12)
#define BIU_ROWSEL0_TYPE1		(0 << 12)	/* Row Address 18, 17:9 */
#define BIU_ROWSEL0_TYPE2		(1 << 12)	/* Row Address 22,18,20,19,17:9 */
#define BIU_ROWSEL0_TYPE3		(2 << 12)	/* Row Address 22,21,19,17:9 */
#define BIU_ROWSEL0_TYPE4		(3 << 12)	/* Row Address 23,21,19,17:9 */
#define BIU_COLSEL1MASK			(0xf << 8)
#define BIU_COLSEL1_TYPE1		(0 << 8)	/* Column Address 22,20,18,8:1 */
#define BIU_COLSEL1_TYPE2		(1 << 8)	/* Column Address 19,18,8:2 */
#define BIU_COLSEL1_TYPE3		(2 << 8)	/* Column Address 21,20,8:2 */
#define BIU_COLSEL1_TYPE4		(3 << 8)	/* Column Address 23,22,20,18,8:2 */
#define BIU_COLSEL1_TYPE5		(4 << 8)	/* Column Address 24,22,20,18,8:2 */
#define BIU_COLSEL1_TYPE6		(5 << 8)	/* Column Address 18,p,X,8:0 */
#define BIU_COLSEL1_TYPE7		(6 << 8)	/* Column Address 22,p,X,21,8:1 */
#define BIU_COLSEL1_TYPE8		(7 << 8)	/* Column Address 18,p,X,21,8:1 */
#define BIU_COLSEL1_TYPE9		(8 << 8)	/* Column Address 22,p,X,23,21,8:2 */
#define BUI_COLSEL1_TYPE10		(9 << 8)	/* Column Address 21,8:2 */

#define BIU_COLSEL0MASK			(0xf << 4)
#define BIU_COLSEL0_TYPE1		(0 << 4)	/* Column Address 22,20,18,8:1 */
#define BIU_COLSEL0_TYPE2		(1 << 4)	/* Column Address 19,18,8:2 */
#define BIU_COLSEL0_TYPE3		(2 << 4)	/* Column Address 21,20,8:2 */
#define BIU_COLSEL0_TYPE4		(3 << 4)	/* Column Address 23,22,20,18,8:2 */
#define BIU_COLSEL0_TYPE5		(4 << 4)	/* Column Address 24,22,20,18,8:2 */
#define BIU_COLSEL0_TYPE6		(5 << 4)	/* Column Address 18,p,X,8:0 */
#define BIU_COLSEL0_TYPE7		(6 << 4)	/* Column Address 22,p,X,21,8:1 */
#define BIU_COLSEL0_TYPE8		(7 << 4)	/* Column Address 18,p,X,21,8:1 */
#define BIU_COLSEL0_TYPE9		(8 << 4)	/* Column Address 22,p,X,23,21,8:2 */
#define BIU_COLSEL0_TYPE10		(9 << 4)	/* Column Address 21,8:2 */

#define BIU_CS3SIZE			(1 << 3)
#define BIU_CS2SIZE			(1 << 2)
#define BIU_CS1SIZE			(1 << 1)
#define BIU_CS0SIZE			1

#define OFF_BIU_MEM_CONFIG1		0x0004
#define BIU_MCS3ACCVAL1MASK		(0xf << 28)
#define BIU_MCS3ACCVAL1(a)		(((a) << 28) & BIU_MCS3ACCVAL1MASK)
#define BIU_MCS3ACCVAL2MASK		(0xf << 24)
#define BIU_MCS3ACCVAL2(a)		(((a) << 24) & BIU_MCS3ACCVAL2MASK)
#define BIU_MCS2ACCVAL1MASK		(0xf << 20)
#define BIU_MCS2ACCVAL1(a)		(((a) << 20) & BIU_MCS3ACCVAL1MASK)
#define BIU_MCS2ACCVAL2MASK		(0xf << 16)
#define BIU_MCS2ACCVAL2(a)		(((a) << 16) & BIU_MCS2ACCVAL2MASK)
#define BIU_MCS1ACCVAL1MASK		(0xf << 12)
#define BIU_MCS1ACCVAL1(a)		(((a) << 12) & BIU_MCS1ACCVAL1MASK)
#define BIU_MCS1ACCVAL2MASK		(0xf << 8)
#define BIU_MCS1ACCVAL2(a)		(((a) << 8) & BIU_MCS1ACCVAL2MASK)
#define BIU_MCS0ACCVAL1MASK		(0xf << 4)
#define BIU_MCS0ACCVAL1(a)		(((a) << 4) & BIU_MCS0ACCVAL1MASK)
#define BIU_MCS0ACCVAL2MASK		0xf
#define BIU_MCS0ACCVAL2(a)		((a) & BIU_MCS0ACCVAL2MASK)

#define OFF_BIU_MEM_CONFIG2		0x0008
#define BIU_CS3ACCVAL1MASK		(0xf << 28)
#define BIU_CS3ACCVAL1(a)		(((a) << 28) & BIU_CS3ACCVAL1MASK)
#define BIU_CS3ACCVAL2MASK		(0xf << 24)
#define BIU_CS3ACCVAL2(a)		(((a) << 24) & BIU_CS3ACCVAL2MASK)
#define BIU_CS2ACCVAL1MASK		(0xf << 20)
#define BIU_CS2ACCVAL1(a)		(((a) << 20) & BIU_CS3ACCVAL1MASK)
#define BIU_CS2ACCVAL2MASK		(0xf << 16)
#define BIU_CS2ACCVAL2(a)		(((a) << 16) & BIU_CS2ACCVAL2MASK)
#define BIU_CS1ACCVAL1MASK		(0xf << 12)
#define BIU_CS1ACCVAL1(a)		(((a) << 12) & BIU_CS1ACCVAL1MASK)
#define BIU_CS1ACCVAL2MASK		(0xf << 8)
#define BIU_CS1ACCVAL2(a)		(((a) << 8) & BIU_CS1ACCVAL2MASK)
#define BIU_CS0ACCVAL1MASK		(0xf << 4)
#define BIU_CS0ACCVAL1(a)		(((a) << 4) & BIU_CS0ACCVAL1MASK)
#define BIU_CS0ACCVAL2MASK		0xf
#define BIU_CS0ACCVAL2(a)		((a) & BIU_CS0ACCVAL2MASK)

#define OFF_BIU_MEM_CONFIG3		0x00c
#define BIU_CARD2ACCVALMASK		(0xf << 28)
#define BIU_CARD2ACCVAL(a)		(((a) << 28) & BIU_CARD2ACCVALMASK)
#define BIU_CARD1ACCVALMASK		(0xf << 24)
#define BIU_CARD1ACCVAL(a)		(((a) << 24) & BIU_CARD1ACCVALMASK)
#define BIU_CARD2IOACCVALMASK		(0xf << 20)
#define BIU_CARD2IOACCVAL(a)		(((a) << 20) & BIU_CARD2IOACCVALMASK)
#define BIU_CARD1IOACCVALMASK		(0xf << 16)
#define BIU_CARD1IOACCVAL(a)		(((a) << 16) & BIU_CARD1IOACCVALMASK)
#define BIU_ENMCS3PAGE			(1 << 15)
#define BIU_ENMCS2PAGE			(1 << 14)
#define BIU_ENMCS1PAGE			(1 << 13)
#define BIU_ENMCS0PAGE			(1 << 12)
#define BIU_ENCS3PAGE			(1 << 11)
#define BIU_ENCS2PAGE			(1 << 10)
#define BIU_ENCS1PAGE			(1 << 9)
#define BIU_ENCS0PAGE			(1 << 8)
#define BIU_CARD2WAITEN			(1 << 7)
#define BIU_CARD1WAITEN			(1 << 6)
#define BIU_CARD2IOEN			(1 << 5)
#define BIU_CARD1IOEN			(1 << 4)
#define BIU_PORT8SEL			(1 << 3)

#define OFF_BIU_MEM_CONFIG4		0x010
#define BIU_ENBANK1HDRAM		(1 << 31)
#define BIU_ENBANK0HDRAM		(1 << 30)
#define BIU_ENARB			(1 << 29)
#define BIU_DISSNOP			(1 << 28)
#define BIU_CLRWRBUSERRINT		(1 << 27)
#define BIU_ENBANK1OPT			(1 << 26)
#define BIU_ENBANK0OPT			(1 << 25)
#define BIU_ENWATCH			(1 << 24)
#define BIU_WATCHTIMEVALMASK		(0xf << 20)
#define BIU_WATCHTIMEVAL(a)		(((a) << 20) & BIU_WATCHTIMEVALMASK)
#define BIU_MEMPOWERDOWN		(1 << 16)
#define	BIU_ENRFSH1			(1 << 15)
#define	BIU_ENRFSH0			(1 << 14)
#define BIU_RFSHVAL1MASK		(0x1f << 8)
#define BIU_RFSHVAL1(a)			(((a) << 8) & BIU_RFSHVAL1MASK)
#define BIU_RFSHVAL2MASK		0x1f
#define BIU_RFSHVAL2(a)			((a) & BIU_RFSHVAL2MASK)

#define OFF_BIU_MEM_CONFIG5		0x014
#define BIU_STARTVAL2MASK		0xfffffe00
#define BIU_MASK2			0x0000000f

#define OFF_BIU_MEM_CONFIG6		0x018
#define BIU_STARTVAL1MASK		0xfffffe00
#define BIU_MASK1			0x0000000f

#define OFF_BIU_MEM_CONFIG7		0x01c
#define BIU_RMAPADD2MASK		0xfffffe00

#define OFF_BIU_MEM_CONFIG8		0x020
#define BIU_RMAPADD1MASK		0xfffffe00

/*
   SIU Module
*/
#ifdef INTERNAL_TEST
#define OFF_SIU_TEST			0x1c8
#define SIU_ENDMATEST			(1 << 7)
#define SIU_ENNOTIMETEST		(1 << 6)
#define SIU_DMATESTWRMASK		(0x3f)
#endif /* INTERNAL_TEST */

/*
  R3912 Clock Module 
*/

#define OFF_CLOCK_CTL			0x1c0
#define CLOCK_CHICLKDIVMASK		0xff000000
#define CLOCK_CHICLKDIV(a)		((a) << 24)
#define CLOCK_ENCLKTEST			(1 << 23)
#define CLOCK_TESTSELSIB		(1 << 22)
#define CLOCK_CHIMCLKSEL		(1 << 21)
#define CLOCK_CHICLKDIR			(1 << 20)
#define CLOCK_ENCHIMCLK			(1 << 19)
#define CLOCK_ENVIDCLK			(1 << 18)
#define CLOCK_ENMSUBCLK			(1 << 17)
#define CLOCK_ENSPICLK			(1 << 16)
#define CLOCK_ENTIMERCLK		(1 << 15)
#ifdef INTERNAL_TEST
#define CLOCK_FASTTIMERCLK		(1 << 14)
#endif /* INTERNAL_TEST */
#define CLOCK_SIBMCLKDIR		(1 << 13)
#define CLOCK_ENSIBMCLK			(1 << 11)
#define CLOCK_SIBMCLKDIVMASK		0x00000700
#define CLOCK_SIBMCLKDIV(a)		(((a) << 8) & CLOCK_SIBMCLKDIVMASK)
#define CLOCK_ENCSERSEL			(1 << 7)
#define CLOCK_CSERDIVMASK		0x00000070
#define CLOCK_CSERDIV(a)		(((a) << 4) & CLOCK_CSERDIVMASK)
#define CLOCK_ENCSERCLK			(1 << 3)
#define CLOCK_ENIRCLK			(1 << 2)
#define CLOCK_ENUARTACLK		(1 << 1)
#define CLOCK_ENUARTBCLK		1

/*
   CHI Module
*/
#define OFF_CHI_CTL			0x1d8
#define CHI_CHILOOP			(1 << 29)
#ifdef INTERNAL_TEST
#define CHI_CHIENTEST			(1 << 28)
#endif /* INTERNAL_TEST */
#define CHI_CHIFSDIR			(1 << 27)
#define CHI_CHIFSWIDEMASK		(3 << 25)
#define CHI_CHIFSWIDE_1BIT		0
#define CHI_CHIFSWIDE_2BIT		(1 << 25)
#define CHI_CHIFSWIDE_1BYTE		(2 << 25)
#define CHI_CHIFSWIDE_NCHAN		(3 << 25)
#define CHI_CHINCHANMASK		(0x1f << 20)
#define CHI_CHINCHAN(a)			(((a) << 20) & CHI_CHINCHANMASK)
#define CHI_CHITXBOFFMASK		(0xf << 16)
#define CHI_CHITXBOFF(a)		(((a) << 16) & CHI_CHITXBOFFMASK)
#define CHI_CHIRXBOFFMASK		(0xf << 12)
#define CHI_CHIRXBOFF(a)		(((a) << 12) & CHI_CHIRXBOFFMASK)
#define CHI_TXMSBFIRST			(1 << 11)
#define CHI_RXMSBFIRST			(1 << 10)
#define CHI_CHIRXFSPOL			(1 << 9)
#define CHI_CHITXFSPOL			(1 << 8)
#define CHI_CHIRXEDGE			(1 << 7)
#define CHI_CHITXEDGE			(1 << 6)
#define CHI_CHIFSEDGE			(1 << 5)
#define CHI_CHITXFSEDGE			(1 << 4)
#define CHI_CHICLK2XMODE		(1 << 3)
#define CHI_CHIRXEN			(1 << 2)
#define CHI_CHITXEN			(1 << 1)
#define CHI_ENCHI			1

#define OFF_CHI_PTREN			0x1dc
#define	CHI_CHITXPTRB3EN		(1 << 31)
#define	CHI_CHITXPTRB2EN		(1 << 30)
#define	CHI_CHITXPTRB1EN		(1 << 29)
#define	CHI_CHITXPTRB0EN		(1 << 28)
#define	CHI_CHITXPTRA3EN		(1 << 27)
#define	CHI_CHITXPTRA2EN		(1 << 26)
#define	CHI_CHITXPTRA1EN		(1 << 25)
#define	CHI_CHITXPTRA0EN		(1 << 24)
#define	CHI_CHIRXPTRB3EN		(1 << 23)
#define	CHI_CHIRXPTRB2EN		(1 << 22)
#define	CHI_CHIRXPTRB1EN		(1 << 21)
#define	CHI_CHIRXPTRB0EN		(1 << 20)
#define	CHI_CHIRXPTRA3EN		(1 << 19)
#define	CHI_CHIRXPTRA2EN		(1 << 18)
#define	CHI_CHIRXPTRA1EN		(1 << 17)
#define	CHI_CHIRXPTRA0EN		(1 << 16)

#define OFF_CHI_RCVPTRA			0x1e0
#define	CHI_CHIRXPTRA3MASK		(0xf << 24)
#define CHI_CHIRXPTRA3(a)		(((a) << 24) & CHI_CHIRXPTRA3MASK)
#define	CHI_CHIRXPTRA2MASK		(0xf << 16)
#define CHI_CHIRXPTRA2(a)		(((a) << 16) & CHI_CHIRXPTRA2MASK)
#define	CHI_CHIRXPTRA1MASK		(0xf << 8)
#define CHI_CHIRXPTRA1(a)		(((a) << 8) & CHI_CHIRXPTRA1MASK)
#define	CHI_CHIRXPTRA0MASK		0xf
#define CHI_CHIRXPTRA0(a)		((a) & CHI_CHIRXPTRA0MASK)

#define OFF_CHI_RCVPTRB			0x1e4
#define	CHI_CHIRXPTRB3MASK		(0xf << 24)
#define CHI_CHIRXPTRB3(a)		(((a) << 24) & CHI_CHIRXPTRB3MASK)
#define	CHI_CHIRXPTRB2MASK		(0xf << 16)
#define CHI_CHIRXPTRB2(a)		(((a) << 16) & CHI_CHIRXPTRB2MASK)
#define	CHI_CHIRXPTRB1MASK		(0xf << 8)
#define CHI_CHIRXPTRB1(a)		(((a) << 8) & CHI_CHIRXPTRB1MASK)
#define	CHI_CHIRXPTRB0MASK		0xf
#define CHI_CHIRXPTRB0(a)		((a) & CHI_CHIRXPTRB0MASK)

#define OFF_CHI_TXPTRA			0x1e8
#define	CHI_CHITXPTRA3MASK		(0xf << 24)
#define CHI_CHITXPTRA3(a)		(((a) << 24) & CHI_CHITXPTRA3MASK)
#define	CHI_CHITXPTRA2MASK		(0xf << 16)
#define CHI_CHITXPTRA2(a)		(((a) << 16) & CHI_CHITXPTRA2MASK)
#define	CHI_CHITXPTRA1MASK		(0xf << 8)
#define CHI_CHITXPTRA1(a)		(((a) << 8) & CHI_CHITXPTRA1MASK)
#define	CHI_CHITXPTRA0MASK		0xf
#define CHI_CHITXPTRA0(a)		((a) & CHI_CHITXPTRA0MASK)

#define OFF_CHI_TXPTRB			0x1ec
#define	CHI_CHITXPTRB3MASK		(0xf << 24)
#define CHI_CHITXPTRB3(a)		(((a) << 24) & CHI_CHITXPTRB3MASK)
#define	CHI_CHITXPTRB2MASK		(0xf << 16)
#define CHI_CHITXPTRB2(a)		(((a) << 16) & CHI_CHITXPTRB2MASK)
#define	CHI_CHITXPTRB1MASK		(0xf << 8)
#define CHI_CHITXPTRB1(a)		(((a) << 8) & CHI_CHITXPTRB1MASK)
#define	CHI_CHITXPTRB0MASK		0xf
#define CHI_CHITXPTRB0(a)		((a) & CHI_CHITXPTRB0MASK)

#define OFF_CHI_SIZE			0x1f0
#define CHI_CHIDMAPTRMASK		0x3ffc0000
#define CHI_CHIDMAPTR(a)		(((a) << 18) & CHI_CHIDMAPTR)
#define CHI_CHIBUFF1TIME		(1 << 15)
#define CHI_CHIMALOOP			(1 << 14)
#define CHI_CHISIZEMASK			0x3ffc
#define CHI_CHISIZE(a)			(((a) << 2) & CHI_HISIZEMASK
#define CHI_ENDMARXCHI			(1 <<2)
#define CHI_ENDMATXCHI			1

#define	OFF_CHIRXSTART			0x1f4
#define	CHI_RXSTARTMASK			0xfffffffc

#define	OFF_CHITXSTART			0x1f8
#define	CHI_TXSTARTMASK			0xfffffffc

#define OFF_CHITXHOLD			0x1fc
#define OFF_CHIRXHOLD			0x1fc

/*
   R3912 Interrupt Register
 */
#define OFF_INTR_STATUS1		0x100
#define INTR_LCDINT			(1 << 31)
#define INTR_DFINT			(1 << 30)
#define INTR_CHI0_5INT			(1 << 29)
#define INTR_CHI1_0INT			(1 << 28)
#define INTR_CHIDMACNTINT		(1 << 27)
#define INTR_CHIININTA			(1 << 26)
#define INTR_CHIININTB			(1 << 25)
#define INTR_CHIACTINT			(1 << 24)
#define INTR_CHIERRINT			(1 << 23)
#define INTR_SND0_5INT			(1 << 22)
#define INTR_SND1_0TINT			(1 << 21)
#define INTR_TEL0_5INT			(1 << 20)
#define INTR_TEL1_0TINT			(1 << 19)
#define INTR_SNDDMACNTINT		(1 << 18)
#define INTR_TELDMACNTINT		(1 << 17)
#define INTR_LSNDCLIPINT		(1 << 16)
#define INTR_RSNDCLIPINT		(1 << 15)
#define INTR_VALSNDPOSINT		(1 << 14)
#define INTR_VALSNDNEGINT		(1 << 13)
#define INTR_VALTELPOSINT		(1 << 12)
#define INTR_VALTELNEGINT		(1 << 11)
#define INTR_SNDININT			(1 << 10)
#define INTR_TELININT			(1 << 9)
#define INTR_SIBSF0INT			(1 << 8)
#define INTR_SIBSF1INT			(1 << 7)
#define INTR_SIBIRQPOSINT		(1 << 6)
#define INTR_SIBIRQNEGINT		(1 << 5)

#define OFF_INTR_STATUS2		0x104
#define INTR_UARTARXINT			(1 << 31)
#define INTR_UARTARXOVERRUNINT		(1 << 30)
#define INTR_UARTAFRAMEERRINT		(1 << 29)
#define INTR_UARTABREAKINT		(1 << 28)
#define INTR_UARTAPARITYERRINT		(1 << 27)
#define INTR_UARTATXINT			(1 << 26)
#define INTR_UARTATXOVERRUNINT		(1 << 25)
#define INTR_UARTAEMPTYINT		(1 << 24)
#define INTR_UARTADMAFULLINT		(1 << 23)
#define INTR_UARTADMAHALFINT		(1 << 22)
#define INTR_UARTBRXINT			(1 << 21)
#define INTR_UARTBRXOVERRUNINT		(1 << 20)
#define INTR_UARTBFRAMEERRINT		(1 << 19)
#define INTR_UARTBBREAKINT		(1 << 18)
#define INTR_UARTBPARITYERRINT		(1 << 17)
#define INTR_UARTBTXINT			(1 << 16)
#define INTR_UARTBTXOVERRUNINT		(1 << 15)
#define INTR_UARTBEMPTYINT		(1 << 14)
#define INTR_UARTBDMAFULLINT		(1 << 13)
#define INTR_UARTBDMAHALFINT		(1 << 12)
#define INTR_MBUSTXBUFAVAILINT		(1 << 11)
#define INTR_MBUSTXERRINT		(1 << 10)
#define INTR_MBUSEMPTYINT		(1 << 9)
#define INTR_MBUSRXBUFAVAILINT		(1 << 8)
#define INTR_MBUSRXERRINT		(1 << 7)
#define INTR_MBUSDETINT			(1 << 6)
#define INTR_MBUSDMAFULLINT		(1 << 5)
#define INTR_MBUSDMAHALFINT		(1 << 4)
#define INTR_MBUSPOSINT			(1 << 3)
#define INTR_MBUSNEGINT			(1 << 2)

#define OFF_INTR_STATUS3		0x108
#define INTR_MFIOPOSINT(a)		(1 << (a))

#define OFF_INTR_STATUS4		0x10c
#define INTR_MFIONEGINT(a)		(1 << (a))

#define OFF_INTR_STATUS5		0x110
#define INTR_RTCINT			(1 << 31)
#define INTR_ALARMINT			(1 << 30)
#define INTR_PREINT			(1 << 29)
#define INTR_STPTIMERINT		(1 << 28)
#define INTR_POSPWRINT			(1 << 27)		
#define INTR_NEGPWRINT			(1 << 26)		
#define INTR_POSPWROKINT		(1 << 25)		
#define INTR_NEGPWROKINT		(1 << 24)		
#define INTR_POSONBUTNINT		(1 << 23)		
#define INTR_NEGONBUTNINT		(1 << 22)		
#define INTR_SPIBUFAVAILINT		(1 << 21)
#define INTR_SPIERRINT			(1 << 20)
#define INTR_SPIRCVINT			(1 << 19)
#define INTR_SPIEMPTYINT		(1 << 18)
#define INTR_IRCONSMINT			(1 << 17)
#define INTR_CARSTINT			(1 << 16)
#define INTR_POSCARINT			(1 << 15)
#define INTR_NEGCARINT			(1 << 14)
#define INTR_IOPOSINT(a)		(1 << ((a) + 7))
#define INTR_IONEGINT(a)		(1 << (a))

#define OFF_INTR_STATUS6		0x114
#define INTR_IRQHIGH			(1 << 31)
#define INTR_IRQLOW			(1 << 30)
#define INTR_INTVECTMASK		0x0000003c
#define INTR_INTVECT(a)			(((a) << 2) & INTR_INTVECTMASK)
#define INTR_INTPRIO(status6)		((status6 & INTR_INTVECTMASK) >> 2)

#define OFF_INTR_CLEAR1			0x100
#define OFF_INTR_CLEAR2			0x104
#define OFF_INTR_CLEAR3			0x108
#define	OFF_INTR_CLEAR4			0x10c
#define OFF_INTR_CLEAR5			0x110

#define OFF_INTR_ENABLE1		0x118
#define OFF_INTR_ENABLE2		0x11c
#define OFF_INTR_ENABLE3		0x120
#define	OFF_INTR_ENABLE4		0x124
#define OFF_INTR_ENABLE5		0x128

#define OFF_INTR_ENABLE6		0x12c
#define INTR_GLOBALEN			(1 << 18)
#define INTR_IRQPRITEST			(1 << 17)
#define INTR_IRQTEST			(1 << 16)
#define INTR_PRIORITYMASKMASK		0x0000ffff
#define INTR_PRIORITYMASK(a)		((1 << (a)) & INTR_PRIORITYMASKMASK)

/* 
  IO Module
*/
#define OFF_IO_CTL			0x180
#define IO_IODEBSELMASK			0x7f000000
#define IO_IODEBSEL(a)			(1 << ((a) + 24))
#define IO_IODIRECMASK			0x007f0000
#define IO_IODIREC(a)			(1 << ((a) + 16))
#define IO_IODIRECOUT(a)		(1 << ((a) + 16))
#define IO_IODIRECIN(a)			0
#define IO_IODOUTMASK			0x00007f00
#define IO_IODOUT(a)			(1 << ((a) + 8))
#define IO_IODINMASK			0x0000007f
#define IO_IODIN(a)			(1 << (a))

#define OFF_IO_MFIOOUT			0x184
#define IO_MFIOOUT(a)			(1 << (a))

#define OFF_IO_MFIODIREC		0x188
#define IO_MFIODIRECOUT(a)		(1 << (a))
#define IO_MFIODIRECIN(a)		0

#define OFF_IO_MFIOIN			0x18c
#define IO_MFIOIN(a)			(1 << (a))

#define OFF_IO_MFIOSEL			0x190
#define IO_MFIOSEL(a)			(1 << (a))

#define OFF_IO_IOPWRDN			0x194
#define IO_IOPDMASK			0x0000007f
#define IO_IOPD(a)			((1 << (a)) & IO_PDMASK)

#define OFF_IO_MFIOPWRDN		0x198
#define IO_MFIOPD(a)			(1 << (a))

/*
  IR Module
*/

#define OFF_IR_CTL1			0x0a0
#define IR_CARDET			(1 << 24)
#define	IR_BAUDVALMASK			0x00ff0000
#define	IR_BAUD(a)			(((a) << 16) & IR_BAUDVALMASK)
#ifdef INTERNAL_TEST
#define IR_TESTIR			(1 << 4)
#endif
#define IR_DTINVERT			(1 << 3)
#define IR_RXPWR			(1 << 2)
#define IR_ENSTATE			(1 << 1)
#define IR_ENCONSM			1

#define OFF_IR_CTL2			0x0a4
#define IR_PERMASK			0xff000000
#define IR_PER(a)			(((a) << 24) & IR_PERMASK)
#define IR_ONTIMEMASK			0x00ff0000
#define IR_ONTIME(a)			(((a) << 16) & IR_ONTIMEMASK)
#define IR_DELAYVALMASK			0x0000ff00
#define IR_DELAYVAL(a)			(((a) << 8) & IR_DELAYVALMASK)
#define IR_WAITVALMASK			0x000000ff
#define IR_WAITVAL(a)			((a) & IR_WAITVALMASK)

#define OFF_IR_HOLD			0x0a8
#define IR_TXHOLDMASK			0x0000ffff
#define IR_TXHOLD(a)			((a) & IR_TXHOLDMASK)

#define OFF_MAGICBUS_CTL1		0x0e0
#define	MAGICBUS_MBUSON			(1 << 31)
#define MAGICBUS_EMPTY			(1 << 30)
#define MAGICBUS_MBUSINT		(1 << 29)
#define MAGICBUS_ENDMARX		(1 << 16)
#define MAGICBUS_ENDMATX		(1 << 15)
#ifdef INTERNAL_TEST
#define MAGICBUS_ENDMATEST		(1 << 14)
#endif
#define MAGICBUS_ENDMALOOP		(1 << 13)
#define MAGICBUS_LOOPBACK		(1 << 12)
#define MAGICBUS_RCVPHAPOL		(1 << 11)
#define MAGICBUS_DTIDLE			(1 << 10)
#define MAGICBUS_ENBYTEWAIT		(1 << 9)
#define MAGICBUS_ENWORDWAIT		(1 << 8)
#define MAGICBUS_DETPHAPOL		(1 << 7)
#define MAGICBUS_DETCLKPOL		(1 << 6)
#define MAGICBUS_PHAPOL			(1 << 5)
#define MAGICBUS_CLKPOL			(1 << 4)
#define MAGICBUS_SLAVE			(1 << 3)
#define MAGICBUS_FSLAVE			(1 << 2)
#define MAGICBUS_LONG			(1 << 1)
#define MAGICBUS_ENMBUS			1

#define OFF_MAGICBUS_CTL2		0x0e4
#define MAGICBUS_DELAYVALMASK		0xff000000
#define MAGICBUS_DELAYVAL(a)		(((a) << 24) & MAGICBUS_DELAYVALMASK)
#define MAGICBUS_BAUDRATEMASK		0x00ff0000
#define MAGICBUS_BAUDRATE(a)		(((a) << 16) & MAGICBUS_BAUDRATEMASK)

#define OFF_MAGICBUS_DMACTL1		0x0e8
#define MAGICBUS_DMASTARTVALMASK	0xfffffffc
#define MAGICBUS_DMASTARTVAL(a)		((a) & MAGICBUS_DMASTARTVALMASK)

#define OFF_MAGICBUS_DMACTL2		0x0ec
#define MAGICBUS_DMALENGTHMASK		0x000ffffc
#define MAGICBUS_DMALENGTH(a)		((a) & MAGICBUS_DMALENGTHMASK)

#define OFF_MAGICBUS_DMACOUNT		0x0f0
#define MAGICBUS_DMACOUNTMASK		0x000ffffc

#define OFF_MAGICBUS_TXHOLD		0x0f8
#define OFF_MAGICBUS_TXHOLD_SWAP	0x0f4

#define OFF_MAGICBUS_RXHOLD		0x0f8

/*
  Power Management
*/
#define OFF_POWER_CTL			0x1c4
#define POWER_ONBUTN			(1 << 31)
#define POWER_PWRINT			(1 << 30)
#define POWER_PWROK			(1 << 29)
#define POWER_STPTIMERVALMASK		0x0000f000
#define POWER_STPTIMERVAL(a)		(((a) << 12) & POWER_STPTIMERVALMASK)
#define POWER_ENSTPTIMER		(1 << 11)
#define POWER_ENFORCESHUTDOWN		(1 << 10)
#define POWER_FORCESHUTDOWN		(1 << 9)
#define POWER_FORCESHUTDOWNOCC		(1 << 8)
#define POWER_SELC2MS			(1 << 7)
#define POWER_BPDBVCC3			(1 << 5)
#define POWER_STOPCPU			(1 << 4)
#define POWER_DBNCONBUTN		(1 << 3)
#define POWER_COLDSTART			(1 << 2)
#define POWER_PWRCS			(1 << 1)
#define POWER_VCCON			(1 << 0)

/*
  SIB Module
*/
#define OFF_SIB_SIZE			0x60
#define	SIB_SNDSIZEMASK			0x3ffc0000
#define SIB_SNDSIZE(a)			(((a) << 16) & SIB_SNDSIZEMASK)
#define SIB_TELSIZEMASK			0x00003ffc
#define SIB_TELSIZE(a)			((a) & SIB_TELSIZEMASK)

#define OFF_SIB_SNDRXSTART		0x64
#define SIB_SNDRXSTARTMASK		0xfffffffc
#define SIB_SNDRXSTART			((a) & SIB_SNDRXSTARTMASK)

#define OFF_SIB_SNDTXSTART		0x68
#define SIB_SNDTXSTARTMASK		0xfffffffc
#define SIB_SNDTXSTART			((a) & SIB_SNDRXSTARTMASK)

#define OFF_SIB_TELRXSTART		0x6c
#define SIB_TELRXSTARTMASK		0xfffffffc
#define SIB_TELRXSTART			((a) & SIB_TELRXSTARTMASK)

#define OFF_SIB_TELTXSTART		0x70
#define SIB_TELTXSTARTMASK		0xfffffffc
#define SIB_TELTXSTART			((a) & SIB_TELRXSTARTMASK)

#define OFF_SIB_CTL			0x74
#define SIB_SIBIRQ			(1 << 31)
#ifdef INTERNAL_TEST
#define SIB_ENCNTTEST			(1 << 30)
#define SIB_ENDMATEST			(1 << 29)
#endif
#define SIB_SNDMONO			(1 << 28)
#define SIB_RMONOSNDIN			(1 << 27)
#define SIB_SCLKDIVMASK			(7 << 24)
#define SIB_SCLKDIV(a)			(((a) << 24) & SIBSCLKDIVMASK)
#define SIB_TEL16			(1 << 23)
#define SIB_TELFSDIVMASK		0x007f0000
#define SIB_TELFSDIV(a)			(((a) << 16) & SIB_TELFSDIVMASK)
#define SIB_SND16			(1 << 15)
#define SIB_SNDFSDIVMASK		0x00007f00
#define SIB_SNDFSDIV(a)			(((a) << 8) & SIB_SNDFSDIVMASK)
#define SIB_SELTELSF1			(1 << 7)
#define SIB_SELSNDSF1			(1 << 6)
#define SIB_ENTEL			(1 << 5)
#define SIB_ENSND			(1 << 4)
#define SIB_SIBLOOP			(1 << 3)
#define SIB_ENSF1			(1 << 2)
#define SIB_ENSF0			(1 << 1)
#define SIB_ENSIB			1

#define OFF_SIB_SNDTXHOLD		0x078
#define OFF_SIB_SNDRXHOLD		0x078

#define OFF_SIB_TELTXHOLD		0x07c
#define OFF_SIB_TELRXHOLD		0x07c

#define OFF_SIB_SF0AUX			0x80
#define OFF_SIB_SF1AUX			0x84

#define OFF_SIB_SF0TAT			0x88
#define OFF_SIB_SF1TAT			0x8c

#define OFF_SIB_DMACTL			0x90
#define SIB_SNDBUFF1TIME		(1 << 31)
#define SIB_SNDDMALOOP			(1 << 30)
#define SIB_SNDDMAPTRMASK		0x3ffc0000
#define SIB_ENDMARXSND			(1 << 17)
#define SIB_ENDMATXSND			(1 << 16)
#define SIB_TELBUFF1TIME		(1 << 15)
#define SIB_TELDMALOOP			(1 << 14)
#define SIB_TELDMAPTRMASK		0x00003ffc
#define SIB_ENDMARXTEL			(1 << 1)
#define SIB_ENDMATXTEL			1

/*
  SPI Module
 */
#define OFF_SPI_CTL			0x160
#define SPI_SPION			(1 << 17)
#define SPI_EMPTY			(1 << 16)
#define SPI_DELAYVALMASK		0x0000f000
#define SPI_DELAYVAL(a)			(((a) << 12) & SPI_DELAYVALMASK)
#define SPI_BAUDRATEMASK		0x00000f00
#define SPI_BAUDRATE(a)			(((a) << 8) & SPI_BAUDRATEMASK)
#define SPI_PHAPOL			(1 << 5)
#define SPI_CHKPOL			(1 << 4)
#define SPI_WORD			(1 << 2)
#define SPI_LSB				(1 << 1)
#define SPI_ENSPI			1

#define OFF_SPI_TXDATA			0x164
#define SPI_TXDATAMASK			0x0000ffff
#define OFF_SPI_RXDATA			0x164
#define SPI_RXDATAMASK			0x0000ffff

/*
   Timer
 */
/* RTC */
#define OFF_RTC_RTCHI			0x140
#define RTC_RTCHIMASK			0x000000ff
#define OFF_RTC_RTCLOW			0x144
/* Alarm */
#define OFF_ALARM_ALARMHI		0x148
#define ALARM_ALARMHIMASK		0x000000ff
#define OFF_ALARM_ALARMLOW		0x14c
/* Timer */
#define OFF_TIMER_CTL			0x150
#define TIMER_FREEZEPRE			(1 << 7)
#define TIMER_FREEZERTC			(1 << 6)
#define TIMER_FREEZETIMER		(1 << 5)
#define TIMER_ENPRETIMER		(1 << 4)
#define TIMER_RTCCLR			(1 << 3)
#define TIMER_TESTC8MS			(1 << 2)
#define TIMER_ENTESTCLK			(1 << 1)
#define TIMER_ENRTCTEST			1

#define OFF_PERIODIC_TIMER		0x154
#define PERIODIC_PRECNTMASK		0xffff0000
#define PERIODIC_PRECNT(a)		(((a) << 16) & PERIODIC_PRECNTMASK)
#define PERIODIC_PREVALMASK		0x0000ffff
#define PERIODIC_PREVAL(a)		((a) & PERIODIC_PREVALMASK)

/*
	Serial Definition
*/
#define OFF_UARTA_CTL1		0x0b0
#define OFF_UARTB_CTL1		0x0c8

#define UART_UARTON		(1 << 31)
#define UART_EMPTY		(1 << 30)
#define UART_PRXHOLDFULL	(1 << 29)
#define UART_RXHOLDFULL		(1 << 28)
#define UART_ENDMATX		(1 << 15)
#define UART_ENDMARX		(1 << 14)
#ifdef INTERNAL_TEST
#define UART_TESTMODE		(1 << 13)
#endif
#define UART_ENBREAKHALT	(1 << 12)
#define UART_ENDMATEST		(1 << 11)
#define UART_ENDMALOOP		(1 << 10)
#define UART_PULSEOPT2		(1 << 9)
#define UART_PULSEOPT1		(1 << 8)
#define UART_DTINVERT		(1 << 7)
#define UART_DISTXD		(1 << 6)
#define UART_TWOSTOP		(1 << 5)
#define UART_LOOPBACK		(1 << 4)
#define UART_BIT_7		(1 << 3)
#define UART_EVENPARITY		(1 << 2)
#define UART_ENPARITY		(1 << 1)
#define	UART_ENUART		1

#define OFF_UARTA_CTL2		0x0b4
#define OFF_UARTB_CTL2		0x0cc
#define UART_BAUDMASK		0x000003ff		// lower 10bits

/*
   Standart UART Values 
   This comes from: baud rate = 3.6864MHz / ((BaudRate + 1) * 16)
*/
#define UART_B38400		5
#define UART_B19200		11
#define UART_B9600		23
#define UART_B4800		47
#define UART_B2400		95
#define UART_B1200		191
#define UART_B600		383
#define UART_B300		767

#define OFF_UARTA_DMA_CTL1	0x0b8
#define OFF_UARTB_DMA_CTL1	0x0d0
#define UART_DMASTARTVALMASK	0xfffffffc

#define OFF_UARTA_DMA_CTL2	0x0bc
#define OFF_UARTB_DMA_CTL2	0x0d4
#define OFF_UARTA_DMA_COUNT	0x0c0
#define OFF_UARTB_DMA_COUNT	0x0d8
#define UART_DMALENGTHMASK	0x0000ffff

#define OFF_UARTA_TXDATA	0x0c4	/* Write Only */
#define OFF_UARTB_TXDATA	0x0dc	/* Write Only */
#define OFF_UARTA_RXDATA	0x0c4	/* Read Only */
#define OFF_UARTB_RXDATA	0x0dc	/* Read Only */
#define UART_BREAK		0x00000100	/* send/received break */
#define UART_TXDATAMASK		0x000000ff	/* send data mask */
#define UART_RXDATAMASK		0x000000ff	/* receive data mask */
	
/*
   Video
 */
#define OFF_VIDEO_CTL1			0x28
#define VIDEO_LINECNTMASK		0xffc00000
#define VIDEO_LINECNT(a)		(((a) << 22) & VIDEO_LINECNTMASK)
#define VIDEO_LOADDLY			(1 << 21)
#define VIDEO_BAUDVALMASK		0x000f0000
#define VIDEO_BAUDVAL(a)		(((a) << 16) & VIDEO_BAUDVALMASK)
#define VIDEO_VIDDONEVALMASK		0x0000fe00
#define VIDEO_VIDDONEVAL		(((a) << 9) & VIDEO_DONEVALMASK)
#define VIDEO_ENFREEZEFRAME		(1 << 8)
#define VIDEO_BITSELMASK		0x000000c0
#define VIDEO_BITSEL(a)			(((a) << 6) & VIDEO_BITSEL)
#define VIDEO_DISPSPLIT			(1 << 5)
#define VIDEO_DISP8			(1 << 4)
#define VIDEO_DFMODE			(1 << 3)
#define VIDEO_INVVID			(1 << 2)
#define VIDEO_DISPON			(1 << 1)
#define VIDEO_ENVID			1

#define OFF_VIDEO_CTL2			0x2c
#define VIDEO_VIDRATEMASK		0xffc00000
#define VIDEO_VIDRATE(a)		(((a) << 22) & VIDEO_VIDRATEMASK)
#define VIDEO_HORZVALMASK		0x001ff000
#define VIDEO_HORZVAL(a)		(((a) << 12) & VIDEO_HORZVALMASK)
#define VIDEO_LINEVALMASK		0x000003ff
#define VIDEO_LINEVAL(a)		((a) & VIDEO_LINEVALMASK)

#define OFF_VIDEO_CTL3			0x30
#define VIDEO_VIDBANKMASK		0xfff00000
#define VIDEO_VIDBANK(a)		((a) & VIDEO_VIDBANKMASK)
#define VIDEO_VIDBASEHIMASK		0x000ffff0
#define VIDEO_VIDBASEHI(a)		((a) & VIDEO_VIDBASEHIMASK)

#define OFF_VIDEO_CTL4			0x34
#define VIDEO_DFVALMASK			0xff000000
#define VIDEO_DFVAL(a)			(((a) << 24) & VIDEO_DFVALMASK)
#define VIDEO_FRAMEMASKVALMASK		0x00f00000
#define VIDEO_FRAMEMASKVAL(a)		(((a) << 20) & VIDEO_FRAMEMASKVALMASK)
#define VIDEO_VIDBASELOMASK		0x000ffff0
#define VIDEO_VIDBASELO(a)		((a) & VIDEO_VIDBASELOMASK)

#define OFF_VIDEO_CTL5			0x38

#define OFF_VIDEO_CTL6			0x3c

#define OFF_VIDEO_CTL7			0x40
#define VIDEO_BLUESELMASK		0x0000ffff
#define VIDEO_BLUESEL(a)		((a) & VIDEO_BLUESEL)

#define OFF_VIDEO_CTL8			0x44
#define VIDEO_PAT2_3MASK		0x00000fff
#define VIDEO_PAT2_3(a)			((a) & VIDEO_PAT2_3)

#define OFF_VIDEO_CTL9			0x48
#define VIDEO_PAT3_4MASK		0xffff0000
#define VIDEO_PAT3_4(a)			(((a) << 16) & VIDEO_PAT3_4)
#define VIDEO_PAT2_4MASK		0x0000ffff
#define VIDEO_PAT2_4(a)			((a) & VIDEO_PAT2_4MASK)

#define OFF_VIDEO_CTL10			0x4c
#define VIDEO_PAT4_5MASK		0x000fffff
#define VIDEO_PAT4_5(a)			((a) & VIDEO_PAT4_5)

#define OFF_VIDEO_CTL11			0x50
#define VIDEO_PAT3_5MASK		0x000fffff
#define VIDEO_PAT3_5(a)			((a) & VIDEO_PAT3_5)

#define OFF_VIDEO_CTL12			0x54
#define VIDEO_PAT6_7MASK		0x0fffffff
#define VIDEO_PAT6_7(a)			((a) & VIDEO_PAT6_7)

#define OFF_VIDEO_CTL13			0x58
#define VIDEO_PAT5_7MASK		0x0fffffff
#define VIDEO_PAT5_7(a)			((a) & VIDEO_PAT5_7)
 
#define OFF_VIDEO_CTL14			0x5c
#define VIDEO_PAT4_7MASK		0x0fffffff
#define VIDEO_PAT4_7(a)			((a) & VIDEO_PAT4_7)

/*
  Register Access Macros..
*/

#define READ_REGISTER_ULONG(reg) (*(volatile unsigned long * const)(reg))
#define WRITE_REGISTER_ULONG(reg, val) (*(volatile unsigned long * const)(reg)) = (val)
#define READ_REGISTER_USHORT(reg) (*(volatile unsigned short * const)(reg))
#define WRITE_REGISTER_USHORT(reg, val) (*(volatile unsigned short * const)(reg)) = (val)
#define READ_REGISTER_UCHAR(reg) (*(volatile unsigned char * const)(reg))
#define WRITE_REGISTER_UCHAR(reg, val) (*(volatile unsigned char * const)(reg)) = (val)

#define R3REG(base, id)   (*(volatile ULONG *)((base)+(id)))

#endif /* _R3912_H_ */

