/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
Copyright (c) 1995-2000 Microsoft Corporation.  All rights reserved.

Module Name:  

  cmtt1pos.h

Abstract:  

	this file provides headers for R3910 specific
    functionality specific to cmtt1 E1 engineering build
  
Functions:

  
Notes:


Revision History:

--*/
#ifndef _cmtt1pos_h_
#define _cmtt1pos_h_

#include "poseidon.h"

/* Cmtt1 Interrupt ID's */
#define	kSIBSoundHalfInterrupt					kSoundHalfInterrupt
#define	kSIBSoundFullInterrupt					kSoundFullInterrupt
#define	kSIBTelHalfInterrupt					kTelHalfInterrupt
#define	kSIBTelFullInterrupt					kTelFullInterrupt
#define	kSIBSF0Interrupt						kSIBsf0Interrupt
#define	kSIBSF1Interrupt						kSIBsf1Interrupt
//#define	kSIBPositiveInterrupt					kSIBPositiveInterrupt
#define	kSIBRingDetectPosInterrupt				kmfioPositiveInterrupt0
#define	kSerialRXInterrupt						kUARTARXInterrupt
#define	kSerialTXInterrupt						kUARTATXInterrupt
#define	kSerialDMAFullInterrupt					kUARTADMAFullInterrupt
#define	kSerialDMAHalfInterrupt					kUARTADMAHalfInterrupt
#define	kSerialCTSNegInterrupt					kmfioNegativeInterrupt30
#define	kSerialCTSPosInterrupt					kmfioPositiveInterrupt30
#define	kSerialDCDNegInterrupt					kioNegativeInterrupt4
#define	kSerialDCDPosInterrupt					kioPositiveInterrupt4
#define	kIrDARXInterrupt						kUARTBRXInterrupt
#define	kIrDATXInterrupt						kUARTBTXInterrupt
#define	kIrDADMAFullInterrupt					kUARTBDMAFullInterrupt
#define	kIrDADMAHalfInterrupt					kUARTBDMAHalfInterrupt
#define	kBatteryACPosInterrupt					kPositivePowerInterrupt
#define	kBatteryACNegInterrupt					kNegativePowerInterrupt
//#define	kMagicBusTXBufferAvailableInterrupt		kMagicBusTXBufferAvailableInterrupt
//#define	kMagicBusTXErrorInterrupt				kMagicBusTXErrorInterrupt
//#define	kMagicBusEmptyInterrupt					kMagicBusEmptyInterrupt
//#define	kMagicBusRXErrorInterrupt				kMagicBusRXErrorInterrupt
#define	kMagicBusCmdDetInterrupt				kMagicBusDetInterrupt
//#define	kMagicBusDMAFullInterrupt				kMagicBusDMAFullInterrupt
//#define	kMagicBusPositiveInterrupt				kMagicBusPositiveInterrupt
//#define	kMagicBusNegativeInterrupt				kMagicBusNegativeInterrupt
#define	kMiniCard2BusyPosInterrupt				kmfioPositiveInterrupt28
#define	kMiniCard1DetectNegInterrupt			kioNegativeInterrupt6
#define	kMiniCard1DetectPosInterrupt			kioPositiveInterrupt6
#define	kMiniCard2DetectNegInterrupt			kioNegativeInterrupt5
#define	kMiniCard2DetectPosInterrupt			kioPositiveInterrupt5
#define	kKeyboardAttentionNegInterrupt			kmfioNegativeInterrupt1
#define	kKeyboardSPIInPosInterrupt				kSPIrcvInterrupt
#define	kKeyboardOnButtonPosInterrupt			kPositiveOnButtonInterrupt
#define	kMModulePosInterrupt					kioPositiveInterrupt2
#define	kMModuleAttachedNegInterrupt			kioNegativeInterrupt0
#define	kMModuleAttachedPosInterrupt			kioPositiveInterrupt0
#define	kMModuleCardWaitPosInterrupt			kmfioPositiveInterrupt4
//#define	kRTCInterrupt							kRTCInterrupt
//#define	kAlarmInterrupt							kAlarmInterrupt
//#define	kPeriodicInterrupt						kPeriodicInterrupt

/* Cmtt1 Interrupt Masks */
#define	kAudioSoundHalfMask						kIntSoundDmaHalfMask
#define	kAudioSoundFullMask						kIntSoundDmaEndMask
#define	kSIBTelHalfMask							kIntTelDmaHalfMask
#define	kSIBTelFullMask							kIntTelDmaEndMask
#define	kSIBSF0Mask								kIntSibSubFrame0Mask
#define	kSIBSF1Mask								kIntSibSubFrame1Mask
#define	kSIBPositiveMask						kIntSibIrqPosMask
#define	kSIBRingDetectPosMask					kIntMfio0PosMask
#define	kSerialRXMask							kIntUartAReceiveMask
#define	kSerialTXMask							kIntUartATransmitMask
#define	kSerialDMAFullMask						kIntUartADmaEndMask
#define	kSerialDMAHalfMask						kIntUartADmaHalfMask
#define	kSerialCTSNegMask						kIntMfio30NegMask
#define	kSerialCTSPosMask						kIntMfio30PosMask
#define	kSerialDCDNegMask						kIntIOInt4NegMask
#define	kSerialDCDPosMask						kIntIOInt4PosMask
#define	kIrDARXMask								kIntUartBReceiveMask
#define	kIrDATXMask								kIntUartBTransmitMask
#define	kIrDADMAFullMask						kIntUartBDmaEndMask
#define	kIrDADMAHalfMask						kIntUartBDmaHalfMask
#define	kBatteryACPosMask						kIntPwrIntPosMask
#define	kBatteryACNegMask						kIntPwrIntNegMask
#define	kMagicBusTXBufferAvailableMask			kIntMbusTransmitMask
#define	kMagicBusTXErrorMask					kIntMbusTxErrMask
#define	kMagicBusEmptyMask						kIntMbusEmptyMask
#define	kMagicBusRXErrorMask					kIntMbusRxErrMask
#define	kMagicBusCmdDetMask						kIntMbusCmdDetectMask
#define	kMagicBusDMAFullMask					kIntMbusDmaEndMask
#define	kMagicBusPositiveMask					kIntMbusPosMask
#define	kMagicBusNegativeMask					kIntMbusNegMask
#define	kMiniCard2BusyPosMask					kIntMfio28PosMask
#define	kMiniCard1DetectNegMask					kIntIOInt6NegMask
#define	kMiniCard1DetectPosMask					kIntIOInt6PosMask
#define	kMiniCard2DetectNegMask					kIntIOInt5NegMask
#define	kMiniCard2DetectPosMask					kIntIOInt5PosMask
#define	kKeyboardAttentionNegMask				kIntMfio1NegMask
#define	kKeyboardSPIInPosMask					kIntSpiReceiveMask
#define	kKeyboardOnButtonPosMask				kIntOnButPosMask
#define	kMModulePosMask							kIntIOInt2PosMask
#define	kMModuleAttachedNegMask					kIntIOInt0NegMask
#define	kMModuleAttachedPosMask					kIntIOInt0PosMask
#define	kMModuleCardWaitPosMask					kIntMfio4PosMask

#define	kRTCMask								kIntRTCRolloverMask
#define	kAlarmMask								kIntRTCAlarmMask
#define	kPeriodicMask							kIntPeriodicTimerMask
/* SSP: add the following for power.*/
#define kRescheduleMask                                                 kIntVideoFrameMask
#define kTouchSampleMask                                                kIntVideoDFMask
#define kVidDoneMask                                                    kIntIOInt2PosMask

/* Cmtt1 Hig Priority Interrupt Masks */
#define	kMModuleAttachedNegPriorityMask			0x00000002	/* 1 */
#define	kMModuleAttachedPosPriorityMask			0x00000002	/* 1 */
#define	kMiniCard1DetectNegPriorityMask			0x00000040	/* 6 */
#define	kMiniCard1DetectPosPriorityMask			0x00000100	/* 8 */
#define	kMiniCard2DetectNegPriorityMask			0x00000040	/* 6 */
#define	kMiniCard2DetectPosPriorityMask			0x00000100	/* 8 */

#define kCmtt1HighPriorityMask					(kIntGlobalEnMask | kIntEnHighPwrOkMask | \
													kMModuleAttachedNegPriorityMask | kMModuleAttachedPosPriorityMask | \
													kMiniCard1DetectNegPriorityMask | kMiniCard1DetectPosPriorityMask | \
													kMiniCard2DetectNegPriorityMask | kMiniCard2DetectPosPriorityMask)

/* Cmtt1 Standard Wake Interrupt Masks - "and" with current enable register contents */
#define kCmtt1StdInterrupt1Wake					0
#define kCmtt1StdInterrupt2Wake					0 //kMagicBusPositiveMask
#define kCmtt1StdInterrupt3Wake					0 //SSP: kSIBRingDetectPosMask
#define kCmtt1StdInterrupt4Wake					0 //SSP: kKeyboardAttentionNegMask
#define kCmtt1StdInterrupt5Wake					kIntOnButPosMask //SSP: (kSerialDCDPosMask | kKeyboardOnButtonPosMask | kRTCMask | kAlarmMask)
#define kCmtt1StdInterrupt6Wake					kIntGlobalEnMask

#define kStandardShutdownCode					0xDABBFADD

/* Cmtt1 Emergency Wake Interrupt Masks - set enable register contents to these values */
#define kCmtt1EmergInterrupt1Wake				0
#define kCmtt1EmergInterrupt2Wake				0
#define kCmtt1EmergInterrupt3Wake				0
#define kCmtt1EmergInterrupt4Wake				0
#define kCmtt1EmergInterrupt5Wake				kKeyboardOnButtonPosMask
#define kCmtt1EmergInterrupt6Wake				kIntGlobalEnMask

#define kEmergencyShutdownCode					0xFEADDEAF

/* Cmtt1 IO and MFIO Pin Masks */
						/***** Register Equates (PoseidonModule.ioControl) *****/	
#define	kMiniCard1DetectDebounceMask			kIODebounceSelect6Mask	/* 30 */
#define	kMiniCard2DetectDebounceMask			kIODebounceSelect5Mask	/* 29 */
#define	kSerialDCDDebounceMask					kIODebounceSelect4Mask	/* 28 */
#define	kSerialDTRDebounceMask					kIODebounceSelect3Mask	/* 27 */
#define	kMModuleInterruptDebounceMask			kIODebounceSelect2Mask	/* 26 */
#define	kMModuleWakeDebounceMask				kIODebounceSelect1Mask	/* 25 */
#define	kMModuleAttachedDebounceMask			kIODebounceSelect0Mask	/* 24 */

#define	kMiniCard1DetectDirectionMask			kIOOutputSelect6Mask	/* 22 */
#define	kMiniCard2DetectDirectionMask			kIOOutputSelect5Mask	/* 21 */
#define	kSerialDCDDirectionMask					kIOOutputSelect4Mask	/* 20 */
#define	kSerialDTRDirectionMask					kIOOutputSelect3Mask	/* 19 */
#define	kMModuleInterruptDirectionMask			kIOOutputSelect2Mask	/* 18 */
#define	kMModuleWakeDirectionMask				kIOOutputSelect1Mask	/* 17 */
#define	kMModuleAttachedDirectionMask			kIOOutputSelect0Mask	/* 16 */

#define	kMiniCard1DetectDataOutMask				kIODataOut6Mask	/* 14 */
#define	kMiniCard2DetectDataOutMask				kIODataOut5Mask	/* 13 */
#define	kSerialDCDDataOutMask					kIODataOut4Mask	/* 12 */
#define	kSerialDTRDataOutMask					kIODataOut3Mask	/* 11 */
#define	kMModuleInterruptDataOutMask			kIODataOut2Mask	/* 10 */
#define	kMModuleWakeDataOutMask					kIODataOut1Mask	/* 9 */
#define	kMModuleAttachedDataOutMask				kIODataOut0Mask	/* 8 */

#define	kMiniCard1DetectDataInMask				kIODataIn6Mask	/* 6 */
#define	kMiniCard2DetectDataInMask				kIODataIn5Mask	/* 5 */
#define	kSerialDCDDataInMask					kIODataIn4Mask	/* 4 */
#define	kSerialDTRDataInMask					kIODataIn3Mask	/* 3 */
#define	kMModuleInterruptDataInMask				kIODataIn2Mask	/* 2 */
#define	kMModuleWakeDataInMask					kIODataIn1Mask	/* 1 */
#define	kMModuleAttachedDataInMask				kIODataIn0Mask	/* 0 */

						/***** Register Equates (PoseidonModule.ioPowerDown) *****/	
#define	kMiniCard1DetectPowerDownMask			kIOPowerDown6Mask	/* 6 */
#define	kMiniCard2DetectPowerDownMask			kIOPowerDown5Mask	/* 5 */
#define	kSerialDCDPowerDownMask					kIOPowerDown4Mask	/* 4 */
#define	kSerialDTRPowerDownMask					kIOPowerDown3Mask	/* 3 */
#define	kMModuleInterruptPowerDownMask			kIOPowerDown2Mask	/* 2 */
#define	kMModuleWakePowerDownMask				kIOPowerDown1Mask	/* 1 */
#define	kMModuleAttachedPowerDownMask			kIOPowerDown0Mask	/* 0 */


						/***** Register Equates (PoseidonModule.mfioDataOutput) *****/	
#define	kSerialRTSDataOutMask					kIOMfioDataOut31Mask	/* 31 */
#define	kSerialCTSDataOutMask					kIOMfioDataOut30Mask	/* 30 */
#define	kMiniCard2ResetDataOutMask				kIOMfioDataOut29Mask	/* 29 */
#define	kMiniCard2BusyDataOutMask				kIOMfioDataOut28Mask	/* 28 */
#define	kPowerVCC3DataOutMask					kIOMfioDataOut27Mask	/* 27 */
#define	kPowerDRAMVCCOnDataOutMask				kIOMfioDataOut26Mask	/* 26 */
#define	kDisplayVBacklightOnDataOutMask			kIOMfioDataOut25Mask	/* 25 */
#define	kMagicBusTXDataDataOutMask				kIOMfioDataOut24Mask	/* 24 */
#define	kMagicBusRXDataDataOutMask				kIOMfioDataOut23Mask	/* 23 */
#define	kMiniCard2MCCSDataOutMask				kIOMfioDataOut22Mask	/* 22 */
#define	kMModuleCS2DataOutMask					kIOMfioDataOut21Mask	/* 21 */
#define	kMiniCard1SDADataOutMask				kIOMfioDataOut20Mask	/* 20 */
#define	kMiniCard2SDADataOutMask				kIOMfioDataOut19Mask	/* 19 */
#define	kMiniCardSCLDataOutMask					kIOMfioDataOut18Mask	/* 18 */
#define	kDisplayVLCDOnDataOutMask				kIOMfioDataOut17Mask	/* 17 */
#define	kMagicBusVCCOnDataOutMask				kIOMfioDataOut16Mask	/* 16 */
#define	kKeyboardSPIClockDataOutMask			kIOMfioDataOut15Mask	/* 15 */
#define	kKeyboardSPIOutDataOutMask				kIOMfioDataOut14Mask	/* 14 */
#define	kKeyboardSPIInDataOutMask				kIOMfioDataOut13Mask	/* 13 */
#define	kFlashOnBoardDataOutMask				kIOMfioDataOut12Mask	/* 12 */
#define	kMModuleCardRegDataOutMask				kIOMfioDataOut11Mask	/* 11 */
#define	kMModuleCardIOWriteDataOutMask			kIOMfioDataOut10Mask	/* 10 */
#define	kMModuleCardIOReadDataOutMask			kIOMfioDataOut9Mask	/* 9 */
#define	kMModuleCardCSLDataOutMask				kIOMfioDataOut8Mask	/* 8 */
#define	kMModuleCardCSHDataOutMask				kIOMfioDataOut7Mask	/* 7 */
#define	kMModuleEnFlashRdDataOutMask			kIOMfioDataOut6Mask	/* 6 */
#define	kIrDAShutDownDataOutMask				kIOMfioDataOut5Mask	/* 5 */
#define	kMModuleCardWaitDataOutMask				kIOMfioDataOut4Mask	/* 4 */
#define	kKeyboardWakeDataOutMask				kIOMfioDataOut3Mask	/* 3 */
#define	kKeyboardResetDataOutMask				kIOMfioDataOut2Mask	/* 2 */
#define	kKeyboardAttentionDataOutMask			kIOMfioDataOut1Mask	/* 1 */
#define	kSIBRingDetectDataOutMask				kIOMfioDataOut0Mask	/* 0 */

						/***** Register Equates (PoseidonModule.mfioDirection) *****/	
#define	kSerialRTSDirectionMask					kIOMfioOutputSelect31Mask	/* 31 */
#define	kSerialCTSDirectionMask					kIOMfioOutputSelect30Mask	/* 30 */
#define	kMiniCard2ResetDirectionMask			kIOMfioOutputSelect29Mask	/* 29 */
#define	kMiniCard2BusyDirectionMask				kIOMfioOutputSelect28Mask	/* 28 */
#define	kPowerVCC3DirectionMask					kIOMfioOutputSelect27Mask	/* 27 */
#define	kPowerDRAMVCCOnDirectionMask			kIOMfioOutputSelect26Mask	/* 26 */
#define	kDisplayVBacklightOnDirectionMask		kIOMfioOutputSelect25Mask	/* 25 */
#define	kMagicBusTXDataDirectionMask			kIOMfioOutputSelect24Mask	/* 24 */
#define	kMagicBusRXDataDirectionMask			kIOMfioOutputSelect23Mask	/* 23 */
#define	kMiniCard2MCCSDirectionMask				kIOMfioOutputSelect22Mask	/* 22 */
#define	kMModuleCS2DirectionMask				kIOMfioOutputSelect21Mask	/* 21 */
#define	kMiniCard1SDADirectionMask				kIOMfioOutputSelect20Mask	/* 20 */
#define	kMiniCard2SDADirectionMask				kIOMfioOutputSelect19Mask	/* 19 */
#define	kMiniCardSCLDirectionMask				kIOMfioOutputSelect18Mask	/* 18 */
#define	kDisplayVLCDOnDirectionMask				kIOMfioOutputSelect17Mask	/* 17 */
#define	kMagicBusVCCOnDirectionMask				kIOMfioOutputSelect16Mask	/* 16 */
#define	kKeyboardSPIClockDirectionMask			kIOMfioOutputSelect15Mask	/* 15 */
#define	kKeyboardSPIOutDirectionMask			kIOMfioOutputSelect14Mask	/* 14 */
#define	kKeyboardSPIInDirectionMask				kIOMfioOutputSelect13Mask	/* 13 */
#define	kFlashOnBoardDirectionMask				kIOMfioOutputSelect12Mask	/* 12 */
#define	kMModuleCardRegDirectionMask			kIOMfioOutputSelect11Mask	/* 11 */
#define	kMModuleCardIOWriteDirectionMask		kIOMfioOutputSelect10Mask	/* 10 */
#define	kMModuleCardIOReadDirectionMask			kIOMfioOutputSelect9Mask	/* 9 */
#define	kMModuleCardCSLDirectionMask			kIOMfioOutputSelect8Mask	/* 8 */
#define	kMModuleCardCSHDirectionMask			kIOMfioOutputSelect7Mask	/* 7 */
#define	kMModuleEnFlashRdDirectionMask			kIOMfioOutputSelect6Mask	/* 6 */
#define	kIrDAShutDownDirectionMask				kIOMfioOutputSelect5Mask	/* 5 */
#define	kMModuleCardWaitDirectionMask			kIOMfioOutputSelect4Mask	/* 4 */
#define	kKeyboardWakeDirectionMask				kIOMfioOutputSelect3Mask	/* 3 */
#define	kKeyboardResetDirectionMask				kIOMfioOutputSelect2Mask	/* 2 */
#define	kKeyboardAttentionDirectionMask			kIOMfioOutputSelect1Mask	/* 1 */
#define	kSIBRingDetectDirectionMask				kIOMfioOutputSelect0Mask	/* 0 */

						/***** Register Equates (PoseidonModule.mfioDataInput) *****/	
#define	kSerialRTSDataInMask					kIOMfioDataIn31Mask	/* 31 */
#define	kSerialCTSDataInMask					kIOMfioDataIn30Mask	/* 30 */
#define	kMiniCard2ResetDataInMask				kIOMfioDataIn29Mask	/* 29 */
#define	kMiniCard2BusyDataInMask				kIOMfioDataIn28Mask	/* 28 */
#define	kPowerVCC3DataInMask					kIOMfioDataIn27Mask	/* 27 */
#define	kPowerDRAMVCCOnDataInMask				kIOMfioDataIn26Mask	/* 26 */
#define	kDisplayVBacklightOnDataInMask			kIOMfioDataIn25Mask	/* 25 */
#define	kMagicBusTXDataDataInMask				kIOMfioDataIn24Mask	/* 24 */
#define	kMagicBusRXDataDataInMask				kIOMfioDataIn23Mask	/* 23 */
#define	kMiniCard2MCCSDataInMask				kIOMfioDataIn22Mask	/* 22 */
#define	kMModuleCS2DataInMask					kIOMfioDataIn21Mask	/* 21 */
#define	kMiniCard1SDADataInMask					kIOMfioDataIn20Mask	/* 20 */
#define	kMiniCard2SDADataInMask					kIOMfioDataIn19Mask	/* 19 */
#define	kMiniCardSCLDataInMask					kIOMfioDataIn18Mask	/* 18 */
#define	kDisplayVLCDOnDataInMask				kIOMfioDataIn17Mask	/* 17 */
#define	kMagicBusVCCOnDataInMask				kIOMfioDataIn16Mask	/* 16 */
#define	kKeyboardSPIClockDataInMask				kIOMfioDataIn15Mask	/* 15 */
#define	kKeyboardSPIOutDataInMask				kIOMfioDataIn14Mask	/* 14 */
#define	kKeyboardSPIInDataInMask				kIOMfioDataIn13Mask	/* 13 */
#define	kFlashOnBoardDataInMask					kIOMfioDataIn12Mask	/* 12 */
#define	kMModuleCardRegDataInMask				kIOMfioDataIn11Mask	/* 11 */
#define	kMModuleCardIOWriteDataInMask			kIOMfioDataIn10Mask	/* 10 */
#define	kMModuleCardIOReadDataInMask			kIOMfioDataIn9Mask	/* 9 */
#define	kMModuleCardCSLDataInMask				kIOMfioDataIn8Mask	/* 8 */
#define	kMModuleCardCSHDataInMask				kIOMfioDataIn7Mask	/* 7 */
#define	kMModuleEnFlashRdDataInMask				kIOMfioDataIn6Mask	/* 6 */
#define	kIrDAShutDownDataInMask					kIOMfioDataIn5Mask	/* 5 */
#define	kMModuleCardWaitDataInMask				kIOMfioDataIn4Mask	/* 4 */
#define	kKeyboardWakeDataInMask					kIOMfioDataIn3Mask	/* 3 */
#define	kKeyboardResetDataInMask				kIOMfioDataIn2Mask	/* 2 */
#define	kKeyboardAttentionDataInMask			kIOMfioDataIn1Mask	/* 1 */
#define	kSIBRingDetectDataInMask				kIOMfioDataIn0Mask	/* 0 */

						/***** Register Equates (PoseidonModule.mfioSelect) *****/	
#define	kSerialRTSSelectMask					kIOMfioSelect31Mask	/* 31 */
#define	kSerialCTSSelectMask					kIOMfioSelect30Mask	/* 30 */
#define	kMiniCard2ResetSelectMask				kIOMfioSelect29Mask	/* 29 */
#define	kMiniCard2BusySelectMask				kIOMfioSelect28Mask	/* 28 */
#define	kPowerVCC3SelectMask					kIOMfioSelect27Mask	/* 27 */
#define	kPowerDRAMVCCOnSelectMask				kIOMfioSelect26Mask	/* 26 */
#define	kDisplayVBacklightOnSelectMask			kIOMfioSelect25Mask	/* 25 */
#define	kMagicBusTXDataSelectMask				kIOMfioSelect24Mask	/* 24 */
#define	kMagicBusRXDataSelectMask				kIOMfioSelect23Mask	/* 23 */
#define	kMiniCard2MCCSSelectMask				kIOMfioSelect22Mask	/* 22 */
#define	kMModuleCS2SelectMask					kIOMfioSelect21Mask	/* 21 */
#define	kMiniCard1SDASelectMask					kIOMfioSelect20Mask	/* 20 */
#define	kMiniCard2SDASelectMask					kIOMfioSelect19Mask	/* 19 */
#define	kMiniCardSCLSelectMask					kIOMfioSelect18Mask	/* 18 */
#define	kDisplayVLCDOnSelectMask				kIOMfioSelect17Mask	/* 17 */
#define	kMagicBusVCCOnSelectMask				kIOMfioSelect16Mask	/* 16 */
#define	kKeyboardSPIClockSelectMask				kIOMfioSelect15Mask	/* 15 */
#define	kKeyboardSPIOutSelectMask				kIOMfioSelect14Mask	/* 14 */
#define	kKeyboardSPIInSelectMask				kIOMfioSelect13Mask	/* 13 */
#define	kFlashOnBoardSelectMask					kIOMfioSelect12Mask	/* 12 */
#define	kMModuleCardRegSelectMask				kIOMfioSelect11Mask	/* 11 */
#define	kMModuleCardIOWriteSelectMask			kIOMfioSelect10Mask	/* 10 */
#define	kMModuleCardIOReadSelectMask			kIOMfioSelect9Mask	/* 9 */
#define	kMModuleCardCSLSelectMask				kIOMfioSelect8Mask	/* 8 */
#define	kMModuleCardCSHSelectMask				kIOMfioSelect7Mask	/* 7 */
#define	kMModuleEnFlashRdSelectMask				kIOMfioSelect6Mask	/* 6 */
#define	kIrDAShutDownSelectMask					kIOMfioSelect5Mask	/* 5 */
#define	kMModuleCardWaitSelectMask				kIOMfioSelect4Mask	/* 4 */
#define	kKeyboardWakeSelectMask					kIOMfioSelect3Mask	/* 3 */
#define	kKeyboardResetSelectMask				kIOMfioSelect2Mask	/* 2 */
#define	kKeyboardAttentionSelectMask			kIOMfioSelect1Mask	/* 1 */
#define	kSIBRingDetectSelectMask				kIOMfioSelect0Mask	/* 0 */

						/***** Register Equates (PoseidonModule.mfioPowerDown) *****/	
#define	kSerialRTSPowerDownMask					kIOMfioPowerDown31Mask	/* 31 */
#define	kSerialCTSPowerDownMask					kIOMfioPowerDown30Mask	/* 30 */
#define	kMiniCard2ResetPowerDownMask			kIOMfioPowerDown29Mask	/* 29 */
#define	kMiniCard2BusyPowerDownMask				kIOMfioPowerDown28Mask	/* 28 */
#define	kPowerVCC3PowerDownMask					kIOMfioPowerDown27Mask	/* 27 */
#define	kPowerDRAMVCCOnPowerDownMask			kIOMfioPowerDown26Mask	/* 26 */
#define	kDisplayVBacklightOnPowerDownMask		kIOMfioPowerDown25Mask	/* 25 */
#define	kMagicBusTXDataPowerDownMask			kIOMfioPowerDown24Mask	/* 24 */
#define	kMagicBusRXDataPowerDownMask			kIOMfioPowerDown23Mask	/* 23 */
#define	kMiniCard2MCCSPowerDownMask				kIOMfioPowerDown22Mask	/* 22 */
#define	kMModuleCS2PowerDownMask				kIOMfioPowerDown21Mask	/* 21 */
#define	kMiniCard1SDAPowerDownMask				kIOMfioPowerDown20Mask	/* 20 */
#define	kMiniCard2SDAPowerDownMask				kIOMfioPowerDown19Mask	/* 19 */
#define	kMiniCardSCLPowerDownMask				kIOMfioPowerDown18Mask	/* 18 */
#define	kDisplayVLCDOnPowerDownMask				kIOMfioPowerDown17Mask	/* 17 */
#define	kMagicBusVCCOnPowerDownMask				kIOMfioPowerDown16Mask	/* 16 */
#define	kKeyboardSPIClockPowerDownMask			kIOMfioPowerDown15Mask	/* 15 */
#define	kKeyboardSPIOutPowerDownMask			kIOMfioPowerDown14Mask	/* 14 */
#define	kKeyboardSPIInPowerDownMask				kIOMfioPowerDown13Mask	/* 13 */
#define	kFlashOnBoardPowerDownMask				kIOMfioPowerDown12Mask	/* 12 */
#define	kMModuleCardRegPowerDownMask			kIOMfioPowerDown11Mask	/* 11 */
#define	kMModuleCardIOWritePowerDownMask		kIOMfioPowerDown10Mask	/* 10 */
#define	kMModuleCardIOReadPowerDownMask			kIOMfioPowerDown9Mask	/* 9 */
#define	kMModuleCardCSLPowerDownMask			kIOMfioPowerDown8Mask	/* 8 */
#define	kMModuleCardCSHPowerDownMask			kIOMfioPowerDown7Mask	/* 7 */
#define	kMModuleEnFlashRdPowerDownMask			kIOMfioPowerDown6Mask	/* 6 */
#define	kIrDAShutDownPowerDownMask				kIOMfioPowerDown5Mask	/* 5 */
#define	kMModuleCardWaitPowerDownMask			kIOMfioPowerDown4Mask	/* 4 */
#define	kKeyboardWakePowerDownMask				kIOMfioPowerDown3Mask	/* 3 */
#define	kKeyboardResetPowerDownMask				kIOMfioPowerDown2Mask	/* 2 */
#define	kKeyboardAttentionPowerDownMask			kIOMfioPowerDown1Mask	/* 1 */
#define	kSIBRingDetectPowerDownMask				kIOMfioPowerDown0Mask	/* 0 */

/* Cmtt1 Default IO and MFIO Masks */
#define	kCmtt1IOControlDefaultMask				(kSerialDTRDirectionMask | kMModuleWakeDirectionMask | kSerialDTRDataOutMask)

#define	kCmtt1IOPowerDownDefaultMask			(kMiniCard1DetectPowerDownMask | kMiniCard2DetectPowerDownMask | \
													kSerialDTRPowerDownMask | kMModuleInterruptPowerDownMask | \
													kMModuleWakePowerDownMask | kMModuleAttachedPowerDownMask)

#define	kCmtt1MFIODataOutputDefaultMask			(kMiniCard2ResetDataOutMask | kPowerDRAMVCCOnDataOutMask | \
													kKeyboardWakeDataOutMask | kKeyboardResetDataOutMask | \
													kDisplayVLCDOnDataOutMask | kSerialRTSDataOutMask)

#define	kCmtt1MFIODirectionDefaultMask			(kSerialRTSDirectionMask | \
													kMiniCard2ResetDirectionMask | kMiniCard2BusyDirectionMask | \
													kPowerDRAMVCCOnDirectionMask | kDisplayVBacklightOnDirectionMask | \
													kIrDAShutDownDirectionMask | kMiniCard1SDADirectionMask | \
													kMiniCard2SDADirectionMask | kMiniCardSCLDirectionMask | \
													kDisplayVLCDOnDirectionMask | kMagicBusVCCOnDirectionMask | \
													kKeyboardResetDirectionMask)

#define	kCmtt1MFIOSelectDefaultMask				(kSerialCTSSelectMask | kSerialRTSSelectMask | \
													kMiniCard2ResetSelectMask | kMiniCard2BusySelectMask | \
													kPowerDRAMVCCOnSelectMask | kDisplayVBacklightOnSelectMask | \
													kIrDAShutDownSelectMask | kMiniCard1SDASelectMask | \
													kMiniCard2SDASelectMask | kMiniCardSCLSelectMask | \
													kDisplayVLCDOnSelectMask | kMagicBusVCCOnSelectMask | \
													kFlashOnBoardSelectMask | kMModuleEnFlashRdSelectMask | \
													kMModuleCardWaitSelectMask	| kKeyboardWakeSelectMask | \
													kKeyboardResetSelectMask | kKeyboardAttentionSelectMask | \
													kSIBRingDetectSelectMask | kPowerVCC3SelectMask)

#define	kCmtt1MFIOPowerDownDefaultMask			(kSerialCTSPowerDownMask | kSerialRTSPowerDownMask | \
													kMiniCard2ResetPowerDownMask | kMiniCard2BusyPowerDownMask | \
													kDisplayVBacklightOnPowerDownMask | kMagicBusTXDataPowerDownMask | \
													kMagicBusRXDataPowerDownMask | kIrDAShutDownPowerDownMask | \
													kMModuleCS2PowerDownMask | kMiniCard1SDAPowerDownMask | \
													kMiniCard2SDAPowerDownMask | kMiniCardSCLPowerDownMask | \
													kDisplayVLCDOnPowerDownMask | kFlashOnBoardPowerDownMask | \
													kMModuleCardRegPowerDownMask | kMModuleCardIOWritePowerDownMask | \
													kMModuleCardIOReadPowerDownMask | kMModuleCardCSLPowerDownMask | \
													kMModuleCardCSHPowerDownMask | kMModuleEnFlashRdPowerDownMask | \
													kMiniCard2MCCSPowerDownMask | kMModuleCardWaitPowerDownMask)

#ifdef ASM_ONLY
// uses a0, a1, v0, v1; returns rtcLow in v0 and rtcHigh in v1
//		must be called with .set noreorder
//		label 19 = Ripple
#define ReadRTCNoRippleASM														\
	li		a0, kPoseidonModuleAddress;											\
	lw		a1, PoseidonModule_rtcLow(a0);										\
19:;																			\
	lw		v1, PoseidonModule_rtcHigh(a0);										\
	lw		v0, PoseidonModule_rtcLow(a0);										\
	and		v1, 0x000000ff;														\
	bne		a1, v0, 19b;														\
	lw		a1, PoseidonModule_rtcLow(a0);										\
																				\

// uses a0, a1, a2, a3, v0, v1; ticks passed in a0; returns final rtcLow in v0 and rtcHigh in v1
//		must be called with .set noreorder
//		label 31 = WaitHighRoll; label 23 = SkipHighRoll; label 35 = LowReadLoop
#define DelayRTCTicksNoRippleASM												\
	move	a2, a0;																\
	ReadRTCNoRippleASM;															\
	li		a3, 0xffffffff;														\
	subu	a3, v0;																\
	bleu	a2, a3, 23f;														\
	nop;																		\
																				\
	subu	a2, a3;																\
	move	a3, v1;																\
																				\
31:;																			\
	ReadRTCNoRippleASM;															\
	beq		v1, a3, 31b;														\
	nop;																		\
																				\
23:;																			\
	move	a3, v0;																\
	addu	a3, a2;																\
35:;																			\
	ReadRTCNoRippleASM;															\
	bltu	v0, a3, 35b;														\
	nop;																		\
																				\

#else
/*
 * Get the current RTC, avoiding ripple.  We know that if we
 * sandwich a read of rtcHigh between two consistent reads of
 * rtcLow, we have a non-rippling, consistent rtcHigh.
 */
#define ReadRTCNoRipple(poseidonModule, rtcLowVal, rtcHighVal)					\
{																				\
	do	{																		\
		rtcLowVal = poseidonModule->rtcLow;										\
		rtcHighVal = poseidonModule->rtcHigh & 0x000000ff;						\
	} while (rtcLowVal != poseidonModule->rtcLow);								\
}

#define DelayRTCTicksNoRipple(poseidonModule, ticks)							\
{																				\
	ULONG rtcLowVal, rtcHighVal, ticks2, temp;									\
																				\
	ReadRTCNoRipple(poseidonModule, rtcLowVal, rtcHighVal);						\
																				\
	temp = (ULONG)0xffffffff - rtcLowVal;										\
	ticks2 = ticks;																\
																				\
	if (temp < ticks2) {														\
		ticks2 -= temp;															\
		temp = rtcHighVal;														\
																				\
		do {																	\
			ReadRTCNoRipple(poseidonModule, rtcLowVal, rtcHighVal);				\
		} while (rtcHighVal == temp);											\
	}																			\
																				\
	temp = rtcLowVal + ticks2;													\
																				\
	do {																		\
		ReadRTCNoRipple(poseidonModule, rtcLowVal, rtcHighVal);					\
	} while (rtcLowVal  < temp);												\
}

#endif

/*
 * Miscellaneous I/O
 */

#define kIOResetBettyOffMask kIREnRXPwrMask		/* This mask is for PoseidonModule.irControl1 */

/* 
 * Macros
 */

#define AssertBettyResetSignal() \
	poseidonHw->irControl1 &= ~kIOResetBettyOffMask;	

#define DeAssertBettyResetSignal() \
	poseidonHw->irControl1 |= kIOResetBettyOffMask;	

#endif

