/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
Copyright (c) 2001. Samsung Electronics, co. ltd  All rights reserved.

Module Name:  

Abstract:

    S3C2440 interrupt definitions

Notes: 
--*/

// These are the 'standard' interrupts
#define SYSINTR_KEYBOARD				(SYSINTR_FIRMWARE+0)
#define SYSINTR_TOUCH					(SYSINTR_FIRMWARE+1)
#define SYSINTR_ADC						(SYSINTR_FIRMWARE+2)
#define SYSINTR_SERIAL					(SYSINTR_FIRMWARE+3)
#define SYSINTR_AUDIO					(SYSINTR_FIRMWARE+4)
#define SYSINTR_PCMCIA_STATE			(SYSINTR_FIRMWARE+5)
#define SYSINTR_PCMCIA_EDGE				(SYSINTR_FIRMWARE+6)
#define SYSINTR_PCMCIA_LEVEL			(SYSINTR_FIRMWARE+7)
#define SYSINTR_TOUCH_CHANGED			(SYSINTR_FIRMWARE+8)
#define SYSINTR_IR						(SYSINTR_FIRMWARE+9)
#define SYSINTR_ETHER					(SYSINTR_FIRMWARE+10)
#define SYSINTR_USB						(SYSINTR_FIRMWARE+11)
#define SYSINTR_USBD					(SYSINTR_FIRMWARE+12)
#define SYSINTR_POWER					(SYSINTR_FIRMWARE+13)
#define	SYSINTR_SDMMC					(SYSINTR_FIRMWARE+14)
#define SYSINTR_SDMMC_CARD_DETECT		(SYSINTR_FIRMWARE+15)
#define SYSINTR_SDMMC_SDIO_INTERRUPT	(SYSINTR_FIRMWARE+16)
#define SYSINTR_BUTTON					(SYSINTR_FIRMWARE+17)
#define	SYSINTR_DMA0					(SYSINTR_FIRMWARE+18)
#define SYSINTR_DMA3					(SYSINTR_FIRMWARE+19)
#define SYSINTR_CAM						(SYSINTR_FIRMWARE+20)
#define SYSINTR_IIC						(SYSINTR_FIRMWARE+21)



// I get the follow MapIrq2SysIntr inline function from CEPC include directory. hjcho.
//
// CEPC device drivers should get their IRQ number from the registry and use
// MapIrq2SysIntr to get the appropriate SYSINTR_* number to use.
_inline
DWORD
MapIrq2SysIntr(DWORD _Irq)
{
    if( _Irq<=18 )
        return ( SYSINTR_FIRMWARE + _Irq );
    else
        return (0xffffffff);
}


// Here are the names of the values stored in the registry
#define PC_REG_IRQ_VAL_NAME			TEXT("IRQ") 
#define PC_REG_IRQ_VAL_LEN			sizeof( DWORD )

#define PC_REG_IOBASE_VAL_NAME		TEXT("IoBase") 
#define PC_REG_IOBASE_VAL_LEN		sizeof( DWORD )
#define PC_REG_IOLEN_VAL_NAME		TEXT("IoLen") 
#define PC_REG_IOLEN_VAL_LEN		sizeof( DWORD )

#define PC_REG_CONFIGBASE_VAL_NAME	TEXT("ConfigBase") 
#define PC_REG_CONFIGBASE_VAL_LEN	sizeof( DWORD )
#define PC_REG_CONFIGLEN_VAL_NAME	TEXT("ConfigLen") 
#define PC_REG_CONFIGLEN_VAL_LEN	sizeof( DWORD )

#define PC_REG_DMA_VAL_NAME			TEXT("DMA") 
#define PC_REG_DMA_VAL_LEN			sizeof( DWORD )

#define PC_REG_DEVINDEX_VAL_NAME	TEXT("DeviceArrayIndex") 
#define PC_REG_DEVINDEX_VAL_LEN		sizeof( DWORD )