// Copyright (c) 1999-2000 Microsoft Corporation.  All rights reserved.
//++
//  shx.h       - TIMER and Interrupt definitions for sh3 and sh4 processors
//
//--

#ifdef SH3
#include "sh3.h"
#endif

#ifdef SH4
#include "sh4.h"
#endif
