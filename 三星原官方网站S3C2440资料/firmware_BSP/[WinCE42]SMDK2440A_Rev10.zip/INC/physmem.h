// Copyright (c) 1999-2000 Microsoft Corporation.  All rights reserved.
/*
 *
 *  These equates define global memory locations in system RAM used by the 
 * HAL and independent of the NK kernel.
 *
 *
 */
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
//
//                           PHYSICAL MEMORY MAP
//
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
#ifndef __PHYSMEM_H_
#define __PHYSMEM_H_

#define  KSEG0_BASE           0x80000000        // 4k for kernel
//#define  KPAGE                0x80001000        // 4k for kernel

#define  TEMP_STACK           0xa0003FE0  // to backward


#ifdef R4102
// This defines the GPIO pin used by the 4102 as the FPGA interrupt
#define  FPGAGPIOIRQ           (1<<9)
#endif

// Add for fwp2.s access to offbutton flag
#if defined(R4101) || defined(R4102)
#define MISC_GLOBALS_BASE  (DRIVER_GLOBALS_PHYSICAL_MEMORY_START + 0x300)
#define OFFBUTTON          0
#endif

// HARDWARE IO REGISTERS -------------------------------------------------------

#endif

