/*********************************************************************
              Copyright (c) 1996 Philips Electronics, Inc.
  Copyright (c) 1999-2000 Microsoft Corporation.  All rights reserved
 *********************************************************************/

#ifndef __POSEIDON__
#define __POSEIDON__

#define SampleRateToDividerModulus(x) (9216000 / (x * 32) - 1)

#define kPoseidonSDram1ModeAddress			0xB0F00000
#define kPoseidonSDram0ModeAddress			0xB0E00000
#define kPoseidonModuleAddress				0xB0C00000
#define kPoseidonBreakpointModuleAddress	0xFF000010
#define kPoseidonChipSelect3Address			0xB0800000
#define kPoseidonChipSelect2Address			0xB0400000
#define kPoseidonChipSelect1Address			0xB0000000

#define kCard1Addr				(0x64000000 - KUSER_OFFSET)
#define kCard2Addr				(0x68000000 - KUSER_OFFSET)

#define kCard1Size				0x04000000
#define kCard2Size				0x04000000

#define kCard1AttributeAddress	0x88000000
#define kCard1IOAddress			0x88000000
#define kCard2AttributeAddress	0x8C000000
#define kCard2IOAddress			0x8C000000

#define kDRAMBank0Offset		0x0
#define kDRAMBank1Offset		0x200000


#define kProtectionLimit		0x10000000		/* limit address for Poseidon protection */

#define kBootParametersOffset		0			/* offset from beginning of ROM in device */
#define kRestorePersistentRAMSize 	0x00020000	
#define kSystemRAMAddr	 			0x00000000
#define kBootStackSize				0x2000

	/* NOTE: change these two in tandem */
#define kVectorDispatchTableSize 2048
#define kVectorDispatchReMapMask 0xC	


/***** Poseidon Exception Number Equates  *****/
/* With Poseidon there are no core exception numbers */

#define kFirstRealVector					0

#define kLCDInterrupt						0
#define kDFInterrupt						1
#define kCHIHalfInterrupt					2
#define kCHIFullInterrupt					3
#define kCHIDMACountInterrupt				4
#define kCHIinInterruptA					5
#define kCHIinintInterruptB					6
#define kCHIactInterrupt					7
#define kCHIErrorInterrupt					8
#define kSoundHalfInterrupt					9
#define kSoundFullInterrupt					10
#define kTelHalfInterrupt					11
#define kTelFullInterrupt					12
#define kSoundDMACountInterrupt				13
#define kTelDMACountInterrupt				14
#define kLeftSoundClipInterrupt				15
#define kRightSoundClipInterrupt			16
#define kvalSoundPositiveInterrupt			17
#define kvalSoundNegativeInterrupt			18
#define kvalTelPositiveInterrupt			19
#define kvalTelNegativeInterrupt			20
#define kSoundinInterrupt					21
#define kTelinInterrupt						22
#define kSIBsf0Interrupt					23
#define kSIBsf1Interrupt					24
#define kSIBPositiveInterrupt				25
#define kSIBNegativeInterrupt				26
#define kInterrupt1Reserved4				27
#define kInterrupt1Reserved3				28
#define kInterrupt1Reserved2				29
#define kInterrupt1Reserved1				30
#define kInterrupt1Reserved0				31
#define kUARTARXInterrupt					32
#define kUARTARXoverrunInterrupt			33
#define kUARTAFrameErrorInterrupt			34
#define kUARTABreakInterrupt				35
#define kUARTAParityErrorInterrupt			36
#define kUARTATXInterrupt					37
#define kUARTATXoverrunInterrupt			38
#define kUARTAEmptyInterrupt				39
#define kUARTADMAFullInterrupt				40
#define kUARTADMAHalfInterrupt				41
#define kUARTBRXInterrupt					42
#define kUARTBRXoverrunInterrupt			43
#define kUARTBFrameErrorInterrupt			44
#define kUARTBBreakInterrupt				45
#define kUARTBParityErrorInterrupt			46
#define kUARTBTXInterrupt					47
#define kUARTBTXoverrunInterrupt			48
#define kUARTBEmptyInterrupt				49
#define kUARTBDMAFullInterrupt				50
#define kUARTBDMAHalfInterrupt				51
#define kMagicBusTXBufferAvailableInterrupt	52
#define kMagicBusTXErrorInterrupt			53
#define kMagicBusEmptyInterrupt				54
#define kMagicBusRXBufferAvailableInterrupt	55
#define kMagicBusRXErrorInterrupt			56
#define kMagicBusDetInterrupt				57
#define kMagicBusDMAFullInterrupt			58
#define kMagicBusDMAHalfInterrupt			59
#define kMagicBusPositiveInterrupt			60
#define kMagicBusNegativeInterrupt			61
#define kInterrupt2Reserved1				62
#define kInterrupt2Reserved0				63
#define kmfioPositiveInterrupt31			64
#define kmfioPositiveInterrupt30			65
#define kmfioPositiveInterrupt29			66
#define kmfioPositiveInterrupt28			67
#define kmfioPositiveInterrupt27			68
#define kmfioPositiveInterrupt26			69
#define kmfioPositiveInterrupt25			70
#define kmfioPositiveInterrupt24			71
#define kmfioPositiveInterrupt23			72
#define kmfioPositiveInterrupt22			73
#define kmfioPositiveInterrupt21			74
#define kmfioPositiveInterrupt20			75
#define kmfioPositiveInterrupt19			76
#define kmfioPositiveInterrupt18			77
#define kmfioPositiveInterrupt17			78
#define kmfioPositiveInterrupt16			79
#define kmfioPositiveInterrupt15			80
#define kmfioPositiveInterrupt14			81
#define kmfioPositiveInterrupt13			82
#define kmfioPositiveInterrupt12			83
#define kmfioPositiveInterrupt11			84
#define kmfioPositiveInterrupt10			85
#define kmfioPositiveInterrupt9				86
#define kmfioPositiveInterrupt8				87
#define kmfioPositiveInterrupt7				88
#define kmfioPositiveInterrupt6				89
#define kmfioPositiveInterrupt5				90
#define kmfioPositiveInterrupt4				91
#define kmfioPositiveInterrupt3				92
#define kmfioPositiveInterrupt2				93
#define kmfioPositiveInterrupt1				94
#define kmfioPositiveInterrupt0				95
#define kmfioNegativeInterrupt31			96
#define kmfioNegativeInterrupt30			97
#define kmfioNegativeInterrupt29			98
#define kmfioNegativeInterrupt28			99
#define kmfioNegativeInterrupt27			100
#define kmfioNegativeInterrupt26			101
#define kmfioNegativeInterrupt25			102
#define kmfioNegativeInterrupt24			103
#define kmfioNegativeInterrupt23			104
#define kmfioNegativeInterrupt22			105
#define kmfioNegativeInterrupt21			106
#define kmfioNegativeInterrupt20			107
#define kmfioNegativeInterrupt19			108
#define kmfioNegativeInterrupt18			109
#define kmfioNegativeInterrupt17			110
#define kmfioNegativeInterrupt16			111
#define kmfioNegativeInterrupt15			112
#define kmfioNegativeInterrupt14			113
#define kmfioNegativeInterrupt13			114
#define kmfioNegativeInterrupt12			115
#define kmfioNegativeInterrupt11			116
#define kmfioNegativeInterrupt10			117
#define kmfioNegativeInterrupt9				118
#define kmfioNegativeInterrupt8				119
#define kmfioNegativeInterrupt7				120
#define kmfioNegativeInterrupt6				121
#define kmfioNegativeInterrupt5				122
#define kmfioNegativeInterrupt4				123
#define kmfioNegativeInterrupt3				124
#define kmfioNegativeInterrupt2				125
#define kmfioNegativeInterrupt1				126
#define kmfioNegativeInterrupt0				127
#define kRTCInterrupt						128
#define kAlarmInterrupt						129
#define kPeriodicInterrupt					130
#define kStopTimerInterrupt					131
#define kPositivePowerInterrupt				132
#define kNegativePowerInterrupt				133
#define kPositivePowerokInterrupt			134
#define kNegativePowerokInterrupt			135
#define kPositiveOnButtonInterrupt			136
#define kNegativeOnButtonInterrupt			137
#define kSPIBufferAvailableInterrupt		138
#define kSPIErrorInterrupt					139
#define kSPIrcvInterrupt					140
#define kSPIEmptyInterrupt					141
#define kIRconsmInterrupt					142
#define kcarstInterrupt						143
#define kPositivecarInterrupt				144
#define kNegativecarInterrupt				145
#define kioPositiveInterrupt6				146
#define kioPositiveInterrupt5				147
#define kioPositiveInterrupt4				148
#define kioPositiveInterrupt3				149
#define kioPositiveInterrupt2				150
#define kioPositiveInterrupt1				151
#define kioPositiveInterrupt0				152
#define kioNegativeInterrupt6				153
#define kioNegativeInterrupt5				154
#define kioNegativeInterrupt4				155
#define kioNegativeInterrupt3				156
#define kioNegativeInterrupt2				157
#define kioNegativeInterrupt1				158
#define kioNegativeInterrupt0				159

#define kGlacier1IOPositiveInterrupt12		160
#define kGlacier1IOPositiveInterrupt11		161
#define kGlacier1IOPositiveInterrupt10		162
#define kGlacier1IOPositiveInterrupt3		163
#define kGlacier1IOPositiveInterrupt2		164
#define kGlacier1IOPositiveInterrupt1		165

#define kGlacier1IONegativeInterrupt12		166
#define kGlacier1IONegativeInterrupt11		167
#define kGlacier1IONegativeInterrupt10		168
#define kGlacier1IONegativeInterrupt3		169
#define kGlacier1IONegativeInterrupt2		170
#define kGlacier1IONegativeInterrupt1		171

#define kGlacier2IOPositiveInterrupt12		172
#define kGlacier2IOPositiveInterrupt11		173
#define kGlacier2IOPositiveInterrupt10		174
#define kGlacier2IOPositiveInterrupt3		175
#define kGlacier2IOPositiveInterrupt2		176
#define kGlacier2IOPositiveInterrupt1		177

#define kGlacier2IONegativeInterrupt12		178
#define kGlacier2IONegativeInterrupt11		179
#define kGlacier2IONegativeInterrupt10		180
#define kGlacier2IONegativeInterrupt3		181
#define kGlacier2IONegativeInterrupt2		182
#define kGlacier2IONegativeInterrupt1		183

#define kNumHandlers						184
#define kNumPoseidonHandlers				160


/***** BIU Module Equates *****/
/***** Memory Configuration Register 0 Equates (PoseidonModule.memoryConfiguration0) *****/
#define kMemDClkoutTriStateMask		0x40000000	/* 30 */
#define kMemDisDqmInitMask			0x20000000	/* 29 */
#define kMemEnSdramPowDownMask		0x10000000	/* 28 */
#define kMemShowPoseidonMask			0x08000000	/* 27 */
#define kMemEnAddrRmap2Mask			0x04000000	/* 26 */
#define kMemEnAddrRmap1Mask			0x02000000	/* 25 */
#define kMemEnPageModeWrinMask		0x01000000	/* 24 */
#define kMemEnCs3UserMask			0x00800000	/* 23 */
#define kMemEnCs2UserMask			0x00400000	/* 22 */
#define kMemEnCs1UserMask			0x00200000	/* 21 */
#define kMemEnCs1Bank01Mask			0x00100000	/* 20 */
#define kMemBank1ConfMask			0x000c0000	/* 19:18 */
#define kMemBank0ConfMask			0x00030000	/* 17:16 */
#define kMemBank1RowSelMask			0x0000c000	/* 15:14 */
#define kMemBank0RowSelMask			0x00003000	/* 13:12 */
#define kMemBank1ColSelMask			0x00000f00	/* 11:8 */
#define kMemBank0ColSelMask			0x000000f0	/* 7:4 */
#define kMemCs332BitMask			0x00000008	/* 3 */
#define kMemCs232BitMask			0x00000004	/* 2 */
#define kMemCs132BitMask			0x00000002	/* 1 */
#define kMemCs032BitMask			0x00000001	/* 0 */

/***** Values for kMemBank1ConfMask field *****/
#define kMemEnBank1Sdram_16			0x000c0000
#define kMemEnBank1Sdram_8			0x00080000
#define kMemEnBank1Dram_32			0x00040000
#define kMemEnBank1Dram_16			0x00000000
#define kMemBank1ConfShift			18

/***** Values for kMemBank0ConfMask field *****/
#define kMemEnBank0Sdram_16			0x00030000
#define kMemEnBank0Sdram_8			0x00020000
#define kMemEnBank0Dram_32			0x00010000
#define kMemEnBank0Dram_16			0x00000000
#define kMemBank0ConfShift			16

/***** Values for kMemBank1RowSelMask field *****/
#define kMemBank1RowSel3			0x0000c000
#define kMemBank1RowSel2			0x00008000
#define kMemBank1RowSel1			0x00004000
#define kMemBank1RowSel0			0x00000000
#define kMemBank1RowSelShift		14

/***** Values for kMemBank0RowSelMask field *****/
#define kMemBank0RowSel3			0x00003000
#define kMemBank0RowSel2			0x00002000
#define kMemBank0RowSel1			0x00001000
#define kMemBank0RowSel0			0x00000000
#define kMemBank0RowSelShift		12

/***** Values for kMemBank1ColSelMask field *****/
#define kMemBank1ColSel9			0x00000900
#define kMemBank1ColSel8			0x00000800
#define kMemBank1ColSel7			0x00000700
#define kMemBank1ColSel6			0x00000600
#define kMemBank1ColSel5			0x00000500
#define kMemBank1ColSel4			0x00000400
#define kMemBank1ColSel3			0x00000300
#define kMemBank1ColSel2			0x00000200
#define kMemBank1ColSel1			0x00000100
#define kMemBank1ColSel0			0x00000000
#define kMemBank1ColSelShift		8

/***** Values for kMemBank0ColSelMask field *****/
#define kMemBank0ColSel9			0x00000090
#define kMemBank0ColSel8			0x00000080
#define kMemBank0ColSel7			0x00000070
#define kMemBank0ColSel6			0x00000060
#define kMemBank0ColSel5			0x00000050
#define kMemBank0ColSel4			0x00000040
#define kMemBank0ColSel3			0x00000030
#define kMemBank0ColSel2			0x00000020
#define kMemBank0ColSel1			0x00000010
#define kMemBank0ColSel0			0x00000000
#define kMemBank0ColSelShift		4

/***** Memory Configuration Register 1 Equates (PoseidonModule.memoryConfiguration1) *****/
#define kMemMcs3AccVal1Mask			0xf0000000	/* 31:28 */
#define kMemMcs3AccVal2Mask			0x0f000000	/* 27:24 */
#define kMemMcs2AccVal1Mask			0x00f00000	/* 23:20 */
#define kMemMcs2AccVal2Mask			0x000f0000	/* 19:16 */
#define kMemMcs1AccVal1Mask			0x0000f000	/* 15:12 */
#define kMemMcs1AccVal2Mask			0x00000f00	/* 11:8 */
#define kMemMcs0AccVal1Mask			0x000000f0	/* 7:4 */
#define kMemMcs0AccVal2Mask			0x0000000f	/* 3:0 */  

#define kMemMcs3AccVal1Shift		28
#define kMemMcs3AccVal2Shift		24
#define kMemMcs2AccVal1Shift		20
#define kMemMcs2AccVal2Shift		16
#define kMemMcs1AccVal1Shift		12
#define kMemMcs1AccVal2Shift		8
#define kMemMcs0AccVal1Shift		4
#define kMemMcs0AccVal2Shift		0

/***** Memory Configuration Register 2 Equates (PoseidonModule.memoryConfiguration2) *****/
#define kMemCs3AccVal1Mask			0xf0000000	/* 31:28 */
#define kMemCs3AccVal2Mask			0x0f000000	/* 27:24 */
#define kMemCs2AccVal1Mask			0x00f00000	/* 23:20 */
#define kMemCs2AccVal2Mask			0x000f0000	/* 19:16 */
#define kMemCs1AccVal1Mask			0x0000f000	/* 15:12 */
#define kMemCs1AccVal2Mask			0x00000f00	/* 11:8 */ 
#define kMemCs0AccVal1Mask			0x000000f0	/* 7:4 */  
#define kMemCs0AccVal2Mask			0x0000000f	/* 3:0 */  

#define kMemCs3AccVal1Shift			28
#define kMemCs3AccVal2Shift			24
#define kMemCs2AccVal1Shift			20
#define kMemCs2AccVal2Shift			16
#define kMemCs1AccVal1Shift			12
#define kMemCs1AccVal2Shift			8
#define kMemCs0AccVal1Shift			4
#define kMemCs0AccVal2Shift			0

/***** Memory Configuration Register 3 Equates (PoseidonModule.memoryConfiguration3) *****/
#define kMemCard2AccValMask			0xf0000000  /* 31:28 */
#define kMemCard1AccValMask			0x0f000000  /* 27:24 */
#define kMemCard2IoAccValMask		0x00f00000  /* 23:20 */
#define kMemCard1IoAccValMask		0x000f0000  /* 19:16 */
#define kMemEnMcs3BurstMask			0x00008000	/* 15 */
#define kMemEnMcs2BurstMask			0x00004000	/* 14 */
#define kMemEnMcs1BurstMask			0x00002000	/* 13 */
#define kMemEnMcs0BurstMask			0x00001000	/* 12 */
#define kMemEnCs3MurstMask			0x00000800	/* 11 */
#define kMemEnCs2burstMask			0x00000400	/* 10 */
#define kMemEnCs1BurstMask			0x00000200	/* 9 */
#define kMemEnCs0BurstMask			0x00000100	/* 8 */
#define kMemCard2WaitEnMask			0x00000080	/* 7 */
#define kMemCard1WaitEnMask			0x00000040	/* 6 */
#define kMemCard2IoEnMask			0x00000020	/* 5 */
#define kMemCard1IoEnMask			0x00000010	/* 4 */

#define kMemCard2AccValShift		28
#define kMemCard1AccValShift		24
#define kMemCard2IoAccValShift		20
#define kMemCard1IoAccValShift		16

#define kWaitStates15				0x0F
#define kWaitStates14				0x0E
#define kWaitStates13				0x0D
#define kWaitStates12				0x0C
#define kWaitStates11				0x0B
#define kWaitStates10				0x0A
#define kWaitStates9				0x09
#define kWaitStates8				0x08
#define kWaitStates7				0x07
#define kWaitStates6				0x06
#define kWaitStates5				0x05
#define kWaitStates4				0x04
#define kWaitStates3				0x03
#define kWaitStates2				0x02
#define kWaitStates1				0x01
#define kWaitStates0				0x00

/***** Memory Configuration Register 4 Equates (PoseidonModule.memoryConfiguration4) *****/
#define kMemEnBank1HDramMask		0x80000000	/* 31 */
#define kMemEnBank0HDramMask		0x40000000	/* 30 */
#define kMemEnArbitrationMask		0x20000000	/* 29 */
#define kMemDisableSnoopMask		0x10000000	/* 28 */
#define kMemClearWriteBusErrIntMask	0x08000000	/* 27 */
#define kMemEnBank1ExtraClkMask		0x04000000	/* 26 */
#define kMemEnBank0ExtraClkMask		0x02000000	/* 25 */
#define kMemEnWatchDogTimerMask		0x01000000	/* 24 */
#define kMemWatchDogValMask			0x00f00000	/* 23:20 */
#define kMemPowerDownMask			0x00010000	/* 16 */
#define kMemEnBank1RefreshMask		0x00008000	/* 15 */
#define kMemEnBank0RefreshMask		0x00004000	/* 14 */
#define kMemBank1RefreshValMask		0x00003f00	/* 13:8 */
#define kMemBank0RefreshValMask		0x0000003f	/* 5:0 */

#define kMemWatchDogValShift		20
#define kMemBank1RefreshValShift	8
#define kMemBank0RefreshValShift	0

#define kRefreshTime15usec			0
#define kRefreshTime60usec			1
#define kRefreshTime90usec			2
#define kRefreshTime120usec			3
#define kRefreshTime150usec			4
#define kRefreshTime180usec			5

#define KWatchDogTime1_7usec		0
#define KWatchDogTime3_4usec		1
#define KWatchDogTime5_2usec		2
#define KWatchDogTime6_9usec		3
#define KWatchDogTime8_6usec		4
#define KWatchDogTime10_3usec		5
#define KWatchDogTime12_0usec		6
#define KWatchDogTime13_8usec		7
#define KWatchDogTime15_5usec		8

#define MEM_WATCHDOG_VAL_TO_MASK(val)		(((val) & 0xf) << kMemWatchDogValShift)
#define MEM_BANK1_REFRESH_VAL_TO_MASK(val)	(((val) & 0x3f) << kMemBank1RefreshValShift)
#define MEM_BANK0_REFRESH_VAL_TO_MASK(val)	(((val) & 0x3f) << kMemBank0RefreshValShift)

/***** Memory Configuration Register 5 Equates (PoseidonModule.memoryConfiguration5) *****/
#define kMemRegion2StartValMask		0xfffffe00	/* 31:9 */
#define kMemRegion2MaskMask			0x0000000f	/* 3:0 */

#define kMemRegion2StartValShift	9

/***** Memory Configuration Register 6 Equates (PoseidonModule.memoryConfiguration6) *****/
#define kMemRegion1StartValMask		0xfffffe00	/* 31:9 */
#define kMemRegion1MaskMask			0x0000000f	/* 3:0 */

#define kMemRegion1StartValShift	9

/***** Memory Configuration Register 7 Equates (PoseidonModule.memoryConfiguration7) *****/
#define kMemRegion2DestAddrMask		0xfffffe00	/* 31:9 */

#define kMemRegion2DestAddrShift	9

/***** Memory Configuration Register 8 Equates (PoseidonModule.memoryConfiguration8) *****/
#define kMemRegion1DestAddrMask		0xfffffe00	/* 31:9 */

#define kMemRegion1DestAddrShift	9


/***** Video Module Equates *****/
/***** Video Control Register Equates (PoseidonModule.videoControl) *****/
#define kVideoLineCntMask			0xffc00000	/* 31:22 */
#define kVideoLoadDelayMask			0x00200000	/* 21 */
#define kVideoBaudValueMask			0x001f0000	/* 20:16 */
#define kVideoDoneValueMask			0x0000fe00	/* 15:9 */
#define kVideoEnFreezeFrameMask		0x00000100	/* 8 */
#define kVideoBitDepthMask			0x000000c0	/* 7:6 */
#define kVideoDisplaySplitMask		0x00000020	/* 5 */
#define kVideoDisplay8Mask			0x00000010	/* 4 */
#define kVideoDfModeMask			0x00000008	/* 3 */
#define kVideoInverseVideoMask		0x00000004	/* 2 */
#define kVideoDisplayOnMask			0x00000002	/* 1 */
#define kVideoEnVideoMask			0x00000001	/* 0 */

#define kVideoLineCntShift			22
#define kVideoBaudValueShift		16
#define	kVideoBitDepthShift			6

/***** Values for kVideoDoneValueMask field *****/
#define kVideoDoneDisableMask		0x0000fe00
#define kVideoDoneEnableMask		0x00000800

/***** Values for kVideoBitDepthMask field *****/
#define kVideoColor8BitMask			0x000000c0
#define kVideoGrey4BitMask			0x00000080
#define kVideoGrey2BitMask			0x00000040
#define kVideoMonoMask				0x00000000

/***** Video Rate & Screen Size Equates (PoseidonModule.videoRateAndScreen) *****/
#define kVideoRateMask				0xffc00000	/* 31:22 */
#define kVideoHorizValueMask		0x001ff000	/* 20:12 */
#define kVideoLineValueMask			0x000003ff	/* 9:0 */
 
#define kVideoRateShift			  	22
#define kVideoHorizValueShift		12
#define kVideoLineValueShift		0

/***** Video High Buffer Equates (PoseidonModule.videoHighBuffer) *****/
#define kVideoBankMask				0xfff00000	/* 31:20 */
#define kVideoBaseHighMask			0x000ffff0	/* 19:4 */

#define kVideoBankShift				20
#define kVideoBaseHighShift			4

/***** Video Low Buffer & DF Equates (PoseidonModule.videoLowBufferAndDf) *****/
#define kVideoDfValueMask			0xff000000	/* 31:24 */
#define kVideoFrameValueMask		0x00f00000	/* 23:20 */
#define kVideoBaseLowMask			0x000ffff0	/* 19:4 */

#define kVideoDfValueShift			24 
#define kVideoBaseLowShift			4
#define kVideoFrameValueDefaultMask	0x00000000

/***** Video Red Palette Equates (PoseidonModule.videoRedPalette) *****/
#define kVideoRedSelectMask			0xffffffff	/* 31:0 */

/***** Video Green Palette Equates (PoseidonModule.videoGreenPalette) *****/
#define kVideoGreenSelectMask		0xffffffff	/* 31:0 */

/***** Video Blue Palette Equates (PoseidonModule.videoBluePalette) *****/
#define kVideoBlueSelectMask		0x0000ffff	/* 15:0 */

/***** Video 2 of 3 Dither Equates (PoseidonModule.videoDither2Of3) *****/
#define kVideoPattern2Of3Mask		0x00000fff	/* 11:0 */

/***** Video n of 4 Dither Equates (PoseidonModule.videoDitherNOf4) *****/
#define kVideoPattern3Of4Mask		0xffff0000	/* 31:16 */
#define kVideoPattern2Of4Mask		0x0000ffff	/* 15:0 */

#define kVideoPattern3Of4Shift		16
#define kVideoPattern2Of4Shift		0

/***** Video 4 of 5 Dither Equates (PoseidonModule.videoDither4Of5) *****/
#define kVideoPattern4Of5Mask		0x000fffff	/* 19:0 */

/***** Video 3 of 5 Dither Equates (PoseidonModule.videoDither3Of5) *****/
#define kVideoPattern3Of5Mask		0x000fffff	/* 19:0 */

/***** Video 6 of 7 Dither Equates (PoseidonModule.videoDither6Of7) *****/
#define kVideoPattern6Of7Mask		0x0fffffff	/* 27:0 */

/***** Video 5 of 7 Dither Equates (PoseidonModule.videoDither5Of7) *****/
#define kVideoPattern5Of7Mask		0x0fffffff	/* 27:0 */

/***** Video 4 of 7 Dither Equates (PoseidonModule.videoDither4Of7) *****/
#define kVideoPattern4Of7Mask		0x0fffffff	/* 27:0 */


/***** SIB Module Equates *****/
/***** SIB Size Register Equates (PoseidonModule.sibSize) *****/
#define kSibTelSizeShift	 		0
#define kSibSoundSizeShift			16

#define kSibTelSizeMask		 		(0x3ffc << kSibTelSizeShift)	/* 29:18 */
#define kSibSoundSizeMask	 		(0x3ffc << kSibSoundSizeShift)	/* 13:2 */

#define kSibBufferSizeMaxBytes		0x4000		/* 16 KBytes */

#define SIB_TELBUF_BYTES_TO_MASK(bytes)	((((bytes) >> 2) & 0xfff) << kSIBTelSizeShift)
#define SIB_SNDBUF_BYTES_TO_MASK(bytes)	((((bytes) >> 2) & 0xfff) << kSIBSoundSizeShift)
#define SIB_TELBUF_MASK_TO_BYTES(mask)	((((mask) >> kSIBTelSizeShift) & 0xfff) << 2)
#define SIB_SNDBUF_MASK_TO_BYTES(mask)	((((mask) >> kSIBSoundSizeShift) & 0xfff) << 2)

/***** SIB Sound Receive Start Register Equates (PoseidonModule.sibSoundRxStart) *****/
/***** SIB Sound Transmit Start Register Equates (PoseidonModule.sibSoundTxStart) *****/
#define kSibSoundRxStartMask		0xfffffffc	/* 31:2 */
#define kSibSoundRxStartShift		2
#define kSibSoundTxStartMask		0xfffffffc	/* 31:2 */
#define kSibSoundTxStartShift		2

/***** SIB Telecom Receive Start Register Equates (PoseidonModule.sibTelRxStart) *****/
/***** SIB Telecom Transmit Start Register Equates (PoseidonModule.sibTelTxStart) *****/
#define kSibTelRxStartMask			0xfffffffc	/* 31:2 */
#define kSibTelRxStartShift			2
#define kSibTelTxStartMask			0xfffffffc	/* 31:2 */
#define kSibTelTxStartShift			2

/***** SIB Control Register Equates (PoseidonModule.sibControl) *****/
#define kSibIrqMask		 			0x80000000	/* 31 */
#define kSibSF1SoundMonoMask	 	0x10000000	/* 28 */
#define kSibSF1RightMonoMask	 	0x08000000	/* 27 */
#define kSibSClkDivMask		 		0x07000000	/* 26:24 */
#define kSibTel16BitMask	 		0x00800000	/* 23 */
#define kSibTelDivMask		 		0x007f0000	/* 22:16 */
#define kSibSound16BitMask	 		0x00008000	/* 15 */
#define kSibSoundDivMask	 		0x00007f00	/* 14:8 */
#define kSibSelectTelSF1Mask	 	0x00000080	/* 7 */
#define kSibSelectSoundSF1Mask		0x00000040	/* 6 */
#define kSibEnableTel	 			0x00000020	/* 5 */
#define kSibEnableSound				0x00000010	/* 4 */
#define kSibLoopModeMask			0x00000008	/* 3 */
#define kSibEnableSF1Mask			0x00000004	/* 2 */
#define kSibEnableSF0Mask			0x00000002	/* 1 */
#define kSibEnableSib				0x00000001	/* 0 */

/***** Values for kSibSclkDiv field *****/
#define kSibSClkDiv_12				0x7
#define kSibSClkDiv_10				0x6
#define kSibSClkDiv_8				0x5
#define kSibSClkDiv_6				0x4
#define kSibSClkDiv_5				0x3
#define kSibSClkDiv_4				0x2
#define kSibSClkDiv_3				0x1
#define kSibSClkDiv_2				0x0
#define kSibSClkDivShift			24

#define SIB_SCLK_DIV_TO_MASK(div)	(((div) & 0x7) << kSibSclkDivShift)

/***** Values for kSibTelDivMask and kSibSoundDivMask fields - SIBSCLK = 9.216 MHz *****/
#define kSibFsDiv9216_7200			0x27	/* 39, div-by-40 */
#define kSibFsDiv9216_8000			0x23	/* 35, div-by-36 */
#define kSibFsDiv9216_9600			0x1d	/* 29, div-by-30 */
/*SSP, 960827: the number for 9216_11025 should be 0x19 (25, div by 26). why 0x1b? */
/*#define kSibFsDiv9216_11025			0x1b	/* 27, div-by-28 */
#define kSibFsDiv9216_11025			0x19	/* 25, div-by-26 */
#define kSibFsDiv9216_19200			0x0e	/* 14, div-by-15 */
#define kSibFsDiv9216_22050			0x0c	/* 12, div-by-13 */
#define kSibFsDiv9216_24000			0x0b	/* 11, div-by-12 */
#define kSibFsDiv9216_72000			0x03	/* 3,  div-by-4, fastest test mode */

#define kSibFsDivMask				0x7f	
#define kSibTelDivShift				16
#define kSibSoundDivShift			8

#define SIB_TEL_DIV_TO_MASK(div)	(((div) & kSibFsDivMask) << kSibTelDivShift)
#define SIB_SOUND_DIV_TO_MASK(div)	(((div) & kSibFsDivMask) << kSibSoundDivShift)

/***** SIB Sound Hold Register Equates (PoseidonModule.sibSoundHold) *****/
/***** SIB Tele Hold Register Equates (PoseidonModule.sibTelHold) *****/

/***** SIB SF0 Aux Register Equates (PoseidonModule.sibSf0Aux) *****/
/***** SIB SF1 Aux Register Equates (PoseidonModule.sibSf1Aux) *****/

/***** SIB SF0 Status Register Equates (PoseidonModule.sibSf0Status) *****/
/***** SIB SF1 Status Register Equates (PoseidonModule.sibSf1Status) *****/

/***** SIB DMA Control Register Equates (PoseidonModule.sibDMA) *****/
#define kSibSoundDmaOnceMask		0x80000000	/* 31 */
#define kSibSoundDmaLoopMask		0x40000000	/* 30 */
#define kSibSoundDmaPtrMask			0x3ffc0000 	/* 29:18 */
#define kSibEnSoundRxDmaMask		0x00020000	/* 17 */
#define kSibEnSoundTxDmaMask		0x00010000	/* 16 */
#define kSibTelDmaOnceMask			0x00008000	/* 15 */
#define kSibTelDmaLoopMask			0x00004000	/* 14 */
#define kSibTelDmaPtrMask			0x00003ffc	/* 13:2 */
#define kSibEnTelRxDmaMask			0x00000002	/* 1 */
#define kSibEnTelTxDmaMask			0x00000001	/* 0 */

#define kSibSoundDmaPtrShift		18
#define kSibTelDmaPtrShift			2


/***** IR Module Equates *****/
/***** Register Equates (PoseidonModule.irControl1) *****/
#define kIRCarDetPinMask			0x01000000	/* 24 */
#define kIRBaudMask					0x00ff0000	/* 23:16 */
#define kIRTestMask					0x00000010	/* 4 */
#define kIRDTInvertMask				0x00000008	/* 3 */
#define kIREnRXPwrMask				0x00000004	/* 2 */
#define kIREnCarDetStateMask 		0x00000002	/* 1 */
#define kIREnConsumerMask			0x00000001	/* 0 */

#define kIRBaudShift				16

/***** Register Equates (PoseidonModule.irControl2) *****/
#define kIRPeriodMask				0xff000000	/* 31:24 */
#define kIROnTimeMask				0x00ff0000	/* 23:16 */
#define kIRDelayMask				0x0000ff00	/* 15:8 */
#define kIRWaitMask					0x000000ff	/* 7:0 */

#define kIRPeriodShift				24
#define kIROnTimeShift				16
#define kIRDelayShift				8
#define kIRWaitShift				0

/***** Register Equates (PoseidonModule.irHold) *****/
#define kIRTxHoldMask				0x0000ffff	/* 15:0 */

#define kIRTxHoldShift				0


/***** UART Module Equates *****/
/***** Register Equates (PoseidonModule.uartA.control1 and PoseidonModule.uartB.control1) *****/
#define kUartEnabledStatusMask		0x80000000	/* 31 */
#define kUartEmptyMask				0x40000000	/* 30 */
#define kUartPRxHoldFullMask		0x20000000	/* 29 */
#define kUartRxHoldFullMask			0x10000000	/* 28 */
#define kUartEnDmaRxMask			0x00008000	/* 15 */
#define kUartEnDmaTxMask			0x00004000	/* 14 */
#define kUartEnHaltOnBreakMask		0x00001000	/* 12 */
#define kUartEnDmaLoopMask			0x00000400	/* 10 */
#define kUartPulseLow3ClockMask		0x00000200	/* 9 */
#define kUartPulseLow6CLockMask		0x00000100	/* 8 */
#define kUartDTInvertMask			0x00000080	/* 7 */
#define kUartDisableTxdMask			0x00000040	/* 6 */
#define kUartTwoStopsMask			0x00000020	/* 5 */
#define kUartLoopbackMask			0x00000010	/* 4 */
#define kUart7BitCharMask			0x00000008	/* 3 */
#define kUartEvenParityMask			0x00000004	/* 2 */
#define kUartEnParityMask			0x00000002	/* 1 */
#define kUartEnUartMask				0x00000001	/* 0 */

/***** Register Equates (PoseidonModule.uartA.control2 and PoseidonModule.uartB.control2) *****/
#define kUartBaudRateMask			0x000003ff	/* 9:0 */

/***** Register Equates (PoseidonModule.uartA.dmaControl1 and PoseidonModule.uartB.dmaControl1) *****/
#define kUartDmaStartAddrMask		0xfffffffc	/* 31:2 */
#define kUartDmaStartAddrShift		2

/***** Register Equates (PoseidonModule.uartA.dmaControl2 and PoseidonModule.uartB.dmaControl2) *****/
#define kUartDmaLengthMask			0x0000ffff	/* 15:0 */

/***** Register Equates (PoseidonModule.uartA.dmacnt and PoseidonModule.uartB.dmacnt) *****/
#define kUartDmaCountMask			0x0000ffff	/* 15:0 */

/***** Register Equates (PoseidonModule.uartA.hold and PoseidonModule.uartB.hold) *****/
#define kUartBreakMask				0x00000100	/* 8 */
#define kUartTxDataMask				0x000000ff	/* 7:0 */



/***** MagicBus Module Equates *****/
/***** Register Equates (PoseidonModule.mbusControl1) *****/
#define kMbusEnabledStatusMask		0x80000000	/* 31 */
#define kMbusEmptyStatusMask		0x40000000	/* 30 */
#define kMbusIntStatusMask			0x20000000	/* 29 */
#define kMbusEnDmaRxMask			0x00010000	/* 16 */
#define kMbusEnDmaTxMask			0x00008000	/* 15 */
#define kMbusEnDmaLoopMask			0x00002000	/* 13 */
#define kMbusLoopbackMask			0x00001000	/* 12 */
#define kMbusRxClockPolMask			0x00000800	/* 11 */
#define kMbusTxDataIdleMask			0x00000400	/* 10 */
#define kMbusEnByteDlyMask			0x00000200	/* 9 */
#define kMbusEnWordDlyMask			0x00000100	/* 8 */
#define kMbusDetRxPhasePolMask		0x00000080	/* 7 */
#define kMbusDetRxClockPolMask		0x00000040	/* 6 */
#define kMbusTxPhasePolMask			0x00000020	/* 5 */
#define kMbusTxClockPolMask			0x00000010	/* 4 */
#define kMbusSlaveMask				0x00000008	/* 3 */
#define kMbusForceSlaveMask			0x00000004	/* 2 */
#define kMbusLongMask				0x00000002	/* 1 */
#define kMbusEnMask					0x00000001	/* 0 */

/***** Register Equates (PoseidonModule.mbusControl2) *****/
#define kMbusDelayValMask			0xff000000	/* 31:24 */
#define kMbusBaudRateMask			0x00ff0000	/* 23:16 */

#define kMbusDelayValShift			24
#define kMbusBaudRateShift			16

/***** Register Equates (PoseidonModule.mbusDMAStartAddr) *****/
#define kMbusDmaStartAddrMask		0xfffffffc	/* 31:2 */
#define kMbusDmaStartAddrShift		2

/***** Register Equates (PoseidonModule.mbusDMALength) *****/
#define kMbusDmaLengthMask			0x000ffffc	/* 19:2 */
#define kMbusDmaLengthShift			2

/***** Register Equates (PoseidonModule.mbusDmaCount) *****/
#define kMbusDmaCountMask			0x000ffffc	/* 19:2 */
#define kMbusDmaCountShift			2

/***** Register Equates (PoseidonModule.mbusCommand) *****/
/***** Register Equates (PoseidonModule.mbusData) *****/


/***** Interrupt Module Equates *****/

#define interrupt1Clear interrupt1
#define interrupt2Clear interrupt2
#define interrupt3Clear interrupt3
#define interrupt4Clear interrupt4
#define interrupt5Clear interrupt5

#define PoseidonModule_interrupt1Clear PoseidonModule_interrupt1
#define PoseidonModule_interrupt2Clear PoseidonModule_interrupt2
#define PoseidonModule_interrupt3Clear PoseidonModule_interrupt3
#define PoseidonModule_interrupt4Clear PoseidonModule_interrupt4
#define PoseidonModule_interrupt5Clear PoseidonModule_interrupt5


/***** Interrupt Status, Enable & Clear Register 1 Equates (PoseidonModule.interrupt1) *****/
#define kIntVideoFrameMask			0x80000000	/* 31 */
#define kIntVideoDFMask				0x40000000	/* 30 */
#define kIntChiDmaHalfMask			0x20000000	/* 29 */
#define kIntChiDmaEndMask			0x10000000	/* 28 */
#define kIntChiDmaPtrIncrMask		0x08000000	/* 27 */
#define kIntChiReceiveAMask			0x04000000	/* 26 */
#define kIntChiReceiveBMask			0x02000000	/* 25 */
#define kIntChiClkMask				0x01000000	/* 24 */
#define kIntChiErrMask				0x00800000	/* 23 */
#define kIntSoundDmaHalfMask		0x00400000	/* 22 */
#define kIntSoundDmaEndMask			0x00200000	/* 21 */
#define kIntTelDmaHalfMask			0x00100000	/* 20 */
#define kIntTelDmaEndMask			0x00080000	/* 19 */
#define kIntSoundDmaPtrIncMask		0x00040000	/* 18 */
#define kIntTelDmaPtrIncMask		0x00020000	/* 17 */
#define kIntSoundLClipMask			0x00010000	/* 16 */
#define kIntSoundRClipMask			0x00008000	/* 15 */
#define kIntSoundValPosMask			0x00004000	/* 14 */
#define kIntSoundValNegMask			0x00002000	/* 13 */
#define kIntTelValPosMask			0x00001000	/* 12 */
#define kIntTelValNegMask			0x00000800	/* 11 */
#define kIntSoundReceiveMask		0x00000400	/* 10 */
#define kIntTeleReceiveMask			0x00000200	/* 9 */
#define kIntSibSubFrame0Mask		0x00000100	/* 8 */
#define kIntSibSubFrame1Mask		0x00000080	/* 7 */
#define kIntSibIrqPosMask			0x00000040	/* 6 */
#define kIntSibIrqNegMask			0x00000020	/* 5 */

/***** Interrupt Status, Enable & Clear Register 2 Equates (PoseidonModule.interrupt2) *****/
#define kIntUartAReceiveMask		0x80000000	/* 31 */
#define kIntUartARxOverRunMask		0x40000000	/* 30 */
#define kIntUartAFrameErrMask		0x20000000	/* 29 */
#define kIntUartABreakMask			0x10000000	/* 28 */
#define kIntUartAParityErrMask		0x08000000	/* 27 */
#define kIntUartATransmitMask		0x04000000	/* 26 */
#define kIntUartATxOverRunMask		0x02000000	/* 25 */
#define kIntUartAEmptyMask			0x01000000	/* 24 */
#define kIntUartADmaEndMask			0x00800000	/* 23 */
#define kIntUartADmaHalfMask		0x00400000	/* 22 */
#define kIntUartBReceiveMask		0x00200000	/* 21 */
#define kIntUartBRxOverRunMask		0x00100000	/* 20 */
#define kIntUartBFrameErrMask		0x00080000	/* 19 */
#define kIntUartBBreakMask			0x00040000	/* 18 */
#define kIntUartBParityErrMask		0x00020000	/* 17 */
#define kIntUartBTransmitMask		0x00010000	/* 16 */
#define kIntUartBTxOverRunMask		0x00008000	/* 15 */
#define kIntUartBEmptyMask			0x00004000	/* 14 */
#define kIntUartBDmaEndMask			0x00002000	/* 13 */
#define kIntUartBDmaHalfMask		0x00001000	/* 12 */
#define kIntMbusTransmitMask		0x00000800	/* 11 */
#define kIntMbusTxErrMask			0x00000400	/* 10 */
#define kIntMbusEmptyMask			0x00000200	/* 9 */
#define kIntMbusReceiveMask			0x00000100	/* 8 */
#define kIntMbusRxErrMask			0x00000080	/* 7 */
#define kIntMbusCmdDetectMask		0x00000040	/* 6 */
#define kIntMbusDmaEndMask			0x00000020	/* 5 */
#define kIntMbusDmaHalfMask			0x00000010	/* 4 */
#define kIntMbusPosMask				0x00000008	/* 3 */
#define kIntMbusNegMask				0x00000004	/* 2 */

/***** Interrupt Status, Enable & Clear Register 3 Equates (PoseidonModule.interrupt3) *****/
#define kIntMfio31PosMask			0x80000000	/* 31 */
#define kIntMfio30PosMask			0x40000000	/* 30 */
#define kIntMfio29PosMask			0x20000000	/* 29 */
#define kIntMfio28PosMask			0x10000000	/* 28 */
#define kIntMfio27PosMask			0x08000000	/* 27 */
#define kIntMfio26PosMask			0x04000000	/* 26 */
#define kIntMfio25PosMask			0x02000000	/* 25 */
#define kIntMfio24PosMask			0x01000000	/* 24 */
#define kIntMfio23PosMask			0x00800000	/* 23 */
#define kIntMfio22PosMask			0x00400000	/* 22 */
#define kIntMfio21PosMask			0x00200000	/* 21 */
#define kIntMfio20PosMask			0x00100000	/* 20 */
#define kIntMfio19PosMask			0x00080000	/* 19 */
#define kIntMfio18PosMask			0x00040000	/* 18 */
#define kIntMfio17PosMask			0x00020000	/* 17 */
#define kIntMfio16PosMask			0x00010000	/* 16 */
#define kIntMfio15PosMask			0x00008000	/* 15 */
#define kIntMfio14PosMask			0x00004000	/* 14 */
#define kIntMfio13PosMask			0x00002000	/* 13 */
#define kIntMfio12PosMask			0x00001000	/* 12 */
#define kIntMfio11PosMask			0x00000800	/* 11 */
#define kIntMfio10PosMask			0x00000400	/* 10 */
#define kIntMfio9PosMask			0x00000200	/* 9 */
#define kIntMfio8PosMask			0x00000100	/* 8 */
#define kIntMfio7PosMask			0x00000080	/* 7 */
#define kIntMfio6PosMask			0x00000040	/* 6 */
#define kIntMfio5PosMask			0x00000020	/* 5 */
#define kIntMfio4PosMask			0x00000010	/* 4 */
#define kIntMfio3PosMask			0x00000008	/* 3 */
#define kIntMfio2PosMask			0x00000004	/* 2 */
#define kIntMfio1PosMask			0x00000002	/* 1 */
#define kIntMfio0PosMask			0x00000001	/* 0 */

/***** Interrupt Status, Enable & Clear Register 4 Equates (PoseidonModule.interrupt4) *****/
#define kIntMfio31NegMask			0x80000000	/* 31 */
#define kIntMfio30NegMask			0x40000000	/* 30 */
#define kIntMfio29NegMask			0x20000000	/* 29 */
#define kIntMfio28NegMask			0x10000000	/* 28 */
#define kIntMfio27NegMask			0x08000000	/* 27 */
#define kIntMfio26NegMask			0x04000000	/* 26 */
#define kIntMfio25NegMask			0x02000000	/* 25 */
#define kIntMfio24NegMask			0x01000000	/* 24 */
#define kIntMfio23NegMask			0x00800000	/* 23 */
#define kIntMfio22NegMask			0x00400000	/* 22 */
#define kIntMfio21NegMask			0x00200000	/* 21 */
#define kIntMfio20NegMask			0x00100000	/* 20 */
#define kIntMfio19NegMask			0x00080000	/* 19 */
#define kIntMfio18NegMask			0x00040000	/* 18 */
#define kIntMfio17NegMask			0x00020000	/* 17 */
#define kIntMfio16NegMask			0x00010000	/* 16 */
#define kIntMfio15NegMask			0x00008000	/* 15 */
#define kIntMfio14NegMask			0x00004000	/* 14 */
#define kIntMfio13NegMask			0x00002000	/* 13 */
#define kIntMfio12NegMask			0x00001000	/* 12 */
#define kIntMfio11NegMask			0x00000800	/* 11 */
#define kIntMfio10NegMask			0x00000400	/* 10 */
#define kIntMfio9NegMask			0x00000200	/* 9 */
#define kIntMfio8NegMask			0x00000100	/* 8 */
#define kIntMfio7NegMask			0x00000080	/* 7 */
#define kIntMfio6NegMask			0x00000040	/* 6 */
#define kIntMfio5NegMask			0x00000020	/* 5 */
#define kIntMfio4NegMask			0x00000010	/* 4 */
#define kIntMfio3NegMask			0x00000008	/* 3 */
#define kIntMfio2NegMask			0x00000004	/* 2 */
#define kIntMfio1NegMask			0x00000002	/* 1 */
#define kIntMfio0NegMask			0x00000001	/* 0 */

/***** Interrupt Status, Enable & Clear Register 5 Equates (PoseidonModule.interrupt5) *****/
#define kIntRTCRolloverMask			0x80000000	/* 31 */
#define kIntRTCAlarmMask			0x40000000	/* 30 */
#define kIntPeriodicTimerMask		0x20000000	/* 29 */
#define kIntStopTimerMask			0x10000000	/* 28 */
#define kIntPwrIntPosMask			0x08000000	/* 27 */
#define kIntPwrIntNegMask			0x04000000	/* 26 */
#define kIntPwrOKPosMask			0x02000000	/* 25 */
#define kIntPwrOKNegMask			0x01000000	/* 24 */
#define kIntOnButPosMask			0x00800000	/* 23 */
#define kIntOnButNegMask			0x00400000	/* 22 */
#define kIntSpiTransmitMask			0x00200000	/* 21 */
#define kIntSpiErrMask				0x00100000	/* 20 */
#define kIntSpiReceiveMask			0x00080000	/* 19 */
#define kIntSpiEmptyMask			0x00040000	/* 18 */
#define kIntIrConsumerMask			0x00020000	/* 17 */
#define kIntCarDetPinMask			0x00010000	/* 16 */
#define kIntCarDetPosMask			0x00008000	/* 15 */
#define kIntCarDetNegMask			0x00004000	/* 14 */
#define kIntIOInt6PosMask			0x00002000	/* 13 */
#define kIntIOInt5PosMask			0x00001000	/* 12 */
#define kIntIOInt4PosMask			0x00000800	/* 11 */
#define kIntIOInt3PosMask			0x00000400	/* 10 */
#define kIntIOInt2PosMask			0x00000200	/* 9 */
#define kIntIOInt1PosMask			0x00000100	/* 8 */
#define kIntIOInt0PosMask			0x00000080	/* 7 */
#define kIntIOInt6NegMask			0x00000040	/* 6 */
#define kIntIOInt5NegMask			0x00000020	/* 5 */
#define kIntIOInt4NegMask			0x00000010	/* 4 */
#define kIntIOInt3NegMask			0x00000008	/* 3 */
#define kIntIOInt2NegMask			0x00000004	/* 2 */
#define kIntIOInt1NegMask			0x00000002	/* 1 */
#define kIntIOInt0NegMask			0x00000001	/* 0 */

#define kIntClearAllMask			0xffffffff


/***** Interrupt Status, Enable & Clear Register 6 Equates (PoseidonModule.interrupt6) *****/
#define kIntIrqHighPrioMask			0x80000000	/* 31 */
#define kIntIrqLowPrioMask			0x40000000	/* 30 */
#define kIntHighPrioVectMask		0x0000003c	/* 5:2 */

#define kIntHighPrioVectShift		2

#define HIGH_INT_MASK_TO_VECT(mask)	(((mask) >> kIntHighPrioVectShift) & 0xf)

/***** Interrupt Enable Register 6 Equates (PoseidonModule.interrupt6Enable) *****/
#define kIntGlobalEnMask			0x00040000	/* 18 */
#define kIntPriorityMask			0x0000ffff	/* 15:0 */

#define kIntEnHighPwrOkMask			0x00008000	/* 15 */
#define kIntEnHighAlarmMask			0x00004000	/* 14 */
#define kIntEnHighPerTimerMask		0x00002000	/* 13 */
#define kIntEnHighMbusMask			0x00001000	/* 12 */
#define kIntEnHighUartARxMask		0x00000800	/* 11 */
#define kIntEnHighUartBRxMask		0x00000400	/* 10 */
#define kIntEnHighMccsPosMask		0x00000200	/* 9 */
#define kIntEnHighMcdetPosMask		0x00000100	/* 8 */
#define kIntEnHighMccsNegMask		0x00000080	/* 7 */
#define kIntEnHighMcdetNegMask		0x00000040	/* 6 */
#define kIntEnHighMbusDmaFullMask	0x00000020	/* 5 */
#define kIntEnHighSndDmaCountMask	0x00000010	/* 4 */
#define kIntEnHighTelDmaCountMask	0x00000008	/* 3 */
#define kIntEnHighChiDmaCountMask	0x00000004	/* 2 */
#define kIntEnHighIo0Mask			0x00000002	/* 1 */


/***** Timer Module Equates *****/
/***** Register Equates (PoseidonModule.rtcHigh) *****/
#define kTimerRTCHighBitsMask		0x000000ff

/***** Register Equates (PoseidonModule.alarmHigh) *****/
#define kTimerAlarmHighBitsMask		0x000000ff

/***** Register Equates (PoseidonModule.alarmLow) *****/
#define kTimerAlarmLowBitsMask		0xffffffff

/***** Register Equates (PoseidonModule.timerControl) *****/
#define kTimerFreezePre				0x00000080	/* 7 */
#define kTimerFreezeRtc				0x00000040	/* 6 */
#define kTimerFreezePerTimer		0x00000020	/* 5 */
#define kTimerEnPerTimer			0x00000010	/* 4 */
#define kTimerClearRtc				0x00000008	/* 3 */
#define kTimerTestC8Ms				0x00000004	/* 2 */
#define kTimerRtcEnTestClk			0x00000002	/* 1 */
#define kTimerEnRtcTest				0x00000001	/* 0 */

#define kTimerControlReadMask		0x000000ff

/***** Register Equates (PoseidonModule.perTimer) *****/
#define kTimerPerCntMask			0xffff0000  /* 31:16 */
#define kTimerPerLoadMask			0x0000ffff  /* 15:0 */

#define kTimerPerCntShift			16
#define kTimerPerLoadShift			0


/***** SPI Module Equates *****/
/***** SPI Control Register Equates (PoseidonModule.spiControl) *****/
#define kSpiOnStatusMask				0x00020000	/* 17 */
#define kSpiEmptyStatusMask				0x00010000	/* 16 */
#define kSpiInterCharacterDelayMask		0x0000f000  /* 15:12 */
#define kSpiBaudRateMask				0x00000f00  /* 11:8 */
#define kSpiTransmitOnRisingEdgeMask	0x00000020	/* 5 */
#define kSpiClockIdleHighMask			0x00000010	/* 4 */
#define kSpi16BitDataMask				0x00000004	/* 2 */
#define kSpiShiftDataLsbFirstMask		0x00000002	/* 1 */
#define kSpiEnableMask					0x00000001	/* 0 */

#define kSpiInterCharacterDelayShift	12
#define kSpiBaudRateShift				8

#define kSpiDefaultBaud					3

#define kSpiControlWriteMask	( \
	kSpiInterCharacterDelayMask | \
	kSpiBaudRateMask | \
	kSpiTransmitOnRisingEdgeMask | \
	kSpiClockIdleHighMask | \
	kSpi16BitDataMask | \
	kSpiShiftDataLsbFirstMask | \
	kSpiEnableMask)


/***** SPI Data Register Equates (PoseidonModule.spi) *****/
#define kSpiTxDataHoldMask			0x0000ffff	/* 15:0 */
#define kSpiRxDataHoldMask			0x0000ffff	/* 15:0 */


/***** IO Module Equates *****/
/***** Register Equates (PoseidonModule.ioControl) *****/
#define kIODebounceSelect6Mask		0x40000000	/* 30 */
#define kIODebounceSelect5Mask		0x20000000	/* 29 */
#define kIODebounceSelect4Mask		0x10000000	/* 28 */
#define kIODebounceSelect3Mask		0x08000000	/* 27 */
#define kIODebounceSelect2Mask		0x04000000	/* 26 */
#define kIODebounceSelect1Mask		0x02000000	/* 25 */
#define kIODebounceSelect0Mask		0x01000000	/* 24 */
#define kIOOutputSelect6Mask		0x00400000	/* 22 */
#define kIOOutputSelect5Mask		0x00200000	/* 21 */
#define kIOOutputSelect4Mask		0x00100000	/* 20 */
#define kIOOutputSelect3Mask		0x00080000	/* 19 */
#define kIOOutputSelect2Mask		0x00040000	/* 18 */
#define kIOOutputSelect1Mask		0x00020000	/* 17 */
#define kIOOutputSelect0Mask		0x00010000	/* 16 */
#define kIODataOut6Mask				0x00004000	/* 14 */
#define kIODataOut5Mask				0x00002000	/* 13 */
#define kIODataOut4Mask				0x00001000	/* 12 */
#define kIODataOut3Mask				0x00000800	/* 11 */
#define kIODataOut2Mask				0x00000400	/* 10 */
#define kIODataOut1Mask				0x00000200	/* 9 */
#define kIODataOut0Mask				0x00000100	/* 8 */
#define kIODataIn6Mask				0x00000040	/* 6 */
#define kIODataIn5Mask				0x00000020	/* 5 */
#define kIODataIn4Mask				0x00000010	/* 4 */
#define kIODataIn3Mask				0x00000008	/* 3 */
#define kIODataIn2Mask				0x00000004	/* 2 */
#define kIODataIn1Mask				0x00000002	/* 1 */
#define kIODataIn0Mask				0x00000001	/* 0 */

#define kIOBit6Mask					0x00000040	/* 6 */
#define kIOBit5Mask					0x00000020	/* 5 */
#define kIOBit4Mask					0x00000010	/* 4 */
#define kIOBit3Mask					0x00000008	/* 3 */
#define kIOBit2Mask					0x00000004	/* 2 */
#define kIOBit1Mask					0x00000002	/* 1 */
#define kIOBit0Mask					0x00000001	/* 0 */

#define kIODebounceSelectShift		24
#define kIOOutputSelectShift		16
#define kIODataOutShift				8
#define kIODataInShift				0

#define IO_DATA_OUT_PIN_TO_MASK(pin)	(1 << (kIODataOutShift + (pin)))
#define IO_DATA_IN_PIN_TO_MASK(pin)		(1 << (kIODataInShift + (pin)))


/***** Register Equates (PoseidonModule.mfioDataOutput) *****/
#define kIOMfioDataOut31Mask		0x80000000	/* 31 */
#define kIOMfioDataOut30Mask		0x40000000	/* 30 */
#define kIOMfioDataOut29Mask		0x20000000	/* 29 */
#define kIOMfioDataOut28Mask		0x10000000	/* 28 */
#define kIOMfioDataOut27Mask		0x08000000	/* 27 */
#define kIOMfioDataOut26Mask		0x04000000	/* 26 */
#define kIOMfioDataOut25Mask		0x02000000	/* 25 */
#define kIOMfioDataOut24Mask		0x01000000	/* 24 */
#define kIOMfioDataOut23Mask		0x00800000	/* 23 */
#define kIOMfioDataOut22Mask		0x00400000	/* 22 */
#define kIOMfioDataOut21Mask		0x00200000	/* 21 */
#define kIOMfioDataOut20Mask		0x00100000	/* 20 */
#define kIOMfioDataOut19Mask		0x00080000	/* 19 */
#define kIOMfioDataOut18Mask		0x00040000	/* 18 */
#define kIOMfioDataOut17Mask		0x00020000	/* 17 */
#define kIOMfioDataOut16Mask		0x00010000	/* 16 */
#define kIOMfioDataOut15Mask		0x00008000	/* 15 */
#define kIOMfioDataOut14Mask		0x00004000	/* 14 */
#define kIOMfioDataOut13Mask		0x00002000	/* 13 */
#define kIOMfioDataOut12Mask		0x00001000	/* 12 */
#define kIOMfioDataOut11Mask		0x00000800	/* 11 */
#define kIOMfioDataOut10Mask		0x00000400	/* 10 */
#define kIOMfioDataOut9Mask			0x00000200	/* 9 */
#define kIOMfioDataOut8Mask			0x00000100	/* 8 */
#define kIOMfioDataOut7Mask			0x00000080	/* 7 */
#define kIOMfioDataOut6Mask			0x00000040	/* 6 */
#define kIOMfioDataOut5Mask			0x00000020	/* 5 */
#define kIOMfioDataOut4Mask			0x00000010	/* 4 */
#define kIOMfioDataOut3Mask			0x00000008	/* 3 */
#define kIOMfioDataOut2Mask			0x00000004	/* 2 */
#define kIOMfioDataOut1Mask			0x00000002	/* 1 */
#define kIOMfioDataOut0Mask			0x00000001	/* 0 */

#define MFIO_DATA_OUT_PIN_TO_MASK(pin)	(1 << (pin))

/***** Register Equates (PoseidonModule.mfioDirection) *****/
#define kIOMfioOutputSelect31Mask	0x80000000	/* 31 */
#define kIOMfioOutputSelect30Mask	0x40000000	/* 30 */
#define kIOMfioOutputSelect29Mask	0x20000000	/* 29 */
#define kIOMfioOutputSelect28Mask	0x10000000	/* 28 */
#define kIOMfioOutputSelect27Mask	0x08000000	/* 27 */
#define kIOMfioOutputSelect26Mask	0x04000000	/* 26 */
#define kIOMfioOutputSelect25Mask	0x02000000	/* 25 */
#define kIOMfioOutputSelect24Mask	0x01000000	/* 24 */
#define kIOMfioOutputSelect23Mask	0x00800000	/* 23 */
#define kIOMfioOutputSelect22Mask	0x00400000	/* 22 */
#define kIOMfioOutputSelect21Mask	0x00200000	/* 21 */
#define kIOMfioOutputSelect20Mask	0x00100000	/* 20 */
#define kIOMfioOutputSelect19Mask	0x00080000	/* 19 */
#define kIOMfioOutputSelect18Mask	0x00040000	/* 18 */
#define kIOMfioOutputSelect17Mask	0x00020000	/* 17 */
#define kIOMfioOutputSelect16Mask	0x00010000	/* 16 */
#define kIOMfioOutputSelect15Mask	0x00008000	/* 15 */
#define kIOMfioOutputSelect14Mask	0x00004000	/* 14 */
#define kIOMfioOutputSelect13Mask	0x00002000	/* 13 */
#define kIOMfioOutputSelect12Mask	0x00001000	/* 12 */
#define kIOMfioOutputSelect11Mask	0x00000800	/* 11 */
#define kIOMfioOutputSelect10Mask	0x00000400	/* 10 */
#define kIOMfioOutputSelect9Mask	0x00000200	/* 9 */
#define kIOMfioOutputSelect8Mask	0x00000100	/* 8 */
#define kIOMfioOutputSelect7Mask	0x00000080	/* 7 */
#define kIOMfioOutputSelect6Mask	0x00000040	/* 6 */
#define kIOMfioOutputSelect5Mask	0x00000020	/* 5 */
#define kIOMfioOutputSelect4Mask	0x00000010	/* 4 */
#define kIOMfioOutputSelect3Mask	0x00000008	/* 3 */
#define kIOMfioOutputSelect2Mask	0x00000004	/* 2 */
#define kIOMfioOutputSelect1Mask	0x00000002	/* 1 */
#define kIOMfioOutputSelect0Mask	0x00000001	/* 0 */

#define MFIO_OUTPUT_SELECT_PIN_TO_MASK(pin)	(1 << (pin))

/***** Register Equates (PoseidonModule.mfioDataInput) *****/
#define kIOMfioDataIn31Mask			0x80000000	/* 31 */
#define kIOMfioDataIn30Mask			0x40000000	/* 30 */
#define kIOMfioDataIn29Mask			0x20000000	/* 29 */
#define kIOMfioDataIn28Mask			0x10000000	/* 28 */
#define kIOMfioDataIn27Mask			0x08000000	/* 27 */
#define kIOMfioDataIn26Mask			0x04000000	/* 26 */
#define kIOMfioDataIn25Mask			0x02000000	/* 25 */
#define kIOMfioDataIn24Mask			0x01000000	/* 24 */
#define kIOMfioDataIn23Mask			0x00800000	/* 23 */
#define kIOMfioDataIn22Mask			0x00400000	/* 22 */
#define kIOMfioDataIn21Mask			0x00200000	/* 21 */
#define kIOMfioDataIn20Mask			0x00100000	/* 20 */
#define kIOMfioDataIn19Mask			0x00080000	/* 19 */
#define kIOMfioDataIn18Mask			0x00040000	/* 18 */
#define kIOMfioDataIn17Mask			0x00020000	/* 17 */
#define kIOMfioDataIn16Mask			0x00010000	/* 16 */
#define kIOMfioDataIn15Mask			0x00008000	/* 15 */
#define kIOMfioDataIn14Mask			0x00004000	/* 14 */
#define kIOMfioDataIn13Mask			0x00002000	/* 13 */
#define kIOMfioDataIn12Mask			0x00001000	/* 12 */
#define kIOMfioDataIn11Mask			0x00000800	/* 11 */
#define kIOMfioDataIn10Mask			0x00000400	/* 10 */
#define kIOMfioDataIn9Mask			0x00000200	/* 9 */
#define kIOMfioDataIn8Mask			0x00000100	/* 8 */
#define kIOMfioDataIn7Mask			0x00000080	/* 7 */
#define kIOMfioDataIn6Mask			0x00000040	/* 6 */
#define kIOMfioDataIn5Mask			0x00000020	/* 5 */
#define kIOMfioDataIn4Mask			0x00000010	/* 4 */
#define kIOMfioDataIn3Mask			0x00000008	/* 3 */
#define kIOMfioDataIn2Mask			0x00000004	/* 2 */
#define kIOMfioDataIn1Mask			0x00000002	/* 1 */
#define kIOMfioDataIn0Mask			0x00000001	/* 0 */

#define MFIO_DATA_IN_PIN_TO_MASK(pin)	(1 << (pin))

/***** Register Equates (PoseidonModule.mfioSelect) *****/
#define kIOMfioSelect31Mask			0x80000000	/* 31 */
#define kIOMfioSelect30Mask			0x40000000	/* 30 */
#define kIOMfioSelect29Mask			0x20000000	/* 29 */
#define kIOMfioSelect28Mask			0x10000000	/* 28 */
#define kIOMfioSelect27Mask			0x08000000	/* 27 */
#define kIOMfioSelect26Mask			0x04000000	/* 26 */
#define kIOMfioSelect25Mask			0x02000000	/* 25 */
#define kIOMfioSelect24Mask			0x01000000	/* 24 */
#define kIOMfioSelect23Mask			0x00800000	/* 23 */
#define kIOMfioSelect22Mask			0x00400000	/* 22 */
#define kIOMfioSelect21Mask			0x00200000	/* 21 */
#define kIOMfioSelect20Mask			0x00100000	/* 20 */
#define kIOMfioSelect19Mask			0x00080000	/* 19 */
#define kIOMfioSelect18Mask			0x00040000	/* 18 */
#define kIOMfioSelect17Mask			0x00020000	/* 17 */
#define kIOMfioSelect16Mask			0x00010000	/* 16 */
#define kIOMfioSelect15Mask			0x00008000	/* 15 */
#define kIOMfioSelect14Mask			0x00004000	/* 14 */
#define kIOMfioSelect13Mask			0x00002000	/* 13 */
#define kIOMfioSelect12Mask			0x00001000	/* 12 */
#define kIOMfioSelect11Mask			0x00000800	/* 11 */
#define kIOMfioSelect10Mask			0x00000400	/* 10 */
#define kIOMfioSelect9Mask			0x00000200	/* 9 */
#define kIOMfioSelect8Mask			0x00000100	/* 8 */
#define kIOMfioSelect7Mask			0x00000080	/* 7 */
#define kIOMfioSelect6Mask			0x00000040	/* 6 */
#define kIOMfioSelect5Mask			0x00000020	/* 5 */
#define kIOMfioSelect4Mask			0x00000010	/* 4 */
#define kIOMfioSelect3Mask			0x00000008	/* 3 */
#define kIOMfioSelect2Mask			0x00000004	/* 2 */
#define kIOMfioSelect1Mask			0x00000002	/* 1 */
#define kIOMfioSelect0Mask			0x00000001	/* 0 */

#define MFIO_SELECT_PIN_TO_MASK(pin)	(1 << (pin))

/* 
 * MFIO Standard function masks used for: (PoseidonModule.mfioDataOutput, PoseidonModule.mfioDirection,
 * PoseidonModule.mfioDataInput, PoseidonModule.mfioSelect, PoseidonModule.mfioPowerDown)
 */
#define kIOMfioChiFrameSyncMask			kIOMfioSelect31Mask
#define kIOMfioChiClockMask				kIOMfioSelect30Mask
#define kIOMfioChiDataOutMask			kIOMfioSelect29Mask
#define kIOMfioChiDataInMask			kIOMfioSelect28Mask			
#define kIOMfioBusRequestMask			kIOMfioSelect27Mask			
#define kIOMfioBusGrantMask				kIOMfioSelect26Mask			
#define kIOMfioBuffered32KhzClockMask	kIOMfioSelect25Mask			
#define kIOMfioUartATransmitDataMask	kIOMfioSelect24Mask			
#define kIOMfioUartAReceiveDataMask		kIOMfioSelect23Mask			
#define kIOMfioChipSelect1Mask			kIOMfioSelect22Mask			
#define kIOMfioChipSelect2Mask			kIOMfioSelect21Mask			
#define kIOMfioChipSelect3Mask			kIOMfioSelect20Mask			
#define kIOMfioMagicCardChipSelect0Mask kIOMfioSelect19Mask			
#define kIOMfioMagicCardChipSelect1Mask kIOMfioSelect18Mask			
#define kIOMfioMagicCardChipSelect2Mask kIOMfioSelect17Mask			
#define kIOMfioMagicCardChipSelect3Mask kIOMfioSelect16Mask			
#define kIOMfioSpiClockMask				kIOMfioSelect15Mask			
#define kIOMfioSpiDataOutMask			kIOMfioSelect14Mask			
#define kIOMfioSpiDataInMask			kIOMfioSelect13Mask			
#define kIOMfioSibMClockMask			kIOMfioSelect12Mask			
#define kIOMfioCardRegMask				kIOMfioSelect11Mask			
#define kIOMfioCardIoWriteMask			kIOMfioSelect10Mask			
#define kIOMfioCardIoReadMask			kIOMfioSelect9Mask			
#define kIOMfioCard1ChipSelectLowMask	kIOMfioSelect8Mask			
#define kIOMfioCard1ChipSelectHighMask	kIOMfioSelect7Mask			
#define kIOMfioCard2ChipSelectLowMask	kIOMfioSelect6Mask			
#define kIOMfioCard2ChipSelectHighMask	kIOMfioSelect5Mask			
#define kIOMfioCard1WaitMask			kIOMfioSelect4Mask			
#define kIOMfioCard2WaitMask			kIOMfioSelect3Mask			
#define kIOMfioCardDirectionMask		kIOMfioSelect2Mask

#define kIOMfioCard1Disable				(kIOMfioCard1ChipSelectLowMask | kIOMfioCard1ChipSelectHighMask | kIOMfioCard1WaitMask)
#define kIOMfioCard2Disable				(kIOMfioCard2ChipSelectLowMask | kIOMfioCard2ChipSelectHighMask | kIOMfioCard2WaitMask)				
#define kIOMfioCardDisable				(kIOMfioCardRegMask | kIOMfioCardIoWriteMask | kIOMfioCardIoReadMask | kIOMfioCardDirectionMask)
#define kIOMfioGeneralDisable			kIOMfioCardDisable			


/***** Register Equates (PoseidonModule.ioPowerDown) *****/
#define kIOPowerDown6Mask			0x00000040	/* 6 */
#define kIOPowerDown5Mask			0x00000020	/* 5 */
#define kIOPowerDown4Mask			0x00000010	/* 4 */
#define kIOPowerDown3Mask			0x00000008	/* 3 */
#define kIOPowerDown2Mask			0x00000004	/* 2 */
#define kIOPowerDown1Mask			0x00000002	/* 1 */
#define kIOPowerDown0Mask			0x00000001	/* 0 */

#define IO_POWER_DOWN_PIN_TO_MASK(pin)	(1 << (pin))

/***** Register Equates (PoseidonModule.mfioPowerDown) *****/
#define kIOMfioPowerDown31Mask		0x80000000	/* 31 */
#define kIOMfioPowerDown30Mask		0x40000000	/* 30 */
#define kIOMfioPowerDown29Mask		0x20000000	/* 29 */
#define kIOMfioPowerDown28Mask		0x10000000	/* 28 */
#define kIOMfioPowerDown27Mask		0x08000000	/* 27 */
#define kIOMfioPowerDown26Mask		0x04000000	/* 26 */
#define kIOMfioPowerDown25Mask		0x02000000	/* 25 */
#define kIOMfioPowerDown24Mask		0x01000000	/* 24 */
#define kIOMfioPowerDown23Mask		0x00800000	/* 23 */
#define kIOMfioPowerDown22Mask		0x00400000	/* 22 */
#define kIOMfioPowerDown21Mask		0x00200000	/* 21 */
#define kIOMfioPowerDown20Mask		0x00100000	/* 20 */
#define kIOMfioPowerDown19Mask		0x00080000	/* 19 */
#define kIOMfioPowerDown18Mask		0x00040000	/* 18 */
#define kIOMfioPowerDown17Mask		0x00020000	/* 17 */
#define kIOMfioPowerDown16Mask		0x00010000	/* 16 */
#define kIOMfioPowerDown15Mask		0x00008000	/* 15 */
#define kIOMfioPowerDown14Mask		0x00004000	/* 14 */
#define kIOMfioPowerDown13Mask		0x00002000	/* 13 */
#define kIOMfioPowerDown12Mask		0x00001000	/* 12 */
#define kIOMfioPowerDown11Mask		0x00000800	/* 11 */
#define kIOMfioPowerDown10Mask		0x00000400	/* 10 */
#define kIOMfioPowerDown9Mask		0x00000200	/* 9 */
#define kIOMfioPowerDown8Mask		0x00000100	/* 8 */
#define kIOMfioPowerDown7Mask		0x00000080	/* 7 */
#define kIOMfioPowerDown6Mask		0x00000040	/* 6 */
#define kIOMfioPowerDown5Mask		0x00000020	/* 5 */
#define kIOMfioPowerDown4Mask		0x00000010	/* 4 */
#define kIOMfioPowerDown3Mask		0x00000008	/* 3 */
#define kIOMfioPowerDown2Mask		0x00000004	/* 2 */
#define kIOMfioPowerDown1Mask		0x00000002	/* 1 */
#define kIOMfioPowerDown0Mask		0x00000001	/* 0 */

#define MFIO_POWER_DOWN_PIN_TO_MASK(pin)	(1 << (pin))


/***** Clock Control Equates *****/
/***** Clock Control Register Equates (PoseidonModule.masterClock) *****/
#define kClockChiClkDivMask			0xff000000	/* 31:24 */
#define kClockChiMClkSelectMask		0x00200000	/* 21 */
#define kClockChiClkDirectionMask	0x00100000	/* 20 */
#define kClockEnChiMClkMask			0x00080000	/* 19 */
#define kClockEnVideoClkMask		0x00040000	/* 18 */
#define kClockEnMbusClkMask			0x00020000	/* 17 */
#define kClockEnSpiClkMask			0x00010000	/* 16 */
#define kClockEnTimerClkMask		0x00008000	/* 15 */
#define kClockEnFastTimerClkMask	0x00004000	/* 14 */
#define kClockSibMClkDirectionMask	0x00002000	/* 13 */
#define kClockEnSibMClkMask			0x00000800	/* 11 */
#define kClockSibMClkDivMask		0x00000700	/* 10:8 */
#define kClockCserSelectMask		0x00000080	/* 7 */
#define kClockCserDivMask			0x00000070	/* 6:4 */
#define kClockEnCserClkMask			0x00000008	/* 3 */
#define kClockEnIrClkMask			0x00000004	/* 2 */
#define kClockEnUartAClkMask		0x00000002	/* 1 */
#define kClockEnUartBClkMask		0x00000001	/* 0 */

/***** Values for kClockChiClkDivMask *****/
#define kClockChiClockDivShift		24

/***** Values for kClockSibMClkDivMask *****/
#define kClockSibMClkDivBy8			0x00000600
#define kClockSibMClkDivBy7			0x00000500
#define kClockSibMClkDivBy6			0x00000400
#define kClockSibMClkDivBy5			0x00000300
#define kClockSibMClkDivBy4			0x00000200
#define kClockSibMClkDivBy3			0x00000100
#define kClockSibMClkDivBy2			0x00000000
#define kClockSibMClockDivShift		8

/***** Values for kClockCserDivMask *****/
#define kClockCserDivBy8			0x00000060
#define kClockCserDivBy7			0x00000050
#define kClockCserDivBy6			0x00000040
#define kClockCserDivBy5			0x00000030
#define kClockCserDivBy4			0x00000020
#define kClockCserDivBy3			0x00000010
#define kClockCserDivBy2			0x00000000
#define kClockCserDivShift			4


/***** Power Module Equates *****/
/***** Power Module Control Equates (PoseidonModule.powerControl) *****/
#define kPowerOnButtonStatusMask			0x80000000	/* 31 */
#define kPowerInterruptStatusMask			0x40000000	/* 30 */
#define kPowerOkStatusMask					0x20000000	/* 29 */
#define kPowerStopTimerValueMask			0x0000f000	/* 15:12 */
#define kPowerEnableStopTimerMask			0x00000800	/* 11 */
#define kPowerEnableForceShutdownMask		0x00000400	/* 10 */
#define kPowerForceShutdownMask				0x00000200	/* 9 */
#define kPowerForceShutdownOccurredMask		0x00000100	/* 8 */
#define kPowerSelectShortWakeUpDebounceMask	0x00000080	/* 7 */
#define kPowerDisableWakeUpDebounceMask		0x00000020	/* 5 */
#define kPowerStopCpuMask					0x00000010	/* 4 */
#define kPowerEnableOnButtonDebounceMask	0x00000008	/* 3 */
#define kPowerColdStartMask					0x00000004	/* 2 */
#define kPowerCsMask						0x00000002	/* 1 */
#define kPowerVccOnMask						0x00000001	/* 0 */

#define kPowerStopTimerValueShift			12

#define kPowerWriteMask	( \
	kPowerStopTimerValueMask | \
	kPowerEnableStopTimerMask | \
	kPowerEnableForceShutdownMask | \
	kPowerForceShutdownMask | \
	kPowerForceShutdownOccurredMask | \
	kPowerSelectShortWakeUpDebounceMask | \
	kPowerDisableWakeUpDebounceMask | \
	kPowerStopCpuMask | \
	kPowerEnableOnButtonDebounceMask | \
	kPowerColdStartMask | \
	kPowerCsMask | \
	kPowerVccOnMask)


/***** CHI Module Equates *****/
/***** Register Equates (PoseidonModule.chiControl) *****/
#define kChiFsOutputSelectMask		0x08000000	/* 27 */
#define kChiFsWidthMask				0x06000000	/* 26:25 */
#define kChiNumChanTimeslotsMask	0x01f00000	/* 24:20 */
#define kChiTxBitOffsetMask			0x000f0000	/* 19:16 */
#define kChiRxBitOffsetMask			0x0000f000	/* 15:12 */
#define kChiTxMSBSelectMask			0x00000800	/* 11 */
#define kChiRxMSBSelectMask			0x00000400	/* 10 */
#define kChiRxFsNegativePolMask		0x00000200	/* 9 */
#define kChiTxFsNegativePolMask		0x00000100	/* 8 */
#define kChiRxRisingEdgeMask		0x00000080	/* 7 */
#define kChiTxRisingEdgeMask		0x00000040	/* 6 */
#define kChiRxFsRisingEdgeMask		0x00000020	/* 5 */
#define kChiTxFsRisingEdgeMask		0x00000010	/* 4 */
#define kChiSelect2xClockMask		0x00000008	/* 3 */
#define kChiEnReceiveMask			0x00000004	/* 2 */
#define kChiEnTransmitMask			0x00000002	/* 1 */
#define kChiEnMask					0x00000001	/* 0 */

#define kChiFsWidthShift			25
#define kChiNumChanTimeslotsShift	20
#define kChiTxBitOffsetShift		16
#define kChiRxBitOffsetShift		12

/***** Register Equates (PoseidonModule.chiPointerEnable) *****/
#define kChiEnTxPtrB3TimeslotMask	0x80000000	/* 31 */
#define kChiEnTxPtrB2TimeslotMask	0x40000000	/* 30 */
#define kChiEnTxPtrB1TimeslotMask	0x20000000	/* 29 */
#define kChiEnTxPtrB0TimeslotMask	0x10000000	/* 28 */
#define kChiEnTxPtrA3TimeslotMask	0x08000000	/* 27 */
#define kChiEnTxPtrA2TimeslotMask	0x04000000	/* 26 */
#define kChiEnTxPtrA1TimeslotMask	0x02000000	/* 25 */
#define kChiEnTxPtrA0TimeslotMask	0x01000000	/* 24 */
#define kChiEnRxPtrB3TimeslotMask	0x00800000	/* 23 */
#define kChiEnRxPtrB2TimeslotMask	0x00400000	/* 22 */
#define kChiEnRxPtrB1TimeslotMask	0x00200000	/* 21 */
#define kChiEnRxPtrB0TimeslotMask	0x00100000	/* 20 */
#define kChiEnRxPtrA3TimeslotMask	0x00080000	/* 19 */
#define kChiEnRxPtrA2TimeslotMask	0x00040000	/* 18 */
#define kChiEnRxPtrA1TimeslotMask	0x00020000	/* 17 */
#define kChiEnRxPtrA0TimeslotMask	0x00010000	/* 16 */

/***** Register Equates (PoseidonModule.chiRxPointerA) *****/
#define kChiRxPtrA3Mask				0x1f000000	/* 28:24 */
#define kChiRxPtrA2Mask				0x001f0000	/* 20:16 */
#define kChiRxPtrA1Mask				0x00001f00	/* 12:8 */
#define kChiRxPtrA0Mask				0x0000001f	/* 4:0 */

#define kChiRxPtrA3Shift			24
#define kChiRxPtrA2Shift			16
#define kChiRxPtrA1Shift			8
#define kChiRxPtrA0Shift			0

/***** Register Equates (PoseidonModule.chiRxPointerB) *****/
#define kChiRxPtrB3Mask				0x1f000000	/* 28:24 */
#define kChiRxPtrB2Mask				0x001f0000	/* 20:16 */
#define kChiRxPtrB1Mask				0x00001f00	/* 12:8 */
#define kChiRxPtrB0Mask				0x0000001f	/* 4:0 */

#define kChiRxPtrB3Shift			24
#define kChiRxPtrB2Shift			16
#define kChiRxPtrB1Shift			8
#define kChiRxPtrB0Shift			0

/***** Register Equates (PoseidonModule.chiTxPointerA) *****/
#define kChiTxPtrA3Mask				0x1f000000	/* 28:24 */
#define kChiTxPtrA2Mask				0x001f0000	/* 20:16 */
#define kChiTxPtrA1Mask				0x00001f00	/* 12:8 */
#define kChiTxPtrA0Mask				0x0000001f	/* 4:0 */

#define kChiTxPtrA3Shift			24
#define kChiTxPtrA2Shift			16
#define kChiTxPtrA1Shift			8
#define kChiTxPtrA0Shift			0

/***** Register Equates (PoseidonModule.chiTxPointerB) *****/
#define kChiTxPtrB3Mask				0x1f000000	/* 28:24 */
#define kChiTxPtrB2Mask				0x001f0000	/* 20:16 */
#define kChiTxPtrB1Mask				0x00001f00	/* 12:8 */
#define kChiTxPtrB0Mask				0x0000001f	/* 4:0 */

#define kChiTxPtrB3Shift			24
#define kChiTxPtrB2Shift			16
#define kChiTxPtrB1Shift			8
#define kChiTxPtrB0Shift			0

/***** Register Equates (PoseidonModule.chiSize) *****/
#define kChiDmaPtrMask				0x3ffc0000	/* 29:18 */
#define kChiDmaOnceMask				0x00008000	/* 15 */
#define kChiDmaLoopMask				0x00004000	/* 14 */
#define kChiDmaSizeMask				0x00003ffc	/* 13:2 */
#define kChiEnRxDmaMask				0x00000002	/* 1 */
#define kChiEnTxDmaMask				0x00000001	/* 0 */

#define kChiDmaPtrShift				18
#define kChiDmaSizeShift			2

/***** Register Equates (PoseidonModule.chiRxStart) *****/
#define kChiRxDmaStartAddrMask		0xfffffffc	/* 31:2 */
#define kChiRxDmaStartAddrShift		2

/***** Register Equates (PoseidonModule.chiTxStart) *****/
#define kChiTxDmaStartAddrMask		0xfffffffc	/* 31:2 */
#define kChiTxDmaStartAddrShift		2

/***** Register Equates (PoseidonModule.chiHold) *****/


#endif /* __POSEIDON__ */
