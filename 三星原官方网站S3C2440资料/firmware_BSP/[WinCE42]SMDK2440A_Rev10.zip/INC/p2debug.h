/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.
Copyright (c) 1995-2000 Microsoft Corporation.  All rights reserved.

Module Name:  

  p2.h

Abstract:  

    This file provides definitions for the debug section of the Windows CE P2
    Reference Platform provided by the housekeeping FPGA.  The interfaces that
    are described here are only available on a development platform that is
    compatible with the P2 platform; they are not available on an OEM platform.

  
Functions:

  
Notes:


Revision History:

--*/
#ifndef _P2DEBUG_H_
#define _P2DEBUG_H_

//
// Housekeeping FPGA registers.
//


// This rather involved ifdef tree localizes the differences
// between the 4101 and 4102 as much as possible.  It depends																			  
// on a define in p2.h to indicate the CPU since there is
// that is where the 4101/4102 def is set.

#if defined(R4100) || defined(R4300) || defined(IDT32364)

#ifndef _P2_H_
#include <p2.h>
#endif

#ifdef R4101
// 4101 defs
#define HKEEP_FPGA_REGS_BASE	0xb7000000	// Housekeeping FPGA reg base
// The following define the addresses of the housekeeping Regs
// The high and low equates are for the .s files
#define LEDALPHA_HADDR         0xb700
#define LEDALPHA_LADDR         0x60
#define LEDDESCRETE_HADDR      0xb700
#define LEDDESCRETE_LADDR      0x40

#define PAR_CONTROL_REG		   (HKEEP_FPGA_REGS_BASE + 0x20)
#define LED_DISCRETE		      (HKEEP_FPGA_REGS_BASE + 0x40)
#define LED_ALPHA		         (HKEEP_FPGA_REGS_BASE + 0x60)
// LED_ALPHA_MIRROR is mask of how large a range is mirrored for LEDS
#define LED_ALPHA_MIRROR	    (0x0F)
#endif //R4101

#ifdef R4102
// 4102 defs
#define HKEEP_FPGA_REGS_BASE   0xb0000000	// Housekeeping FPGA reg base
#define LEDALPHA_HADDR         0xb006
#define LEDALPHA_LADDR         0x0
#define LEDDESCRETE_HADDR      0xb004
#define LEDDESCRETE_LADDR      0x0
#endif //R4102

#if defined(R4300) || defined(IDT32364)
#define HKEEP_FPGA_REGS_BASE   0xa4000000	// Housekeeping FPGA reg base
#define LEDALPHA_HADDR         0xa406
#define LEDALPHA_LADDR         0x0
#define LEDDISCRETE_HADDR      0xa404
#define LEDDISCRETE_LADDR      0x0
#endif //R4300

#else // Okay, back to the non-NEC defs...

#ifdef R3000
#define HKEEP_FPGA_REGS_BASE	0xb0000000	// Housekeeping FPGA reg base
#elif defined(SH7709)
#define HKEEP_FPGA_REGS_BASE	0xa8000000	// Hitachi SH7709/SH7729 base
#else
#define HKEEP_FPGA_REGS_BASE	0xa4000000	// Housekeeping FPGA reg base
#endif

#endif //R4100

//
// Parallel port interface.
//
#ifndef R4101
#ifdef R3912
#define PAR_CONTROL_REG		(HKEEP_FPGA_REGS_BASE + 0x00002000)
#else
#define PAR_CONTROL_REG		(HKEEP_FPGA_REGS_BASE + 0x00020000)
#endif
#endif

#define PAR_EN			0x80000000
#define PAR_AUTOEN		0x20000000
#define PAR_BUSY		0x10000000
#define PAR_NACK		0x08000000
#define PAR_ERROR		0x04000000
#define PAR_SELECT		0x02000000
#define PAR_NFAULT		0x01000000
#define PAR_INTR_MASK		0x00200000
#define PAR_INTR		0x00100000
#define PAR_SELECTIN		0x00080000
#define PAR_INIT		0x00040000
#define PAR_AUTOFD		0x00020000
#define PAR_STROBE		0x00010000
#define PAR_DATA_IN		0x0000FF00
#define PAR_DATA_OUT		0x000000FF

#define PAR_BUSY_NFAULT		(PAR_BUSY | PAR_NFAULT)
#define PAR_BUSY_NFAULT_AUTOEN_SELECT	(PAR_BUSY | PAR_NFAULT | PAR_AUTOEN | PAR_SELECT)

//
// LED interfaces.
//
#ifndef R4101
#ifdef R3912
#define LED_DISCRETE		(HKEEP_FPGA_REGS_BASE + 0x4000)
#define LED_ALPHA		(HKEEP_FPGA_REGS_BASE + 0x6000)
#define LED_ALPHA_MIRROR	    (0x0FFF)
#else
#define LED_DISCRETE		0xB1600018  // S3C2400X01
#define LED_ALPHA		    0xB1600018
#define LED_ALPHA_MIRROR	(0xFFFF)
#endif
#endif

#ifdef R3912
#define SWITCH_S1       (HKEEP_FPGA_REGS_BASE + 0x8000)
#else
#define SWITCH_S1       (HKEEP_FPGA_REGS_BASE + 0x80000)
#endif

// Lets define some indexes to be used for various classes of LED writes.
#define LED_INDEX_GENERIC   0       // Miscellaneous LED data 
#define LED_INDEX_DATA      1       // LED value contains DATA of some sort
#define LED_INDEX_ISR       2       // An interrupt has occurred

#endif // _P2DEBUG_H_
