//
// Copyright (c) Microsoft Corporation.  All rights reserved.
//
//
// Use of this source code is subject to the terms of the Microsoft end-user
// license agreement (EULA) under which you licensed this SOFTWARE PRODUCT.
// If you did not accept the terms of the EULA, you are not authorized to use
// this source code. For a copy of the EULA, please see the LICENSE.RTF on your
// install media.
//
/*++
THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF
ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
PARTICULAR PURPOSE.

Module Name:  

Abstract:  
    Provides control of the notification LED.
    
Functions:


Notes: 


--*/

#include <windows.h>
#include <nled.h>
#include <led_drvr.h>
#include <types.h>


/*
	PeRP HAS NO LED's so this module is easy...
*/


/*++

	@doc	EXTERNAL DRIVERS

	@func	BOOL | NLedDriverGetDeviceInfo | Retrieves information about the notification LED.

	@parm	INT | nInfoId |		Id number of the information to retrieve.

	@parm	PVOID | pOutput |	Buffer to put the information.

	@comm	This is the function interface to the driver..

	@xref
--*/
BOOL
WINAPI
NLedDriverGetDeviceInfo(
	INT		nInfoId,
	PVOID	pOutput
	)
{
	if ( nInfoId == NLED_COUNT_INFO_ID )
		{
		struct NLED_COUNT_INFO	*p = (struct NLED_COUNT_INFO*)pOutput;

		p -> cLeds = 0;
		return TRUE;
		}

	SetLastError(ERROR_GEN_FAILURE);
	return FALSE;
}


/*++

	@doc	EXTERNAL DRIVERS

	@func	BOOL | NLedDriverSetDevice | Changes setting of the notification LED.

	@parm	INT	| nInfoId |		Id number of the setting.

	@parm	PVOID | pInput |	Buffer which has the new settings.

	@comm	This is the function interface to the driver..

	@xref
--*/
BOOL
WINAPI
NLedDriverSetDevice(
	INT		nInfoId,
	PVOID	pInput
	)
{
	SetLastError(ERROR_GEN_FAILURE);
	return FALSE;
}


/*++

	@doc     EXTERNAL DRIVERS

	@func    VOID | NLedDriverPowerDown | Power up/down notification to the LED device(s).

	@parm    BOOL | power_down | TRUE = Power down, FALSE = power up.

--*/
VOID
NLedDriverPowerDown(
   BOOL power_down
   )
{
	return;
}




BOOL
NLedDriverInitialize(
	VOID
	)
{
	return TRUE;
}


/*++

	@doc     EXTERNAL DRIVERS

	@func    BOOL |  NLedDriverDllEntry | This is the entry/exit point for the dll.

	@parm    HANDLE | hinstDll    | Instance handle of the Dll.

	@parm    DWORD  | fdwReason   | The reason why the function was called.

	@parm    LPVOID | lpvReserved | Reserved, not used.

	@rdesc   If the function was successful TRUE is returned; otherwise, FALSE.

--*/
BOOL 
NLedDriverDllEntry(
   HANDLE hinstDll, 
   DWORD fdwReason, 
   LPVOID lpvReserved
   )
{
	return TRUE;
}





